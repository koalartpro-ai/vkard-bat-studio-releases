/**
 * VKARD BAT Studio — coquille de l'application Windows (chargée par l'amorce main.mjs).
 *
 * Fenêtre, menus, serveur local, enregistrement des fichiers (onglet Planches) et mises à jour.
 * Ce fichier voyage avec le moteur (engine/desktop/) : il se met à jour en direct, sans réinstallation.
 */
import { app, BrowserWindow, dialog, ipcMain, Menu, shell } from 'electron';
import { createServer } from 'node:net';
import { existsSync, mkdirSync, readFileSync, writeFileSync, readdirSync, rmSync, renameSync, symlinkSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFile } from 'node:child_process';
import { dirname, join, resolve, sep } from 'node:path';
import { pathToFileURL } from 'node:url';

export async function start(ctx) {
const { APP_NAME, bundled, dataDir, logFile, log, readJson, newer, contentRoot, stateFile, badFile, bundledInfo, bundledVersion } = ctx;
let engine = ctx.engine;
function freePort() {
  return new Promise((resolve, reject) => {
    const s = createServer();
    s.once('error', reject);
    s.listen(0, '127.0.0.1', () => {
      const { port } = s.address();
      s.close(() => resolve(port));
    });
  });
}

let win = null;
let baseUrl = '';

// ------------------------------------------------------------- mises à jour du contenu
// Même principe que TEIKO Admin : l'installateur n'est nécessaire qu'une fois.
// Chaque nouvelle version (moteur + interface, quelques Mo) est publiée sous
// forme d'archive .tar.gz + manifest.json dans le dépôt public
// vkard-bat-studio-releases (fichiers servis gratuitement par GitHub, aucun
// service payant). Au lancement puis toutes les 4 h, l'application lit le
// manifeste ; si la version est plus récente, elle télécharge l'archive,
// vérifie son empreinte SHA-256, la décompresse dans son dossier de données
// et propose de redémarrer. Seule cette coquille exige un nouvel installateur,
// et seulement si minShell l'exige. Si une version téléchargée ne démarre pas,
// l'application revient automatiquement à la version intégrée.
const RELEASES = process.env.VKARD_RELEASES || 'https://raw.githubusercontent.com/koalartpro-ai/vkard-bat-studio-releases/main';



/** Le contenu téléchargé réutilise les modules natifs installés (sharp, pdf.js) via une jonction. */
function linkNodeModules(dir) {
  const link = join(dir, 'node_modules');
  if (existsSync(link)) return;
  symlinkSync(join(bundled, 'node_modules'), link, process.platform === 'win32' ? 'junction' : 'dir');
}

function untar(archive, dir) {
  const bin = process.platform === 'win32' ? join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'tar.exe') : 'tar';
  return new Promise((resolve, reject) => execFile(bin, ['-xzf', archive, '-C', dir], { windowsHide: true }, (err) => (err ? reject(err) : resolve())));
}

let readyVersion = null;
let busy = false;
let shellNoticeShown = false;

async function checkContentUpdate(manual = false) {
  if (busy) return;
  busy = true;
  const info = (message, detail) => manual && dialog.showMessageBox(win ?? undefined, { type: 'info', title: APP_NAME, message, detail });
  try {
    const r = await fetch(`${RELEASES}/manifest.json?t=${Date.now()}`, { cache: 'no-store' });
    if (!r.ok) throw new Error(`manifeste indisponible (${r.status})`);
    const m = await r.json();
    // la version sert de nom de dossier (puis de dossier supprimé au nettoyage) : format strict, rien d'autre
    if (!/^\d{1,4}\.\d{1,4}\.\d{1,6}$/.test(m?.version ?? '') || !/^[\w.-]+\.tar\.gz$/.test(m.archive ?? '') || !/^[0-9a-f]{64}$/.test(m.sha256 ?? ''))
      throw new Error('manifeste invalide');
    const active = readyVersion ?? engine.version;
    if (!newer(m.version, active)) {
      info('Vous utilisez la dernière version', `Version ${engine.version}`);
      return;
    }
    // nouvelle coquille requise, ou modules natifs différents de ceux installés
    if ((m.minShell || 1) > ctx.BOOT_VERSION || (m.depsKey && bundledInfo.depsKey && m.depsKey !== bundledInfo.depsKey)) {
      log('maj', `version ${m.version} : nouvel installateur requis (minShell ${m.minShell})`);
      if (manual || !shellNoticeShown) {
        shellNoticeShown = true;
        const { response } = await dialog.showMessageBox(win ?? undefined, {
          type: 'info', title: APP_NAME, buttons: m.installerUrl ? ['Télécharger', 'Plus tard'] : ['OK'], defaultId: 0, cancelId: 1,
          message: `La version ${m.version} nécessite un nouvel installateur`,
          detail: 'Vos dossiers et réglages seront conservés : il suffit d’installer par-dessus la version actuelle.',
        });
        if (response === 0 && m.installerUrl) openOutside(m.installerUrl, /^https:\/\/github\.com\/koalartpro-ai\//);
      }
      return;
    }
    if (readJson(badFile, []).includes(m.version)) return;
    log('maj', `téléchargement de la version ${m.version}`);
    win?.setProgressBar(2); // indéterminé
    const res = await fetch(`${RELEASES}/${m.archive}?t=${Date.now()}`, { cache: 'no-store' });
    if (!res.ok) throw new Error(`archive indisponible (${res.status})`);
    const buf = Buffer.from(await res.arrayBuffer());
    if (createHash('sha256').update(buf).digest('hex') !== m.sha256) throw new Error('empreinte SHA-256 incorrecte');
    mkdirSync(contentRoot, { recursive: true });
    const archive = join(contentRoot, `${m.version}.tar.gz`);
    const tmp = join(contentRoot, `${m.version}.tmp`);
    const dir = join(contentRoot, m.version);
    writeFileSync(archive, buf);
    rmSync(tmp, { recursive: true, force: true });
    mkdirSync(tmp, { recursive: true });
    await untar(archive, tmp);
    if (!existsSync(join(tmp, 'server.mjs'))) throw new Error('archive incomplète');
    rmSync(dir, { recursive: true, force: true });
    renameSync(tmp, dir);
    rmSync(archive, { force: true });
    linkNodeModules(dir);
    writeFileSync(stateFile, JSON.stringify({ version: m.version, installedAt: new Date().toISOString() }));
    readyVersion = m.version;
    // ménage : on garde la version en cours d'exécution et la nouvelle
    for (const d of readdirSync(contentRoot)) {
      if (![m.version, engine.version, 'current.json', 'bad.json'].includes(d)) rmSync(join(contentRoot, d), { recursive: true, force: true });
    }
    win?.setProgressBar(-1);
    log('maj', `version ${m.version} prête`);
    const notes = typeof m.notes === 'string' ? m.notes.trim().slice(0, 700) : '';
    const { response } = await dialog.showMessageBox(win ?? undefined, {
      type: 'info', title: APP_NAME, buttons: ['Redémarrer maintenant', 'Plus tard'], defaultId: 0, cancelId: 1,
      message: `La version ${m.version} est prête`,
      detail: `${notes ? notes + '\n\n' : ''}Vos dossiers et réglages sont conservés. Avec « Plus tard », elle sera utilisée au prochain démarrage.`,
    });
    if (response === 0) {
      app.relaunch();
      app.exit(0);
    }
  } catch (e) {
    win?.setProgressBar(-1);
    log('maj', `vérification impossible : ${e?.message ?? e}`);
    if (manual) dialog.showMessageBox(win ?? undefined, { type: 'warning', title: APP_NAME, message: 'Impossible de vérifier les mises à jour', detail: 'Vérifiez la connexion Internet puis réessayez.' });
  } finally {
    busy = false;
  }
}

async function startServer() {
  const res = engine.dir;
  if (engine.downloaded) linkNodeModules(res);
  const port = await freePort();
  Object.assign(process.env, {
    NODE_ENV: 'production',
    HOST: '127.0.0.1',
    PORT: String(port),
    DATA_DIR: join(dataDir, 'data'),
    VKARD_ROOT: res,
    VKARD_WORKER: join(res, 'worker.mjs'),
    PDFJS_ASSETS: join(bundled, 'node_modules', 'pdfjs-dist'),
    LOG_LEVEL: 'warn',
    RENDER_WORKERS: '2',
  });
  if (!existsSync(join(res, 'server.mjs'))) throw new Error(`Fichiers de l'application introuvables (${res}).`);
  await import(pathToFileURL(join(res, 'server.mjs')).href);
  baseUrl = `http://127.0.0.1:${port}`;
  // attente de la disponibilité de l'API
  for (let i = 0; i < 100; i++) {
    try {
      const r = await fetch(`${baseUrl}/api/health`);
      if (r.ok) return;
    } catch {
      /* pas encore prêt */
    }
    await new Promise((r) => setTimeout(r, 100));
  }
  throw new Error('Le moteur ne répond pas.');
}

function createWindow() {
  win = new BrowserWindow({
    width: 1600,
    height: 980,
    minWidth: 1200,
    minHeight: 720,
    title: APP_NAME,
    backgroundColor: '#F4F4F2',
    show: false,
    webPreferences: { preload: join(import.meta.dirname, 'preload.cjs'), contextIsolation: true, nodeIntegration: false, sandbox: true },
  });
  win.once('ready-to-show', () => win.show());
  win.loadURL(baseUrl);
  // liens externes : navigateur par défaut (comparaison d'origine exacte : « http://127.0.0.1:port@autre.site » ou un
  // autre port local ne passent pas pour l'application)
  const appOrigin = new URL(baseUrl).origin;
  const inApp = (url) => { try { return new URL(url).origin === appOrigin; } catch { return false; } };
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (!inApp(url)) openOutside(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e, url) => {
    if (!inApp(url)) {
      e.preventDefault();
      openOutside(url);
    }
  });
  win.on('closed', () => (win = null));
}

function buildMenu() {
  const template = [
    {
      label: 'Fichier',
      submenu: [
        { label: 'Ouvrir le dossier des données', click: () => shell.openPath(dataDir) },
        { type: 'separator' },
        { role: 'quit', label: 'Quitter' },
      ],
    },
    {
      label: 'Affichage',
      submenu: [
        { role: 'reload', label: 'Recharger' },
        { role: 'resetZoom', label: 'Taille réelle' },
        { role: 'zoomIn', label: 'Zoom avant' },
        { role: 'zoomOut', label: 'Zoom arrière' },
        { type: 'separator' },
        { role: 'togglefullscreen', label: 'Plein écran' },
        { role: 'toggleDevTools', label: 'Outils de développement' },
      ],
    },
    {
      label: 'Aide',
      submenu: [
        { label: 'Rechercher des mises à jour…', click: () => checkContentUpdate(true) },
        { label: 'Journal de l’application', click: () => shell.openPath(logFile) },
        { label: 'Télécharger Ghostscript (fichiers EPS)', click: () => shell.openExternal('https://www.ghostscript.com/releases/gsdnld.html') },
        { type: 'separator' },
        { label: `À propos — version ${engine.version}${engine.downloaded ? ' (mise à jour)' : ''}`, enabled: false },
      ],
    },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}


/** Ouvre un lien dans le navigateur, seulement https: / mailto: (jamais file:, ms-msdt:, search-ms:…). */
function openOutside(url, only) {
  let u;
  try { u = new URL(url); } catch { return; }
  if (!['https:', 'mailto:'].includes(u.protocol) || (only && !only.test(url))) { log('lien', `refusé : ${url}`); return; }
  shell.openExternal(url);
}

// ------------------------------------------------------------- enregistrement (onglet Planches)
ipcMain.handle('vkard-save-file', async (e, { name, data, filters }) => {
  const w = BrowserWindow.fromWebContents(e.sender);
  const r = await dialog.showSaveDialog(w, { defaultPath: name, filters: filters?.length ? filters : undefined });
  if (r.canceled || !r.filePath) return null;
  writeFileSync(r.filePath, Buffer.from(data));
  return r.filePath;
});
ipcMain.handle('vkard-save-folder', async (e, { folderName, files }) => {
  const w = BrowserWindow.fromWebContents(e.sender);
  const r = process.env.VKARD_TEST_DIR ? { canceled: false, filePaths: [process.env.VKARD_TEST_DIR] }
    : await dialog.showOpenDialog(w, { title: `Choisir où créer le dossier « ${folderName} »`, buttonLabel: 'Enregistrer ici', properties: ['openDirectory', 'createDirectory'] });
  if (r.canceled || !r.filePaths?.[0]) return null;
  // nom de dossier simple (pas de chemin) ; un dossier existant et non vide n'est jamais complété : on crée « NOM (2) »…
  // (sinon d'anciennes planches resteraient mélangées aux nouvelles)
  if (!folderName || /[\\/]|^\.+$/.test(folderName)) throw new Error(`Nom de dossier refusé : ${folderName}`);
  let dir = join(r.filePaths[0], folderName), k = 2;
  while (existsSync(dir) && readdirSync(dir).length) dir = join(r.filePaths[0], `${folderName} (${k++})`);
  mkdirSync(dir, { recursive: true });
  // noms relatifs acceptés (« sources/carte.pdf » : onglet Production), sans sortir du dossier
  for (const f of files) {
    const target = resolve(dir, f.name);
    if (!target.startsWith(resolve(dir) + sep)) throw new Error(`Nom de fichier refusé : ${f.name}`);
    mkdirSync(dirname(target), { recursive: true });
    writeFileSync(target, Buffer.from(f.data));
  }
  if (!process.env.VKARD_TEST_DIR) shell.openPath(dir);
  return dir;
});
ipcMain.handle('vkard-info', () => ({ version: engine.version, downloaded: engine.downloaded, boot: ctx.BOOT_VERSION }));

app.on('second-instance', () => {
  if (win) {
    if (win.isMinimized()) win.restore();
    win.focus();
  }
});

process.on('uncaughtException', (e) => log('uncaughtException', e?.stack ?? e));
process.on('unhandledRejection', (e) => log('unhandledRejection', e?.stack ?? e));

app.whenReady().then(async () => {
  try {
    await startServer();
    buildMenu();
    log('démarrage', `version ${engine.version}${engine.downloaded ? ' (téléchargée)' : ' (intégrée)'}`, baseUrl, 'données', dataDir);
    createWindow();
    setTimeout(() => checkContentUpdate(false), 5000);
    setInterval(() => checkContentUpdate(false), 4 * 3600 * 1000);
  } catch (e) {
    log('erreur de démarrage', e?.stack ?? e);
    if (engine.downloaded) {
      // version téléchargée défaillante : on l'écarte et on redémarre sur la version intégrée
      const bad = readJson(badFile, []);
      writeFileSync(badFile, JSON.stringify([...new Set([...bad, engine.version])]));
      log('maj', `version ${engine.version} écartée, retour à la version intégrée ${bundledVersion}`);
      app.relaunch();
      app.exit(0);
      return;
    }
    dialog.showErrorBox(APP_NAME, `L'application n'a pas pu démarrer.\n\n${e?.message ?? e}\n\nJournal : ${logFile}`);
    app.quit();
  }
});

app.on('window-all-closed', () => app.quit());
}
