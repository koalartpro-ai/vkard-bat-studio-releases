const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('api', {
  saveFile: (name, data, filters) => ipcRenderer.invoke('save-file', { name, data, filters }),
  saveFolder: (folderName, files) => ipcRenderer.invoke('save-folder', { folderName, files }),
  contentReady: () => ipcRenderer.send('content-ready'),
  appInfo: () => ipcRenderer.invoke('app-info'),
  checkUpdate: () => ipcRenderer.invoke('check-update')
});
