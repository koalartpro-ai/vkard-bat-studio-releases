(function(){
'use strict';
const $=s=>document.querySelector(s);
const MM=72/25.4, ASC=0.8; // une position de texte = haut du bloc ; ligne de base = haut + 0,8 x corps
const NS='http://www.w3.org/2000/svg';
try{pdfjsLib.GlobalWorkerOptions.workerSrc='vendor/pdf.worker.min.js'}catch(e){}
try{qrcode.stringToBytes=qrcode.stringToBytesFuncs['UTF-8']}catch(e){}
/* ---------- Intégration dans VKARD BAT Studio (onglet Planches) ----------
   La page tourne dans un cadre de BAT Studio : enregistrement des fichiers par BAT (window.api relayé),
   réglages et modèles stockés par le serveur BAT (dossier de données), ouverture directe depuis un dossier BAT. */
const EMBED=window.parent!==window;let REMOTE={};
if(EMBED){document.documentElement.classList.add('embedded');
  let rid=0;const pend=new Map();
  window.addEventListener('message',e=>{if(e.source!==window.parent||e.origin!==location.origin)return;const d=e.data||{};
    if(d.type==='vkard-api-res'&&pend.has(d.id)){const p=pend.get(d.id);pend.delete(d.id);d.ok?p.res(d.result):p.rej(Object.assign(new Error(d.error||'erreur'),{code:d.code}))}
    else if(d.type==='vkard-job')onBatJob(d.job).catch(x=>{const l=document.getElementById('log');if(l)l.textContent='Ouverture du dossier impossible : '+(x&&x.message||x)})});
  const call=(method,...args)=>new Promise((res,rej)=>{const id=++rid;pend.set(id,{res,rej});window.parent.postMessage({type:'vkard-api',id,method,args},location.origin)});
  window.api={saveFile:(n,d,f)=>call('saveFile',n,d,f),saveFolder:(n,files)=>call('saveFolder',n,files),appInfo:()=>call('appInfo')};
  window.parent.postMessage({type:'vkard-planche-ready'},location.origin)}

/* ---------- état ---------- */
const S={
  art:{bytes:null,wpt:0,hpt:0,name:'',doc:null,demo:true},
  art2:null,variantEl:'',variantMin:2,bg:null,bgKind:'none',fit:'auto',
  sheet:{pageW:304,pageH:412,cols:3,rows:6,cardW:89.5,cardH:58,gapX:7,gapY:9,mL:11.5,mT:8,fillEnd:true},
  data:{cols:[],rows:[],name:'',demo:true},
  rowIdx:0,
  fonts:[
    {id:'helv',label:'Helvetica',family:'Helvetica, Arial, "Liberation Sans", sans-serif',weight:400,std:'Helvetica'},
    {id:'helv-b',label:'Helvetica Gras',family:'Helvetica, Arial, "Liberation Sans", sans-serif',weight:700,std:'HelveticaBold'}],
  els:[],sel:null,nextId:1,elsAreDemo:true
};
const byId=id=>S.els.find(e=>e.id===id);
const fontById=id=>S.fonts.find(f=>f.id===id)||S.fonts[0];

/* ---------- utilitaires ---------- */
const norm=s=>String(s==null?'':s).normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase().replace(/[#°.:]/g,'').replace(/[\s_]+/g,' ').trim();
const num=(v,d)=>{const n=parseFloat(String(v).replace(',','.'));return isFinite(n)?n:d};
const r2=v=>Math.round(v*100)/100;
function cmykRgb(c){const[C,M,Y,K]=c.map(v=>v/100);return `rgb(${Math.round(255*(1-C)*(1-K))},${Math.round(255*(1-M)*(1-K))},${Math.round(255*(1-Y)*(1-K))})`}
const ALIAS=[['prenom','firstname','first name','given name'],['nom','name','lastname','nom de famille'],['poste','titre','fonction','title','job','intitule'],['email','e-mail','mail','courriel','adresse mail','adresse email'],['tel','telephone','mobile','portable','phone','numero','num','numero de telephone','n de telephone','gsm','tel portable'],['url','lien','url qr','qr','lien qr','url du qr','qrcode','qrcodes','qr code','qr codes','code qr','lien qr code','lien vkard','vkard']];
function rowKey(row,name){const n=norm(name);for(const k in row){if(norm(k)===n)return row[k]}
  const g=ALIAS.find(g=>g.includes(n));if(g)for(const k in row){if(g.includes(norm(k)))return row[k]}return undefined}
function hasCol(k){const n=norm(k);if(S.data.cols.some(c=>norm(c)===n))return true;const g=ALIAS.find(g=>g.includes(n));return !!g&&S.data.cols.some(c=>g.includes(norm(c)))}
function fmtTel(v){let d=String(v).replace(/[^\d+]/g,'');if(!d)return String(v);
  if(d.startsWith('00'))d='+'+d.slice(2);else if(/^0\d{9}$/.test(d))d='+33'+d.slice(1);else if(/^33\d{9}$/.test(d))d='+'+d;
  const m=/^\+33(\d)(\d{2})(\d{2})(\d{2})(\d{2})$/.exec(d);return m?`+33 ${m[1]} ${m[2]} ${m[3]} ${m[4]} ${m[5]}`:String(v)}
function applyTpl(tpl,row,typo){
  const out=String(tpl).replace(/\{([^}|]+?)(?:\|(upper|lower|title|telbrut|tel))?\}/g,(m,k,f)=>{
    let v=rowKey(row,k);if(v===undefined)return '';v=String(v);if(f==='tel')return fmtTel(v);if(f==='telbrut'){const t=fmtTel(v);return t.startsWith('+')?t.replace(/\s/g,''):v}
    if(f==='upper')v=v.toUpperCase();else if(f==='lower')v=v.toLowerCase();else if(f==='title')v=v.toLowerCase().replace(/(^|[\s'’-])(\p{L})/gu,(a,b,c)=>b+c.toUpperCase());
    return v});
  const o2=out.replace(/\+\s*(?=\+)/g,'');
  return typo?o2.replace(/'/g,'\u2019'):o2;
}
function tplMissing(tpl){const out=[];String(tpl).replace(/\{([^}|]+?)(?:\|\w+)?\}/g,(m,k)=>{if(!hasCol(k))out.push(k)});return out}
const curRow=()=>S.data.rows[S.rowIdx]||{};
function effY(e,row){if(e.type!=='text'||!e.flow)return e.y;const ref=byId(e.flow);if(!ref||ref.type!=='text'||ref===e)return e.y;const extra=Math.max(0,nLines(ref,row)-1);const step=e.flowStep>0?e.flowStep:ref.size/MM*ref.lh;return e.y+extra*step}
const mmFmt=v=>String(r2(v)).replace('.',',');

/* ---------- Styles de QR (charte : fichier QRCODE-01.svg ; unités = points du fichier, QR = 62,37 pt de côté) ---------- */
const QS_SIDE=62.37;
const QS={
  boxtext:{label:'Boîte blanche + VKARD.IO',box:{w:73.7,h:82.21,r:3.61},qx:5.67,qy:5.63,text:{ox:228.87,oy:81.44,d:'M290.89,148.38c-.24-.42-.57-.75-.98-.98-.41-.24-.87-.35-1.38-.35s-.96.12-1.37.35c-.41.23-.74.56-.98.98-.24.42-.36.89-.36,1.41s.12,1,.36,1.42c.24.42.57.75.98.98.41.24.87.36,1.37.36s.96-.12,1.37-.35c.41-.24.74-.57.98-.99.24-.42.36-.89.36-1.42s-.12-1-.36-1.41M289.7,149.8c0,.41-.1.72-.32.96-.21.23-.49.35-.84.35s-.64-.11-.85-.35c-.21-.24-.32-.55-.32-.96s.1-.73.32-.97c.21-.23.49-.34.85-.34s.64.11.85.35c.21.23.32.55.32.96M279.94 147.13h1.53v5.37h-1.53zM274.06 150.97h1.57v1.53h-1.57zM268.6,147.46c-.42-.22-.92-.33-1.48-.33h-2.07v5.37h2.07c.56,0,1.06-.11,1.48-.34.42-.23.75-.55.98-.96.22-.4.34-.88.34-1.4s-.11-.99-.34-1.39c-.23-.4-.55-.72-.98-.95M268.38,149.8c0,.42-.12.73-.35.96-.24.23-.58.34-1.01.34h-.43v-2.6h.43c.44,0,.77.11,1.01.34.23.22.35.55.35.96M260.43,149.92c.22-.28.34-.63.34-1.03,0-.34-.08-.64-.23-.9-.15-.27-.39-.48-.69-.63-.3-.15-.66-.22-1.09-.22h-2.24v5.37h1.53v-1.92h.04l1.1,1.92h1.71l-1.24-2.06c.33-.11.59-.29.78-.53M258.05,148.46h.61c.2,0,.34.04.43.13.09.09.13.21.13.36,0,.17-.04.29-.12.37-.09.08-.23.12-.44.12h-.61v-.98ZM248.86,147.16l-1.97,5.34h1.61l.32-.93h1.69l.32.93h1.63l-1.97-5.34h-1.62ZM250.09,150.34h-.85l.43-1.25.42,1.25ZM241.44 147.13 L239.93 149.07 L239.93 147.13 L238.4 147.13 L238.4 152.5 L239.93 152.5 L239.93 150.52 L241.43 152.5 L243.3 152.5 L241.13 149.76 L243.3 147.13 L241.44 147.13ZM231.56 150.61 L230.46 147.23 L230.43 147.13 L228.79 147.13 L230.66 152.5 L232.45 152.5 L234.32 147.13 L232.69 147.13 L231.56 150.61Z'}},
  box:{label:'Boîte blanche',box:{w:73.7,h:73.7,r:3.61},qx:5.67,qy:5.67,text:null},
  text:{label:'QR + VKARD.IO (sans boîte)',box:null,qx:0,qy:0,text:{ox:134.99,oy:88.57,d:'M194.65,158.38c-.4,0-.72-.13-.96-.4s-.36-.62-.36-1.06.12-.81.36-1.07c.24-.26.56-.39.96-.39s.72.13.96.4.35.62.35,1.06-.12.8-.36,1.06c-.24.26-.56.4-.95.4M194.65,159.53c.47,0,.9-.11,1.29-.33.39-.22.7-.53.93-.93.23-.4.34-.84.34-1.34s-.11-.94-.34-1.34c-.22-.39-.53-.7-.92-.92-.39-.22-.82-.33-1.3-.33s-.9.11-1.29.33c-.39.22-.7.53-.93.92-.23.4-.34.84-.34,1.34s.11.94.34,1.34c.23.4.54.71.93.93.39.22.82.33,1.29.33M187.43,154.41h-1.23v5.07h1.23v-5.07ZM181.6,158.26h-1.27v1.23h1.27v-1.23ZM175.56,155.62c-.21-.38-.52-.68-.92-.89-.4-.21-.87-.32-1.41-.32h-1.92v5.07h1.92c.54,0,1.01-.11,1.41-.32.4-.22.71-.51.92-.9.21-.39.32-.83.32-1.32s-.11-.94-.32-1.32M174.24,158c-.27.25-.64.38-1.12.38h-.58v-2.9h.58c.48,0,.85.13,1.12.38.26.25.4.61.4,1.07s-.13.81-.4,1.07M166.43,156.96c.2-.26.31-.57.31-.94,0-.31-.07-.59-.21-.83-.14-.24-.35-.43-.62-.57-.28-.14-.62-.21-1.02-.21h-2.1v5.07h1.23v-1.92h.28l1.1,1.92h1.36l-1.21-1.99c.39-.1.68-.27.89-.53M165.31,156.57c-.12.11-.29.16-.54.16h-.76v-1.28h.76c.24,0,.42.06.53.17.12.12.18.27.18.47,0,.21-.06.37-.17.48M155.08,154.45l-1.86,5.04h1.29l.32-.93h1.9l.32.93h1.31l-1.86-5.04h-1.41ZM155.14,157.62l.64-1.87.63,1.87h-1.27ZM147.63 154.41 L145.89 156.64 L145.89 154.41 L144.67 154.41 L144.67 159.48 L145.89 159.48 L145.89 157.21 L147.62 159.48 L149.1 159.48 L147.06 156.89 L149.1 154.41 L147.63 154.41ZM137.67 158.23 L136.43 154.41 L135.12 154.41 L136.88 159.48 L138.46 159.48 L140.23 154.41 L138.91 154.41 L137.67 158.23Z',h:70.96}},
  plain:{label:'QR seul',box:null,qx:0,qy:0,text:null}};
function roundRectPath(w,h,r){const k=r*.5523,i=r-k;return `M${r} 0H${w-r}c${k} 0 ${r} ${i} ${r} ${r}V${h-r}c0 ${k} ${-i} ${r} ${-r} ${r}H${r}c${-k} 0 ${-r} ${-i} ${-r} ${-r}V${r}c0 ${-k} ${i} ${-r} ${r} ${-r}Z`}
/* géométrie d'un bloc QR en mm : le bloc (boîte + QR + texte) est homothétique, e.size = côté du QR */
function qrGeom(e){const st=QS[e.style]||QS.boxtext,u=e.size/QS_SIDE;
  const w=(st.box?st.box.w:QS_SIDE)*u,h=(st.box?st.box.h:(st.text&&st.text.h?st.text.h:QS_SIDE))*u;
  return{st,u,w,h,qx:e.x+st.qx*u,qy:e.y+st.qy*u}}

/* ---------- QR ---------- */
function qrMatrix(text,ecc){
  const q=qrcode(0,ecc||'M');q.addData(text,'Byte');q.make();const n=q.getModuleCount(),m=[];
  for(let r=0;r<n;r++){const row=[];for(let c=0;c<n;c++)row.push(q.isDark(r,c));m.push(row)}return m}
function qrPath(m,x0,y0,size){ // tracé unique, runs fusionnés
  const n=m.length,mod=size/n,runs=new Map();
  for(let r=0;r<n;r++){let c=0;while(c<n){if(m[r][c]){const s=c;while(c<n&&m[r][c])c++;const k=s+'-'+c;if(!runs.has(k))runs.set(k,[]);runs.get(k).push(r)}else c++}}
  let d='';const f=v=>(+v.toFixed(4));
  for(const[k,rows]of runs){const[s,e]=k.split('-').map(Number);let a=rows[0],p=a;
    for(let i=1;i<=rows.length;i++){const r=rows[i];if(r===undefined||r!==p+1){d+=`M${f(x0+s*mod)} ${f(y0+a*mod)}h${f((e-s)*mod)}v${f((p+1-a)*mod)}h${f(-(e-s)*mod)}z`;a=r}p=r}}
  return d}

/* ---------- police : mesure (aperçu) ---------- */
const mctx=document.createElement('canvas').getContext('2d');
function measure(fontId,text,sizePt){const f=fontById(fontId);mctx.font=`${f.std?(f.weight>=600?'bold ':''):(f.variable?f.weight+' ':'')}${sizePt}px ${f.family}`;return mctx.measureText(text).width}
/* graisses : nom <-> valeur (polices variables comme Work Sans) */
const WNAMES=[[100,'Thin'],[200,'ExtraLight'],[300,'Light'],[400,'Regular'],[500,'Medium'],[600,'SemiBold'],[700,'Bold'],[800,'ExtraBold'],[900,'Black']];
function weightFromName(n){n=norm(n||'').replace(/[\s_-]/g,'');if(!n)return null;
  if(/extrabold|ultrabold|heavy/.test(n))return 800;if(/semibold|demibold/.test(n))return 600;if(/extralight|ultralight/.test(n))return 200;
  if(/black/.test(n))return 900;if(/bold/.test(n))return 700;if(/medium/.test(n))return 500;if(/book/.test(n))return 400;if(/light/.test(n))return 300;if(/thin|hairline/.test(n))return 100;
  if(/regular|normal|roman/.test(n))return 400;return null}
const weightName=w=>WNAMES.reduce((a,b)=>Math.abs(b[0]-w)<Math.abs(a[0]-w)?b:a)[1];
const fkCache=new Map();
function fkOf(f){let k=fkCache.get(f.baseId||f.id);if(!k){k=fontkit.create(f.bytes.slice(0));fkCache.set(f.baseId||f.id,k)}return k}
function fkInst(f){const key=(f.baseId||f.id)+'@'+f.wght;let k=fkCache.get(key);if(!k){k=fkOf(f).getVariation({wght:f.wght});fkCache.set(key,k)}return k}
/* graisse d'un texte d'après les largeurs de lettres enregistrées dans le PDF, comparées à la police variable installée */
function matchWeight(f,widths){if(!widths||!Object.keys(widths).length)return null;const base=fkOf(f),ax=base.variationAxes.wght,up=base.unitsPerEm;let best=null;
  for(let w=Math.ceil(ax.min/25)*25;w<=ax.max;w+=25){const v=base.getVariation({wght:w});let err=0,n=0;
    for(const[c,wd]of Object.entries(widths)){const g=v.glyphForCodePoint(+c);if(!g||!g.id)continue;err+=Math.abs(g.advanceWidth*1000/up-wd);n++}
    if(n&&(!best||err<best.err))best={w,err}}
  return best?best.w:null}
/* même police variable à une autre graisse (même fichier, même FontFace) */
function variantOf(f,w){w=Math.round(w);const baseId=f.baseId||f.id;if((f.wght||0)===w)return f;
  let v=S.fonts.find(x=>(x.baseId||x.id)===baseId&&x.wght===w);if(v)return v;
  v={...f,id:'f'+(S.nextId++),baseId,wght:w,weight:w,label:(f.familyName||f.label)+' '+weightName(w),ps:''};S.fonts.push(v);return v}
/* texte plus large que la largeur max : selon le choix de l'élément (e.over)
   'ask' (défaut) = rien n'est changé, on propose des solutions · 'shrink' = réduire la taille · 'none' = laisser dépasser */
function fitLines(el,lines,measureFn){
  let size=el.size;if(!(el.maxW>0)||(el.over||'ask')!=='shrink')return size;const maxPt=el.maxW*MM;
  const w=Math.max(0,...lines.map(l=>measureFn(l,size)));
  return w>maxPt?Math.max(3,size*maxPt/w):size}

/* ---------- éléments par défaut (exemple) ---------- */
function defaultEls(){
  const mk=(o)=>Object.assign({id:'e'+(S.nextId++)},o);
  const L=[
    mk({type:'qr',name:'QR code',col:'URL QR',style:'boxtext',x:50.3,y:14.9,size:+(QS_SIDE/MM).toFixed(2),ecc:'M',color:[0,0,0,100],boxColor:[0,0,0,0]}),
    mk({type:'text',name:'Nom',tpl:'{Prénom} {Nom|upper}',font:'helv-b',size:8.5,x:7.3,y:19.5,color:[66,19,0,0],lh:1.2,maxW:42}),
    mk({type:'text',name:'Poste',tpl:'{Poste}',font:'helv',size:6.5,x:7.3,y:22.9,color:[66,19,0,0],lh:1.2,maxW:42,wrap:true}),
    mk({type:'text',name:'Email',tpl:'{Email}',font:'helv',size:5.5,x:11.5,y:26.5,color:[0,0,0,0],lh:1.2,maxW:38,flow:'@poste'}),
    mk({type:'text',name:'Téléphone',tpl:'{Téléphone}',font:'helv',size:5.5,x:11.5,y:29.8,color:[0,0,0,0],lh:1.2,maxW:38,flow:'@poste'})];
  const poste=L.find(e=>e.name==='Poste');L.forEach(e=>{if(e.flow==='@poste')e.flow=poste.id});return L;
}
function autoMapCols(){ // quand l'utilisateur charge ses données et n'a pas encore modifié les éléments
  const find=(...a)=>S.data.cols.find(c=>a.includes(norm(c)));
  const pre=find('prenom','firstname','first name'),nom=find('nom','name','lastname','nom de famille'),full=find('nom complet','fullname');
  const poste=find('poste','titre','fonction','title','job'),mail=find('email','e-mail','mail','courriel'),tel=find('tel','telephone','mobile','portable','phone','numero','num','gsm');
  const url=find('url','lien','url qr','qr','lien qr','url du qr','qrcode','qrcodes','qr code','qr codes','code qr');
  for(const e of S.els){
    if(e.type==='qr'&&url)e.col=url;
    if(e.name==='Nom')e.tpl=full?`{${full}}`:(pre&&nom?`{${pre}} {${nom}|upper}`:(nom?`{${nom}}`:e.tpl));
    if(e.name==='Poste'&&poste)e.tpl=`{${poste}}`;
    if(e.name==='Email'&&mail)e.tpl=`{${mail}}`;
    if(e.name==='Téléphone'&&tel)e.tpl=`{${tel}}`;
  }}

/* ---------- carte de démonstration (générée) ---------- */
async function demoCard(){
  const{PDFDocument,cmyk}=PDFLib;const d=await PDFDocument.create();const w=S.sheet.cardW*MM,h=S.sheet.cardH*MM;const p=d.addPage([w,h]);
  p.drawRectangle({x:0,y:0,width:w,height:h,color:cmyk(0,0,0,1)});
  p.drawCircle({x:w-16,y:22,size:46,borderColor:cmyk(.9,.1,.5,0),borderWidth:5});
  p.drawCircle({x:w-4,y:6,size:62,borderColor:cmyk(.75,.2,0,0),borderWidth:5});
  const f=await d.embedFont(PDFLib.StandardFonts.HelveticaBold);
  p.drawText('ENTREPRISE',{x:7.3*MM,y:h-9*MM,size:11,font:f,color:cmyk(0,0,0,0)});
  p.drawText('CARTE DE BASE (EXEMPLE)',{x:7.3*MM,y:h-12.2*MM,size:5,font:f,color:cmyk(.66,.19,0,0)});
  const b=await d.save();return b}
const demoRows=()=>[
  {'Prénom':'Camille','Nom':'Martin','Poste':'Responsable Achats','Email':'camille.martin@exemple.fr','Téléphone':'+33 6 12 34 56 78','URL QR':'https://exemple.fr/c/camille-martin'},
  {'Prénom':'Julien','Nom':'Dubois','Poste':'Chargé d’Affaires','Email':'julien.dubois@exemple.fr','Téléphone':'+33 6 98 76 54 32','URL QR':'https://exemple.fr/c/julien-dubois'},
  {'Prénom':'Inès','Nom':'Ait Ayoub','Poste':'Alternante Manager\nde la Performance Commerciale','Email':'ines.aitayoub@exemple.fr','Téléphone':'+33 7 64 75 24 08','URL QR':'https://exemple.fr/c/ines-ait-ayoub'}];

/* ---------- chargement carte ---------- */
async function setArt(bytes,name,demo){
  const src=await PDFLib.PDFDocument.load(bytes.slice(0));const sz=src.getPage(0).getSize();
  const doc=await pdfjsLib.getDocument({isEvalSupported:false,data:bytes.slice(0)}).promise;
  const pgb=src.getPage(0),mbx=pgb.getMediaBox(),tb=pgb.getTrimBox(),trim={x:tb.x-mbx.x,y:tb.y-mbx.y,w:tb.width,h:tb.height};
  S.art={bytes,wpt:sz.width,hpt:sz.height,trim,name,doc,demo:!!demo};
  $('#artInfo').textContent=demo?'exemple':`${name.replace(/\s*\(nettoy\S*\)/,'')} · ${mmFmt(sz.width/MM)} × ${mmFmt(sz.height/MM)} mm`;
  const dw=sz.width/MM-S.sheet.cardW,dh=sz.height/MM-S.sheet.cardH;
  const n=$('#artNote');
  await detectBg();
  const pl=artPlace(S.art);
  if(!demo&&pl.mode==='center'&&pl.aw>=S.sheet.cardW-.2&&pl.ah>=S.sheet.cardH-.2&&(Math.abs(dw)>.2||Math.abs(dh)>.2)){n.className='note ok';n.textContent=`Carte de ${mmFmt(sz.width/MM)} × ${mmFmt(sz.height/MM)} mm avec fond perdu : centrée sur son format fini et rognée à l'emplacement de ${mmFmt(S.sheet.cardW)} × ${mmFmt(S.sheet.cardH)} mm.`}
  else if(!demo&&pl.mode==='center'&&(Math.abs(dw)>.2||Math.abs(dh)>.2)){n.className='note ok';n.textContent=`Carte de ${mmFmt(sz.width/MM)} × ${mmFmt(sz.height/MM)} mm centrée dans l'emplacement de ${mmFmt(S.sheet.cardW)} × ${mmFmt(S.sheet.cardH)} mm. Fond perdu : `+(S.bg?'aplat uni étendu autour de la carte.':'pas de fond (la carte est imprimée sans aplat), rien n\'est ajouté.')}
  else if(!demo&&S.bgKind==='complex'&&(Math.abs(dw)>.2||Math.abs(dh)>.2)){n.className='note warn';n.textContent=`Fond non uni (dégradé ou image) : le fond perdu ne peut pas être reconstitué, la carte de ${mmFmt(sz.width/MM)} × ${mmFmt(sz.height/MM)} mm est étirée à ${mmFmt(S.sheet.cardW)} × ${mmFmt(S.sheet.cardH)} mm. Mieux vaut fournir un PDF avec fond perdu.`}
  else if(!demo&&(Math.abs(dw)>.5||Math.abs(dh)>.5)){n.className='note warn';n.textContent=`Le PDF fait ${mmFmt(sz.width/MM)} × ${mmFmt(sz.height/MM)} mm ; la carte de la planche fait ${mmFmt(S.sheet.cardW)} × ${mmFmt(S.sheet.cardH)} mm. Le visuel sera étiré. Étape 4 : « Taille de carte = taille du PDF » pour garder la taille d'origine.`}
  else if(!demo){n.className='note ok';n.textContent='Taille cohérente avec la carte de la planche.'}
  else{n.className='note';n.textContent='Carte d\'exemple. Remplace-la par le PDF de ta carte, sans QR ni texte variable.'}
  if(!demo&&n.className==='note ok'){n.title=n.textContent;n.textContent='✓ Taille de la carte compatible avec le format (survole pour le détail).'}else n.title='';
  await drawArt();drawAll()}
function textLines(e,row){let lines=applyTpl(e.tpl,row,true).split('\n').map(t=>t.trim()).filter(Boolean);
  if(e.wrap&&e.maxW>0){const maxPt=e.maxW*MM,out=[];
    for(const l of lines){let cur='';for(const w of l.split(/\s+/)){const t=cur?cur+' '+w:w;if(cur&&measure(e.font,t,e.size)>maxPt){out.push(cur);cur=w}else cur=t}if(cur)out.push(cur)}
    lines=out}
  return lines}
const nLines=(e,row)=>textLines(e,row).length;
/* Police par champ : un même texte peut mélanger les polices (ex. Prénom en Regular, NOM en Bold sur une ligne).
   e.fieldFonts = { 'Nom': idPolice, ... } ; les champs absents gardent la police du texte. */
const tplFields=tpl=>[...String(tpl).matchAll(/\{([^}|]+?)(?:\|\w+)?\}/g)].map(m=>m[1]).filter((k,i,a)=>a.indexOf(k)===i);
function isMixed(e){return e.type==='text'&&!!e.fieldFonts&&Object.entries(e.fieldFonts).some(([k,v])=>v&&v!==e.font&&tplFields(e.tpl).includes(k))}
/* lignes de morceaux [{t,font}] pour une ligne de données */
function runsOf(e,row){const fonts=e.fieldFonts||{},parts=[];let last=0;const re=/\{([^}|]+?)(?:\|(\w+))?\}/g;let m;
  while((m=re.exec(e.tpl))){if(m.index>last)parts.push({t:applyTpl(e.tpl.slice(last,m.index),row,true),font:e.font});parts.push({t:applyTpl(m[0],row,true),font:fonts[m[1]]||e.font});last=re.lastIndex}
  if(last<e.tpl.length)parts.push({t:applyTpl(e.tpl.slice(last),row,true),font:e.font});
  const lines=[[]];parts.forEach(p=>{p.t.split('\n').forEach((seg,i)=>{if(i)lines.push([]);if(seg)lines[lines.length-1].push({t:seg,font:p.font})})});
  return lines.map(L=>{const out=[];L.forEach(r=>{const q=out[out.length-1];if(q&&q.font===r.font)q.t+=r.t;else out.push({...r})});
    if(out.length){out[0].t=out[0].t.replace(/^\s+/,'');out[out.length-1].t=out[out.length-1].t.replace(/\s+$/,'')}return out.filter(r=>r.t)}).filter(L=>L.length)}
/* largeur (pt) de chaque ligne du texte à une taille donnée, morceaux compris */
function lineWidthsPt(e,row,size){return isMixed(e)?runsOf(e,row).map(L=>L.reduce((a,r)=>a+measure(r.font,r.t,size),0)):textLines(e,row).map(t=>measure(e.font,t,size))}
/* dépassements de la largeur max (mode « me demander ») sur toutes les lignes du fichier */
function overflowOf(e){if(e.type!=='text'||!(e.maxW>0)||(e.over||'ask')!=='ask')return null;const maxPt=e.maxW*MM;let n=0,worst=0,ex=null;
  S.data.rows.forEach((r,i)=>{const w=Math.max(0,...lineWidthsPt(e,r,e.size));if(w>maxPt+.01){n++;if(w>worst){worst=w;ex=i}}});
  return n?{n,needMm:worst/MM,minPt:Math.max(3,e.size*maxPt/worst),row:ex}:null}
function renderFitAsk(){const box=$('#fitAsk');if(!box)return;box.innerHTML='';
  S.els.forEach(e=>{const o=overflowOf(e);if(!o)return;const d=document.createElement('div');d.className='fa';
    const tot=S.data.rows.length;d.innerHTML=`<b>« ${(e.name||'Texte').replace(/[<>&]/g,'')} »</b> dépasse la largeur max (${mmFmt(e.maxW)} mm) sur ${o.n} carte${o.n>1?'s':''} / ${tot} (jusqu'à ${mmFmt(r2(o.needMm))} mm). Rien n'a été modifié : que veux-tu faire ?`;
    const row=document.createElement('div');row.className='row';
    const btn=(t,title,fn)=>{const b=document.createElement('button');b.className='btn sm';b.textContent=t;b.title=title;b.onclick=()=>{fn();S.elsAreDemo=false;renderForm();drawAll(true);drawArt().then(drawOverlay)};row.appendChild(b)};
    btn(`Réduire la taille si besoin (jusqu'à ${o.minPt.toFixed(1)} pt)`,'Seules les cartes trop longues sont réduites, les autres gardent '+e.size+' pt',()=>{e.over='shrink'});
    if(!e.wrap)btn('Passer à la ligne','Le texte trop long continue sur une 2e ligne',()=>{e.wrap=true});
    btn(`Élargir la zone à ${mmFmt(Math.ceil(o.needMm*2)/2)} mm`,'Vérifie que le texte ne touche pas le QR ou le visuel',()=>{e.maxW=Math.ceil(o.needMm*2)/2});
    btn('Laisser dépasser','Le texte garde sa taille, même s\'il dépasse la largeur max',()=>{e.over='none'});
    btn('Voir la carte','Afficher la carte la plus longue dans l\'aperçu',()=>{S.rowIdx=o.row;$('#rowSel').value=o.row});
    d.appendChild(row);box.appendChild(d)})}
function artFor(row){if(S.art2&&S.variantEl){const e=byId(S.variantEl);if(e&&e.type==='text'&&nLines(e,row)>=S.variantMin)return S.art2}return S.art}
async function setArt2(bytes,name){
  const src=await PDFLib.PDFDocument.load(bytes.slice(0));const sz=src.getPage(0).getSize();
  const pgb=src.getPage(0),mbx=pgb.getMediaBox(),tb=pgb.getTrimBox(),trim={x:tb.x-mbx.x,y:tb.y-mbx.y,w:tb.width,h:tb.height};
  S.art2={bytes,wpt:sz.width,hpt:sz.height,trim,name,doc:await pdfjsLib.getDocument({isEvalSupported:false,data:bytes.slice(0)}).promise};refreshVariant();await drawArt();drawOverlay()}
function refreshVariant(){
  $('#art2Info').textContent=S.art2?S.art2.name:'aucune';$('#art2Del').hidden=!S.art2;
  const sel=$('#varEl');sel.innerHTML='<option value="">—</option>';S.els.filter(e=>e.type==='text').forEach(e=>{const o=document.createElement('option');o.value=e.id;o.textContent=e.name||e.tpl;sel.appendChild(o)});
  if(S.variantEl&&!byId(S.variantEl))S.variantEl='';sel.value=S.variantEl;$('#varMin').value=S.variantMin;
  if(S.art2)$('#varBox').open=true}
/* Placement du visuel dans l'emplacement de la planche : centré à sa taille réelle (le fond uni est étendu = fond perdu) ou étiré */
function artPlace(art){const aw=art.wpt/MM,ah=art.hpt/MM,cw=S.sheet.cardW,ch=S.sheet.cardH;
  const t=art.trim&&art.trim.w>10?art.trim:{x:0,y:0,w:art.wpt,h:art.hpt},tw=t.w/MM,th=t.h/MM,tx=t.x/MM,ttop=(art.hpt-t.y-t.h)/MM;
  const near=Math.abs(cw-tw)<=12&&Math.abs(ch-th)<=12,covers=aw>=cw-.2&&ah>=ch-.2;
  let mode=S.fit;if(!mode||mode==='auto')mode=near&&(S.bgKind!=='complex'||covers)?'center':'stretch';
  return mode==='center'?{mode,aw,ah,ox:(cw-tw)/2-tx,oy:(ch-th)/2-ttop,sx:1,sy:1,dw:aw,dh:ah}:{mode,aw,ah,ox:0,oy:0,sx:cw/aw,sy:ch/ah,dw:cw,dh:ch}}
let curDoc=null;
async function drawArt(){
  const art=artFor(curRow());const cv=$('#artCanvas');const box=$('#cardBox');const W=box.clientWidth;if(!W||!art.doc)return;curDoc=art.doc;
  const H=W*S.sheet.cardH/S.sheet.cardW,dpr=Math.min(2,window.devicePixelRatio||1)*1.5;
  cv.width=Math.round(W*dpr);cv.height=Math.round(H*dpr);
  const page=await art.doc.getPage(1);const vp=page.getViewport({scale:1});
  const ctx=cv.getContext('2d');const pl=artPlace(art);ctx.fillStyle=(pl.mode==='center'&&S.bg)?cmykRgb(S.bg.cmyk):'#fff';ctx.fillRect(0,0,cv.width,cv.height);
  const token=++drawArt.t;const pxMm=cv.width/S.sheet.cardW,pxPt=pxMm/MM;
  const task=page.render({canvasContext:ctx,viewport:vp,background:'rgba(0,0,0,0)',transform:pl.mode==='center'?[pxPt,0,0,pxPt,pl.ox*pxMm,pl.oy*pxMm]:[cv.width/vp.width,0,0,cv.height/vp.height,0,0]});
  try{await task.promise}catch(e){}
  if(token===drawArt.t){artUrlCache=null;drawSheet()}
}
drawArt.t=0;
let artUrlCache=null;
function artUrl(){if(artUrlCache)return artUrlCache;const cv=$('#artCanvas');if(!cv||!cv.width||S.art.demo&&!S.art.doc)return null;try{artUrlCache=cv.toDataURL('image/jpeg',.75)}catch(e){artUrlCache=null}return artUrlCache}

/* ---------- chargement données ---------- */
function parseDelimited(text){
  text=text.replace(/^﻿/,'');const first=text.split(/\r?\n/)[0]||'';
  const delim=[';','\t',','].map(d=>[d,first.split(d).length]).sort((a,b)=>b[1]-a[1])[0][0];
  const rows=[];let row=[],cur='',q=false;
  for(let i=0;i<text.length;i++){const c=text[i];
    if(q){if(c==='"'){if(text[i+1]==='"'){cur+='"';i++}else q=false}else cur+=c}
    else if(c==='"')q=true;else if(c===delim){row.push(cur);cur=''}
    else if(c==='\n'||c==='\r'){if(c==='\r'&&text[i+1]==='\n')i++;row.push(cur);rows.push(row);row=[];cur=''}
    else cur+=c}
  if(cur!==''||row.length){row.push(cur);rows.push(row)}return rows}
async function loadData(file){
  let aoa;
  if(/\.(xlsx|xls|xlsm)$/i.test(file.name)){
    const wb=XLSX.read(await file.arrayBuffer(),{type:'array'});
    aoa=XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]],{header:1,raw:false,defval:''})}
  else{const buf=await file.arrayBuffer();let txt;try{txt=new TextDecoder('utf-8',{fatal:true}).decode(buf)}catch(e){txt=new TextDecoder('windows-1252').decode(buf)}aoa=parseDelimited(txt)}
  aoa=aoa.filter(r=>r.some(v=>String(v).trim()!==''));
  if(aoa.length<2){$('#dataNote').className='note bad';$('#dataNote').textContent='Fichier vide ou sans ligne de données.';return}
  const cols=aoa[0].map((h,i)=>String(h).trim()||('Colonne '+(i+1)));
  const rows=aoa.slice(1).map(r=>{const o={};cols.forEach((c,i)=>o[c]=String(r[i]==null?'':r[i]).replace(/\r/g,'').trim());return o});
  S.data={cols,rows,name:file.name,demo:false};{const i=parseNameInfo(file.name);autoNaming({cmd:S.naming.cmd?'':i.cmd,client:S.naming.client?'':i.client})}S.rowIdx=0;
  if(S.elsAreDemo)autoMapCols();
  refreshData();drawAll();drawArt();reportMissing();$('#log').textContent='';if(!$('#review').hidden)$('#rvOk').click()}
function reportMissing(){const miss=new Set();S.els.forEach(e=>{if(e.type==='qr'){if(!hasCol(e.col))miss.add(e.col)}else tplMissing(e.tpl).forEach(k=>miss.add(k))});
  if(miss.size){const n=$('#dataNote');n.className='note warn';n.textContent='Ton fichier n\'a pas de colonne « '+[...miss].join(' », « ')+' » : indique ci-dessous laquelle utiliser.'}updateStatus()}
function refreshData(){
  const d=S.data;$('#dataInfo').textContent=d.demo?'exemple':`${d.name} · ${d.rows.length} ligne${d.rows.length>1?'s':''}`;
  $('#cols').innerHTML='';d.cols.forEach(c=>{const b=document.createElement('button');b.className='chip';b.textContent=c;b.title='Insérer {'+c+'} dans le texte sélectionné';b.onclick=()=>insertToken(c);$('#cols').appendChild(b)});
  const n=$('#dataNote');n.className='note';n.textContent=d.demo?'Lignes d\'exemple. Remplace-les par ton fichier.':`${d.cols.length} colonnes détectées. Clique sur une colonne pour l'insérer dans le texte sélectionné.`;
  const sel=$('#rowSel');sel.innerHTML='';d.rows.forEach((r,i)=>{const o=document.createElement('option');o.value=i;o.textContent=(i+1)+' · '+(r[d.cols[0]]||'')+' '+(r[d.cols[1]]||'');sel.appendChild(o)});sel.value=S.rowIdx;
  updateInfo()}
/* modèle de texte lisible : {Prénom} {Nom|upper} -> Prénom + NOM */
function tplHuman(t){t=String(t||'');const lab=(k,f)=>f==='upper'?k.toUpperCase():f==='lower'?k.toLowerCase():k;
  if(/^(\s*\{[^}]+\}\s*)+$/.test(t))return[...t.matchAll(/\{([^}|]+?)(?:\|(\w+))?\}/g)].map(m=>lab(m[1],m[2])).join(' + ');
  return t.replace(/\{([^}|]+?)(?:\|(\w+))?\}/g,(m,k,f)=>'['+lab(k,f)+']')||'(vide)'}
function insertToken(c){const e=byId(S.sel);if(!e||e.type!=='text')return;e.tpl+=`{${c}}`;e.name=e.name||'Texte';renderForm();drawAll()}

/* ---------- éléments : liste + formulaire ---------- */
function renderList(){
  refreshVariant();const L=$('#elList');L.innerHTML='';
  S.els.forEach(e=>{const d=document.createElement('div');d.className='item';d.setAttribute('role','option');d.tabIndex=0;d.setAttribute('aria-selected',e.id===S.sel);
    const sw=document.createElement('span');sw.className='sw';sw.style.background=e.type==='qr'?'#222':cmykRgb(e.color);
    const k=document.createElement('span');k.className='k';k.textContent=e.type==='qr'?'QR':'Aa';
    const t=document.createElement('span');t.className='t';t.textContent=e.type==='qr'?`QR · lien pris dans « ${e.col||'—'} »`:`${e.name||'Texte'} · ${tplHuman(e.tpl)}`;t.title=e.type==='qr'?'':'Modèle : '+e.tpl;
    d.append(k,t,sw);if(!fontOk(e)){const w=document.createElement('span');w.className='fw';w.textContent='POLICE';w.title='Police remplacée : '+(e.fontLabel||e.fontPs);d.insertBefore(w,sw)}d.onclick=()=>select(e.id);d.onkeydown=ev=>{if(ev.key==='Enter'||ev.key===' '){ev.preventDefault();select(e.id)}};L.appendChild(d)})}
function select(id){S.sel=id;renderList();renderForm();drawOverlay()}
function afterRowChange(){drawArt().then(drawOverlay)}
function field(label,el){const l=document.createElement('label');l.className='f';l.append(label,el);return l}
function inp(val,type,onchange,attrs){const i=document.createElement('input');i.type=type||'text';i.value=val;if(attrs)for(const k in attrs)i.setAttribute(k,attrs[k]);i.oninput=()=>onchange(i.value);return i}
function renderForm(){
  const F=$('#editor');F.innerHTML='';const e=byId(S.sel);if(!e){F.innerHTML='<p class="note" style="margin:0">Sélectionne un élément dans la liste ou sur la carte.</p>';return}
  const upd=(k,conv)=>v=>{e[k]=conv?conv(v):v;S.elsAreDemo=false;if(k==='tpl'||k==='col')renderList();drawAll(true)};
  const n=(k,min,step)=>inp(e[k],'number',upd(k,v=>num(v,e[k])),{step:step||'0.1',min:min==null?'':min});
  if(e.type==='qr'){
    const s=document.createElement('select');const cl=S.data.cols.includes(e.col)?S.data.cols:[e.col,...S.data.cols];cl.forEach(c=>{const o=document.createElement('option');o.value=c;o.textContent=c;s.appendChild(o)});s.value=e.col;s.onchange=()=>upd('col')(s.value);
    F.appendChild(field('Colonne contenant l\'URL du QR',s));
    const ss=document.createElement('select');Object.keys(QS).forEach(k=>{const o=document.createElement('option');o.value=k;o.textContent=QS[k].label;ss.appendChild(o)});ss.value=e.style||'boxtext';ss.onchange=()=>{e.style=ss.value;S.elsAreDemo=false;drawAll(true)};
    F.appendChild(field('Style du QR (charte)',ss));
    const g=document.createElement('div');g.className='grid3';g.append(field('X bloc (mm)',n('x')),field('Y bloc (mm)',n('y')),field('Côté du QR (mm)',n('size',5)));F.appendChild(g);
    const ec=document.createElement('select');['L','M','Q','H'].forEach(v=>{const o=document.createElement('option');o.value=v;o.textContent=v+(v==='M'?' (standard)':'');ec.appendChild(o)});ec.value=e.ecc;ec.onchange=()=>upd('ecc')(ec.value);
    F.appendChild(field('Correction d\'erreur',ec));
  }else{
    F.appendChild(field('Nom de l\'élément',inp(e.name,'text',upd('name'))));
    const ti=inp(e.tpl,'text',v=>{upd('tpl')(v);showPrev()});ti.id='tplIn';
    F.appendChild(field('Contenu (texte libre + {colonnes}, appliqué à toutes les cartes)',ti));
    const pv=document.createElement('p');pv.className='note';pv.style.margin='0';F.appendChild(pv);
    const showPrev=()=>{pv.textContent='Aperçu ligne '+(S.rowIdx+1)+' : '+(applyTpl(e.tpl,curRow(),true).replace(/\n/g,' ⏎ ')||'(vide)')};showPrev();
    const ig=document.createElement('div');ig.className='grid3';ig.style.alignItems='end';
    const cs=document.createElement('select');S.data.cols.forEach(c=>{const o=document.createElement('option');o.value=c;o.textContent=c;cs.appendChild(o)});
    const fs2=document.createElement('select');[['','Tel quel'],['upper','MAJUSCULES'],['lower','minuscules'],['title','Initiales En Majuscule'],['tel','Téléphone +33 6 00 00 00 00'],['telbrut','Téléphone +33600000000']].forEach(([v,l])=>{const o=document.createElement('option');o.value=v;o.textContent=l;fs2.appendChild(o)});
    const ib=document.createElement('button');ib.className='btn sm';ib.textContent='Insérer';ib.onclick=()=>{const tok='{'+cs.value+(fs2.value?'|'+fs2.value:'')+'}';const a=ti.selectionStart??ti.value.length,b=ti.selectionEnd??a;ti.value=ti.value.slice(0,a)+tok+ti.value.slice(b);upd('tpl')(ti.value);showPrev();ti.focus();ti.setSelectionRange(a+tok.length,a+tok.length)};
    ig.append(field('Colonne',cs),field('Format',fs2),ib);F.appendChild(ig);
    const hint=document.createElement('p');hint.className='note';hint.style.margin='0';hint.textContent='Exemples : « +{numero} » ajoute un + devant chaque numéro ; « Tél. {numero|tel} » ; « {Prénom} {Nom|upper} ». Les ajouts s\'appliquent à toutes les cartes.';F.appendChild(hint);
    const miss=tplMissing(e.tpl);if(miss.length){const p=document.createElement('p');p.className='note bad';p.style.margin='0';p.textContent='Colonne introuvable : '+miss.join(', ');F.appendChild(p)}
    const fs=document.createElement('select');S.fonts.forEach(f=>{const o=document.createElement('option');o.value=f.id;o.textContent=f.label;fs.appendChild(o)});{const o=document.createElement('option');o.value='__pick';o.textContent='Autre police installée…';fs.appendChild(o)}fs.value=e.font;fs.onchange=()=>{if(fs.value==='__pick'){fs.value=e.font;openFontPicker('Police pour « '+(e.name||'texte')+' »'+(e.fontLabel?' (demandée : '+e.fontLabel+')':''),f=>applyFontChoice(e,f),(e.fontLabel||'').split(' ')[0])}else{e.fontPicked=true;upd('font')(fs.value);renderForm()}};
    const g=document.createElement('div');g.className='grid2';g.append(field('Police',fs),field('Corps (pt)',n('size',2,'0.1')));F.appendChild(g);
    {const flds=tplFields(e.tpl);if(flds.length>1){const box=document.createElement('div');box.style.cssText='border:1px solid var(--line);border-radius:6px;padding:8px 10px;margin-top:2px';
      box.appendChild(Object.assign(document.createElement('div'),{textContent:'Police par champ (sur la même ligne)',style:'font-size:12px;font-weight:600;margin-bottom:4px'}));
      const gg=document.createElement('div');gg.className='grid2';box.appendChild(gg);
      flds.forEach(k=>{const sel=document.createElement('select');const o0=document.createElement('option');o0.value='';o0.textContent='Comme le texte ('+fontById(e.font).label+')';sel.appendChild(o0);
        S.fonts.forEach(f=>{const o=document.createElement('option');o.value=f.id;o.textContent=f.label;sel.appendChild(o)});
        {const bf=fontById(e.font);if(bf&&bf.variable)[300,400,500,600,700,800,900].forEach(w=>{if(S.fonts.some(x=>(x.baseId||x.id)===(bf.baseId||bf.id)&&x.wght===w))return;const o=document.createElement('option');o.value='__w'+w;o.textContent=(bf.familyName||bf.label)+' '+weightName(w);sel.appendChild(o)})}
        {const o=document.createElement('option');o.value='__pick';o.textContent='Autre police installée…';sel.appendChild(o)}
        const cur=(e.fieldFonts||{})[k]||'';sel.value=cur;
        const set=id=>{e.fieldFonts={...(e.fieldFonts||{})};if(id&&id!==e.font)e.fieldFonts[k]=id;else delete e.fieldFonts[k];S.elsAreDemo=false;renderForm();renderList();drawAll(true);drawArt().then(drawOverlay)};
        sel.onchange=()=>{if(sel.value==='__pick'){sel.value=cur;openFontPicker('Police pour le champ « '+k+' »',f=>set(f.id),'')}else if(sel.value.startsWith('__w'))set(variantOf(fontById(e.font),+sel.value.slice(3)).id);else set(sel.value)};
        gg.appendChild(field(k,sel))});
      box.appendChild(Object.assign(document.createElement('p'),{className:'note',style:'margin:6px 0 0',textContent:'Ex. prénom en Regular et NOM en Bold. Choisis la même police avec une autre graisse (Regular, Bold…) ou une autre police.'}));
      if(isMixed(e)&&e.wrap)box.appendChild(Object.assign(document.createElement('p'),{className:'note warn',style:'margin:4px 0 0',textContent:'Le retour à la ligne automatique n\'est pas appliqué aux textes à plusieurs polices.'}));
      F.appendChild(box)}}
    if(!fontOk(e)){const w=document.createElement('p');w.className='note warn';w.style.margin='0';w.textContent='Police demandée par la carte : '+(e.fontLabel||e.fontPs)+' (introuvable, remplacée par '+fontById(e.font).label+'). Choisis « Autre police installée… ».';F.appendChild(w)}
    const g2=document.createElement('div');g2.className='grid2';g2.append(field(e.align==='center'?'X du centre (mm)':e.align==='right'?'X du bord droit (mm)':'X (mm)',n('x')),field('Y haut du texte (mm)',n('y')));F.appendChild(g2);
    const as=document.createElement('select');[['left','À gauche'],['center','Centré'],['right','À droite']].forEach(([v,l])=>{const o=document.createElement('option');o.value=v;o.textContent=l;as.appendChild(o)});as.value=e.align||'left';
    as.onchange=()=>{const b=e._box;if(b){e.x=r2(as.value==='center'?b[0]+b[2]/2:as.value==='right'?b[0]+b[2]:b[0])}e.align=as.value;S.elsAreDemo=false;renderForm();drawAll(true);drawArt().then(drawOverlay)};
    F.appendChild(field('Alignement du texte (le centre reste fixe quand le nom change)',as));
    const g3=document.createElement('div');g3.className='grid2';g3.append(field('Interligne (×)',n('lh',0.8,'0.05')),field('Largeur max (mm, 0 = libre)',n('maxW',0,'0.5')));F.appendChild(g3);
    const wl=document.createElement('label');wl.className='f';wl.style.flexDirection='row';wl.style.alignItems='center';wl.style.gap='8px';const wc=document.createElement('input');wc.type='checkbox';wc.style.width='auto';wc.checked=!!e.wrap;wc.onchange=()=>{e.wrap=wc.checked;S.elsAreDemo=false;drawAll(true);drawArt().then(drawOverlay)};wl.append(wc,'Retour à la ligne automatique (selon la largeur max)');F.appendChild(wl);
    {const os=document.createElement('select');[['ask','Me prévenir et me proposer des solutions'],['shrink','Réduire la taille automatiquement'],['none','Laisser dépasser']].forEach(([v,l])=>{const o=document.createElement('option');o.value=v;o.textContent=l;os.appendChild(o)});
     os.value=e.over||'ask';os.onchange=()=>{e.over=os.value;S.elsAreDemo=false;drawAll(true);drawArt().then(drawOverlay)};F.appendChild(field('Si le texte dépasse la largeur max',os))}
    const fl=document.createElement('select');fl.innerHTML='<option value="">Position fixe</option>';S.els.filter(x=>x.type==='text'&&x!==e).forEach(x=>{const o=document.createElement('option');o.value=x.id;o.textContent='Descend si « '+(x.name||x.tpl)+' » a plusieurs lignes';fl.appendChild(o)});fl.value=e.flow||'';fl.onchange=()=>{e.flow=fl.value;S.elsAreDemo=false;renderForm();drawAll(true)};
    const g4=document.createElement('div');g4.className='grid2';g4.append(field('Décalage automatique',fl),field('Décalage par ligne (mm, 0 = auto)',n('flowStep',0,'0.1')));F.appendChild(g4);
  }
  const cg=document.createElement('div');cg.className='grid4';
  ['C','M','J','N'].forEach((l,i)=>cg.appendChild(field(l+' %',inp(e.color[i],'number',v=>{e.color[i]=Math.min(100,Math.max(0,num(v,0)));S.elsAreDemo=false;renderList();drawAll(true)},{min:0,max:100,step:1}))));
  F.append(Object.assign(document.createElement('h3'),{textContent:e.type==='qr'?'Couleur du QR (CMJN)':'Couleur CMJN',style:'margin:4px 0 0'}),cg);
  if(e.type==='qr'){e.boxColor=e.boxColor||[0,0,0,0];const bg=document.createElement('div');bg.className='grid4';['C','M','J','N'].forEach((l,i)=>bg.appendChild(field(l+' %',inp(e.boxColor[i],'number',v=>{e.boxColor[i]=Math.min(100,Math.max(0,num(v,0)));drawAll(true)},{min:0,max:100,step:1}))));F.append(Object.assign(document.createElement('h3'),{textContent:'Couleur de la boîte (CMJN)',style:'margin:4px 0 0'}),bg)}}

/* ---------- aperçu : overlay SVG (unités = mm) ---------- */
let drag=null,guides=[];
/* Les éléments (textes, QR) sont en mm dans l'emplacement. Si le placement du visuel change (autre format, autre taille
   de carte ou de fond perdu), on les déplace avec lui pour qu'ils restent au même endroit sur la carte. */
function reanchorEls(){if(!S.art||!S.art.wpt)return;const p=artPlace(S.art),o=S._place;S._place={ox:p.ox,oy:p.oy,sx:p.sx,sy:p.sy};if(!o)return;
  if(Math.abs(o.ox-p.ox)<1e-4&&Math.abs(o.oy-p.oy)<1e-4&&Math.abs(o.sx-p.sx)<1e-6&&Math.abs(o.sy-p.sy)<1e-6)return;
  const kx=p.sx/o.sx,ky=p.sy/o.sy;
  S.els.forEach(e=>{e.x=r2(p.ox+(e.x-o.ox)*kx);e.y=r2(p.oy+(e.y-o.oy)*ky);if(Math.abs(ky-1)>1e-3){e.size=r2(e.size*ky);if(e.maxW)e.maxW=r2(e.maxW*kx)}})}
function drawOverlay(){reanchorEls();
  const svg=$('#ov');const W=S.sheet.cardW,H=S.sheet.cardH;svg.setAttribute('viewBox',`0 0 ${W} ${H}`);svg.innerHTML='';
  const row=curRow();const stageMsgs=[];
  drawTrimGuides(svg,W,H);
  S.els.forEach(e=>{
    const g=document.createElementNS(NS,'g');g.setAttribute('class','el');g.dataset.id=e.id;svg.appendChild(g);
    if(e.type==='qr'){
      const url=applyTpl('{'+e.col+'}',row),G=qrGeom(e),W2=G.w,H2=G.h;
      if(G.st.box){const bx=document.createElementNS(NS,'path');bx.setAttribute('d',roundRectPath(G.st.box.w*G.u,G.st.box.h*G.u,G.st.box.r*G.u));bx.setAttribute('transform',`translate(${e.x} ${e.y})`);bx.setAttribute('fill',cmykRgb(e.boxColor||[0,0,0,0]));g.appendChild(bx)}
      if(url){try{const m=qrMatrix(url,e.ecc);const p=document.createElementNS(NS,'path');p.setAttribute('d',qrPath(m,G.qx,G.qy,e.size));p.setAttribute('fill',cmykRgb(e.color));g.appendChild(p);
        if(G.st.text){const t=document.createElementNS(NS,'path');t.setAttribute('d',G.st.text.d);t.setAttribute('transform',`translate(${G.qx-G.st.text.ox*G.u} ${G.qy-G.st.text.oy*G.u}) scale(${G.u})`);t.setAttribute('fill',cmykRgb(e.color));g.appendChild(t)}
        const hit=document.createElementNS(NS,'rect');hit.setAttribute('x',e.x);hit.setAttribute('y',e.y);hit.setAttribute('width',W2);hit.setAttribute('height',H2);hit.setAttribute('fill','transparent');g.appendChild(hit)}catch(err){stageMsgs.push('QR impossible : '+err.message)}}
      else{const r=document.createElementNS(NS,'rect');r.setAttribute('x',e.x);r.setAttribute('y',e.y);r.setAttribute('width',W2);r.setAttribute('height',H2);r.setAttribute('fill','rgba(179,38,30,.15)');r.setAttribute('stroke','#b3261e');r.setAttribute('stroke-dasharray','1 .6');r.setAttribute('stroke-width','.3');g.appendChild(r);stageMsgs.push('URL manquante pour la ligne affichée.')}
      if(e.id===S.sel){const hd=document.createElementNS(NS,'circle');hd.setAttribute('cx',e.x+W2);hd.setAttribute('cy',e.y+H2);hd.setAttribute('r','1.3');hd.setAttribute('fill','#2F86C4');hd.setAttribute('stroke','#fff');hd.setAttribute('stroke-width','.3');hd.dataset.handle='1';hd.style.cursor='nwse-resize';g.appendChild(hd)}
    }else{
      const mixed=isMixed(e),runs=mixed?runsOf(e,row):null;
      const lines=mixed?runs.map(L=>L.map(r=>r.t).join('')):textLines(e,row);const f=fontById(e.font);const ey=effY(e,row);
      const size=mixed?(()=>{const w0=Math.max(0,...lineWidthsPt(e,row,e.size));return e.maxW>0&&(e.over||'ask')==='shrink'&&w0>e.maxW*MM?Math.max(3,e.size*e.maxW*MM/w0):e.size})():fitLines(e,lines,(t,s)=>measure(e.font,t,s));const szmm=size/MM;
      const lw=lineWidthsPt(e,row,size).map(v=>v/MM);
      lines.forEach((t,i)=>{const tx=document.createElementNS(NS,'text');tx.setAttribute('x',e.x+alOff(e,lw[i]||0));tx.setAttribute('y',ey+szmm*ASC+i*szmm*e.lh);tx.setAttribute('font-size',szmm);tx.setAttribute('font-family',f.family);tx.setAttribute('font-weight',f.weight);tx.setAttribute('fill',cmykRgb(e.color));
        if(mixed)runs[i].forEach(r=>{const rf=fontById(r.font),ts=document.createElementNS(NS,'tspan');ts.setAttribute('font-family',rf.family);ts.setAttribute('font-weight',rf.weight);ts.setAttribute('xml:space','preserve');ts.textContent=r.t;tx.appendChild(ts)});else tx.textContent=t;g.appendChild(tx)});
      const hh=lines.length?szmm*ASC+(lines.length-1)*szmm*e.lh+szmm*.3:szmm;
      const ww=Math.max(1,...lw);
      const bxl=e.x+alOff(e,ww);const hit=document.createElementNS(NS,'rect');hit.setAttribute('x',bxl);hit.setAttribute('y',ey);hit.setAttribute('width',ww);hit.setAttribute('height',hh);hit.setAttribute('fill','transparent');g.insertBefore(hit,g.firstChild);e._box=[bxl,ey,ww,hh];
      if(size<e.size-.01)stageMsgs.push(`« ${e.name} » réduit à ${size.toFixed(1)} pt (choix « réduire la taille »).`);
      if((e.over||'ask')==='ask'&&e.maxW>0&&ww>e.maxW+.01){const xr=e.x+alOff(e,e.maxW);const r=document.createElementNS(NS,'rect');r.setAttribute('x',xr);r.setAttribute('y',ey-.3);r.setAttribute('width',e.maxW);r.setAttribute('height',hh+.6);r.setAttribute('fill','none');r.setAttribute('stroke','#d97706');r.setAttribute('stroke-width','.25');r.setAttribute('stroke-dasharray','.8 .5');r.setAttribute('pointer-events','none');g.appendChild(r)}}
    if(e.id===S.sel){const b=e.type==='qr'?(()=>{const G=qrGeom(e);return[e.x,e.y,G.w,G.h]})():(e._box||[e.x,e.y,5,3]);const o=document.createElementNS(NS,'rect');o.setAttribute('x',b[0]-.4);o.setAttribute('y',b[1]-.4);o.setAttribute('width',b[2]+.8);o.setAttribute('height',b[3]+.8);o.setAttribute('fill','none');o.setAttribute('stroke','#2F86C4');o.setAttribute('stroke-width','.3');o.setAttribute('stroke-dasharray','1 .7');o.setAttribute('pointer-events','none');svg.appendChild(o)}
  });
  guides.forEach(gd=>{const l=document.createElementNS(NS,'line');if(gd.v){l.setAttribute('x1',gd.p);l.setAttribute('x2',gd.p);l.setAttribute('y1',0);l.setAttribute('y2',H)}else{l.setAttribute('y1',gd.p);l.setAttribute('y2',gd.p);l.setAttribute('x1',0);l.setAttribute('x2',W)}l.setAttribute('stroke','#e0218a');l.setAttribute('stroke-width','.2');l.setAttribute('stroke-dasharray','.8 .5');l.setAttribute('pointer-events','none');svg.appendChild(l)});
  {const bf=[...new Set(S.els.filter(e=>!fontOk(e)).map(e=>e.fontLabel||e.fontPs))];if(bf.length)stageMsgs.push('Police '+bf.join(', ')+' absente de ce poste : l\'aperçu et la planche utilisent une police de remplacement.')}
  renderFitAsk();
  const sn=$('#stageNote');sn.className=stageMsgs.length?'note warn':'note';sn.textContent=stageMsgs.length?stageMsgs.join(' '):'Aperçu de la ligne sélectionnée. Les couleurs CMJN sont approchées à l\'écran.';
}
function showTip(){try{if(localStorage.getItem('planche.tipMove'))return;localStorage.setItem('planche.tipMove','1')}catch(x){}
  if(document.getElementById('tip'))return;const t=document.createElement('div');t.id='tip';
  t.innerHTML='<span>Astuce : flèches du clavier = 0,1 mm · Maj + flèches = 1 mm · maintiens Alt en glissant pour désactiver l\'aimant.</span><button>OK</button>';
  t.querySelector('button').onclick=()=>t.remove();document.body.appendChild(t);setTimeout(()=>t.remove(),9000)}
/* ---------- contours : carte finie (selon la matière) + aplat / fond perdu ---------- */
const TRIMS=[{id:'pvc',label:'PVC blanc / noir',w:85.5,h:54},{id:'bambou',label:'Bambou',w:85.2,h:53.7},{id:'metal',label:'Métal silver / gold',w:85,h:54}];
function trimAuto(){const f=S.fmtId||'';if(/bambou/.test(f))return'bambou';if(/metal/.test(f))return'metal';if(/pvc/.test(f))return'pvc';
  const t=norm([S.naming&&S.naming.color,S.naming&&S.naming.model].filter(Boolean).join(' '));
  return/bambou|bois/.test(t)?'bambou':/metal|gold|silver|argent|\bor\b/.test(t)?'metal':'pvc'}
function trimChoice(){let v='auto';try{v=localStorage.getItem('planche.trim')||'auto'}catch(x){}return v}
/* fond perdu enregistré dans le format : par côté (bleedL/R/T/B), ou ancien format symétrique (bleedX/Y) */
function fmtBleed(){const s=S.sheet,has=['bleedL','bleedR','bleedT','bleedB','bleedX','bleedY'].some(k=>s[k]!=null);if(!has)return null;
  const g=(k,o)=>s[k]!=null?+s[k]:s[o]!=null?+s[o]:0;return{l:g('bleedL','bleedX'),r:g('bleedR','bleedX'),t:g('bleedT','bleedY'),b:g('bleedB','bleedY')}}
function curTrim(){const v=trimChoice();if(v==='none')return null;const s=S.sheet,fb=fmtBleed();
  if(v==='auto'&&fb)return{id:'fmt',label:'du format',w:r2(s.cardW-fb.l-fb.r),h:r2(s.cardH-fb.t-fb.b)};
  return TRIMS.find(t=>t.id===(v==='auto'?trimAuto():v))||TRIMS[0]}
/* fond perdu effectif par côté {l,r,t,b} (0 si aucun contour) */
function trimBleed(){const T=curTrim(),s=S.sheet;if(!T)return{l:0,r:0,t:0,b:0};const fb=fmtBleed();
  if(T.id==='fmt'&&fb)return{l:r2(Math.max(0,fb.l)),r:r2(Math.max(0,fb.r)),t:r2(Math.max(0,fb.t)),b:r2(Math.max(0,fb.b))};
  const x=r2(Math.max(0,(s.cardW-T.w)/2)),y=r2(Math.max(0,(s.cardH-T.h)/2));return{l:x,r:x,t:y,b:y}}
function renderTrimSel(){const sel=$('#trimSel');if(!sel)return;const a=TRIMS.find(t=>t.id===trimAuto());
  const fb=!!fmtBleed();sel.innerHTML=`<option value="auto">Contour : auto (${fb?'fond perdu du format':a.label})</option>`+TRIMS.map(t=>`<option value="${t.id}">Contour : ${t.label} · ${mmFmt(t.w)} × ${mmFmt(t.h)}</option>`).join('')+'<option value="none">Sans contour</option>';sel.value=trimChoice()}
function drawTrimGuides(svg,W,H){renderTrimSel();const T=curTrim(),dims=$('#cardDims');
  const B=trimBleed(),bx=B.l,by=B.t,tw=Math.max(1,W-B.l-B.r),th=Math.max(1,H-B.t-B.b),bleed=T&&(B.l+B.r+B.t+B.b>.05);
  if(dims)dims.textContent=T?(bleed?`Aplat ${mmFmt(W)} × ${mmFmt(H)} · carte finie ${mmFmt(r2(tw))} × ${mmFmt(r2(th))} · fond perdu G ${mmFmt(B.l)} · D ${mmFmt(B.r)} · H ${mmFmt(B.t)} · B ${mmFmt(B.b)} mm`:`Carte ${mmFmt(W)} × ${mmFmt(H)} (sans fond perdu)`):`${mmFmt(W)} × ${mmFmt(H)} mm`;
  if(!T)return;const g=document.createElementNS(NS,'g');g.setAttribute('pointer-events','none');
  const mk=(tag,at)=>{const e=document.createElementNS(NS,tag);for(const k in at)e.setAttribute(k,at[k]);g.appendChild(e);return e};
  /* étiquette en pastille blanche (lisible sur fond clair ou foncé) ; x,y = coin haut-gauche, ou haut-droit si right */
  const label=(x,y,t,c,right)=>{const fs=1.45,w=t.length*fs*.56+1.2,h=fs+.9,x0=right?x-w:x;
    mk('rect',{x:x0,y,width:w,height:h,rx:.5,fill:'#fff',stroke:c,'stroke-width':.15,opacity:.95});
    const e=mk('text',{x:x0+.6,y:y+h/2,'dominant-baseline':'central','font-size':fs,'font-family':'Poppins, sans-serif','font-weight':600,fill:c});e.textContent=t};
  if(bleed){mk('path',{d:`M0 0H${W}V${H}H0Z M${bx} ${by}V${by+th}H${bx+tw}V${by}Z`,'fill-rule':'evenodd',fill:'rgba(224,33,138,.10)'});
    mk('rect',{x:.15,y:.15,width:W-.3,height:H-.3,fill:'none',stroke:'#e0218a','stroke-width':.3,'stroke-dasharray':'1.2 .8'});
    label(W-.4,.4,`Aplat avec fond perdu ${mmFmt(W)} × ${mmFmt(H)}`,'#e0218a',true)}
  mk('rect',{x:bx,y:by,width:tw,height:th,fill:'none',stroke:'#0891b2','stroke-width':.3});
  label(bx+.5,by+.5,`Carte finie ${T.label} ${mmFmt(r2(tw))} × ${mmFmt(r2(th))}`,'#0891b2');
  svg.appendChild(g);S._trimBox=[bx,by,tw,th]}
$('#trimSel').addEventListener('change',()=>{try{localStorage.setItem('planche.trim',$('#trimSel').value)}catch(x){}drawOverlay();syncSheetInputs();drawSheet()});
function svgPt(ev){const svg=$('#ov');const pt=svg.createSVGPoint();pt.x=ev.clientX;pt.y=ev.clientY;return pt.matrixTransform(svg.getScreenCTM().inverse())}
const snap=v=>Math.round(v*20)/20;
/* Aimantation + repères (comme Illustrator) : bords/centre de la carte et bords/centres des autres éléments. Alt = sans aimant. */
/* alignement du texte : e.x = ancre (bord gauche, centre ou bord droit) ; w = largeur de la ligne dans l'unité voulue */
const alOff=(e,w)=>e.align==='center'?-w/2:e.align==='right'?-w:0;
function boxOf(e){if(e.type==='qr'){const G=qrGeom(e);return[e.x,e.y,G.w,G.h]}return e._box||[e.x,e.y,5,3]}
function snapMove(e,bx,by){
  const W=S.sheet.cardW,H=S.sheet.cardH,b=boxOf(e),w=b[2],h=b[3];
  const k=$('#ov').getScreenCTM(),thr=6/(k?k.a:4);/* 6 px écran */
  const tx=[0,W/2,W],ty=[0,H/2,H];if(S._trimBox){const[a,b2,c,d]=S._trimBox;tx.push(a,a+c);ty.push(b2,b2+d)}
  S.els.forEach(o=>{if(o===e)return;const q=boxOf(o);tx.push(q[0],q[0]+q[2]/2,q[0]+q[2]);ty.push(q[1],q[1]+q[3]/2,q[1]+q[3])});
  const best=(pos,size,targets)=>{let d=null,t=null;for(const off of [0,size/2,size])for(const g of targets){const diff=g-(pos+off);if(Math.abs(diff)<=thr&&(d===null||Math.abs(diff)<Math.abs(d))){d=diff;t=g}}return d===null?null:{d,t}};
  const sx=best(bx,w,tx),sy=best(by,h,ty),guides=[];
  if(sx){bx+=sx.d;guides.push({v:1,p:sx.t})}
  if(sy){by+=sy.d;guides.push({v:0,p:sy.t})}
  return{x:r2(bx),y:r2(by),guides};
}
$('#ov').addEventListener('pointerdown',ev=>{
  const g=ev.target.closest('[data-id]');if(!g){select(null);return}
  const e=byId(g.dataset.id);if(S.sel!==e.id){S.sel=e.id;renderList();renderForm()}
  if(!ev.target.dataset.handle)showTip();
  const p=svgPt(ev);const sh=e.type==='text'?effY(e,curRow())-e.y:0;drag={e,shift:sh,dx:p.x-e.x,dy:p.y-e.y-sh,resize:!!ev.target.dataset.handle};try{$('#ov').setPointerCapture(ev.pointerId)}catch(x){}
  drawOverlay();ev.preventDefault()});
$('#ov').addEventListener('pointermove',ev=>{if(!drag)return;const p=svgPt(ev),e=drag.e;
  if(drag.resize){const G=qrGeom(e);const k=Math.max((p.x-e.x)/(G.w/e.size),(p.y-e.y)/(G.h/e.size));e.size=Math.max(8,Math.round(k*20)/20)}else{const sh=drag.shift||0;let nx=snap(p.x-drag.dx),ny=snap(p.y-drag.dy-sh);guides=[];
    if(!ev.altKey){const bo=boxOf(e)[0]-e.x,r=snapMove(e,nx+bo,ny+sh);nx=r2(r.x-bo);ny=r.y-sh;guides=r.guides}
    e.x=nx;e.y=ny}
  S.elsAreDemo=false;drawOverlay();syncPos(e)});
const endDrag=()=>{if(drag){drag=null;guides=[];drawOverlay();renderForm()}};
$('#ov').addEventListener('pointerup',endDrag);$('#ov').addEventListener('pointercancel',endDrag);
function syncPos(e){const ins=[...document.querySelectorAll('#editor input[type=number]')];/* champs X/Y/Côté suivent le glisser */}
document.addEventListener('keydown',ev=>{
  const e=byId(S.sel);if(!e||/INPUT|SELECT|TEXTAREA/.test(document.activeElement.tagName))return;
  const st=ev.shiftKey?1:.1;let h=true;
  if(ev.key==='ArrowLeft')e.x=r2(e.x-st);else if(ev.key==='ArrowRight')e.x=r2(e.x+st);else if(ev.key==='ArrowUp')e.y=r2(e.y-st);else if(ev.key==='ArrowDown')e.y=r2(e.y+st);else h=false;
  if(h){ev.preventDefault();S.elsAreDemo=false;renderForm();drawOverlay()}});

/* ---------- planche : champs + schéma ---------- */
const SHEET_FIELDS=[['pageW','Page larg. (mm)'],['pageH','Page haut. (mm)'],['cols','Colonnes'],['rows','Lignes'],['cardW','Carte larg. (mm)'],['cardH','Carte haut. (mm)'],['gapX','Écart X (mm)'],['gapY','Écart Y (mm)'],['mL','Marge gauche (mm)'],['mT','Marge haut (mm)'],['mR','Marge droite (mm)'],['mB','Marge bas (mm)'],['finW','Carte finie larg. (mm)'],['finH','Carte finie haut. (mm)'],['bL','Fond perdu gauche (mm)'],['bR','Fond perdu droite (mm)'],['bT','Fond perdu haut (mm)'],['bB','Fond perdu bas (mm)']];
/* marges droite / bas : calculées (page − marge opposée − grille) ; les modifier décale les cartes */
const sheetVal=k=>k==='finW'?S.sheet.cardW-trimBleed().l-trimBleed().r:k==='finH'?S.sheet.cardH-trimBleed().t-trimBleed().b:k==='mR'?S.sheet.pageW-S.sheet.mL-gridW():k==='mB'?S.sheet.pageH-S.sheet.mT-gridH():k==='bL'?trimBleed().l:k==='bR'?trimBleed().r:k==='bT'?trimBleed().t:k==='bB'?trimBleed().b:S.sheet[k];
const AXES={x:{page:'pageW',n:'cols',card:'cardW',gap:'gapX',m1:'mL',m2:'mR',grid:()=>gridW(),lab:['gauche','droite']},y:{page:'pageH',n:'rows',card:'cardH',gap:'gapY',m1:'mT',m2:'mB',grid:()=>gridH(),lab:['haut','bas']}};
const AXIS_OF=k=>['pageW','cols','cardW','gapX','mL','mR'].includes(k)?'x':['pageH','rows','cardH','gapY','mT','mB'].includes(k)?'y':null;
const fieldLabel=k=>(SHEET_FIELDS.find(f=>f[0]===k)||[k,k])[1];
/* applique une mesure en respectant le mode d'ajustement : seule la mesure choisie « s'ajuste », les autres ne bougent pas */
function setSheetVal(k,v){const s=S.sheet,ax=AXIS_OF(k),mode=s.adjust||'marge';
  /* la carte finie est la référence : le fond perdu s'AJOUTE autour (aplat = carte finie + fond perdu) */
  if(/^b[LRTB]$/.test(k)||k==='finW'||k==='finH'){const B=trimBleed(),fw=s.cardW-B.l-B.r,fh=s.cardH-B.t-B.b;
    s.bleedL=B.l;s.bleedR=B.r;s.bleedT=B.t;s.bleedB=B.b;delete s.bleedX;delete s.bleedY;try{localStorage.setItem('planche.trim','auto')}catch(x){}
    if(k==='finW')return setSheetVal('cardW',r2(Math.max(1,v)+B.l+B.r));if(k==='finH')return setSheetVal('cardH',r2(Math.max(1,v)+B.t+B.b));
    s['bleed'+k[1]]=Math.max(0,v);if(k==='bL'||k==='bR')return setSheetVal('cardW',r2(fw+s.bleedL+s.bleedR));return setSheetVal('cardH',r2(fh+s.bleedT+s.bleedB))}
  if(!ax){s[k]=v;return}
  const A=AXES[ax],m2Old=s[A.page]-s[A.m1]-A.grid();
  if(k===A.n)v=Math.max(1,Math.round(v));
  const gapFor=(m1,m2)=>s[A.n]>1?(s[A.page]-m1-m2-s[A.n]*s[A.card])/(s[A.n]-1):s[A.gap];
  if(mode==='centre'){
    if(k===A.m1||k===A.m2){s[A.m1]=v;s[A.gap]=r2(gapFor(v,v));if(s[A.n]<=1)s[A.m1]=r2((s[A.page]-A.grid())/2)}
    else{s[k]=v;s[A.m1]=r2((s[A.page]-A.grid())/2)}}
  else if(mode==='ecart'){
    if(k===A.gap)s[k]=v;
    else if(k===A.m2){if(s[A.n]>1)s[A.gap]=r2(gapFor(s[A.m1],v));else s[A.m1]=r2(s[A.page]-v-A.grid())}
    else{s[k]=v;if(s[A.n]>1)s[A.gap]=r2(gapFor(s[A.m1],m2Old))}}
  else{if(k===A.m2)s[A.m1]=r2(s[A.page]-v-A.grid());else s[k]=v}}
function buildSheetInputs(){
  const c=$('#sheetInputs');c.innerHTML='';const adj=$('#adjSel');if(adj)adj.value=S.sheet.adjust||'marge';
  c.innerHTML=`<div class="bm">
    <div class="bm-h">Page <span data-f="pageW"></span> × <span data-f="pageH"></span> <small>mm (largeur × hauteur)</small></div>
    <div class="bm-page">
      <label class="mi mt">Marge haut<span data-f="mT"></span></label>
      <label class="mi ml">Marge<br>gauche<span data-f="mL"></span></label>
      <div class="bm-grid">
        <div class="bm-g2"><label class="mi">Colonnes<span data-f="cols"></span></label><label class="mi">Lignes<span data-f="rows"></span></label>
        <label class="mi gap">Écart ↔<span data-f="gapX"></span></label><label class="mi gap">Écart ↕<span data-f="gapY"></span></label></div>
        <div>cartes avec fond perdu (aplat) : <b class="bmAplat"></b> mm</div>
      </div>
      <label class="mi mr">Marge<br>droite<span data-f="mR"></span></label>
      <label class="mi mb">Marge bas<span data-f="mB"></span></label>
    </div>
    <div class="bm-h">Carte finie + fond perdu <small>= aplat <b class="bmAplat"></b> mm (le fond perdu s'ajoute autour de la carte finie et part à la découpe)</small></div>
    <div class="bm-card">
      <label class="mi bt">haut<span data-f="bT"></span></label>
      <label class="mi bl">gauche<span data-f="bL"></span></label>
      <div class="bm-fin">Carte finie<div class="row" style="gap:4px;justify-content:center;flex-wrap:nowrap"><span data-f="finW"></span>×<span data-f="finH"></span></div>mm</div>
      <label class="mi br">droite<span data-f="bR"></span></label>
      <label class="mi bb">bas<span data-f="bB"></span></label>
    </div></div>`;
  c.querySelectorAll('[data-f]').forEach(slot=>{const k=slot.dataset.f;const i=document.createElement('input');i.type='number';i.id='sh_'+k;i.step=(k==='cols'||k==='rows')?'1':'0.1';i.min=(k==='cols'||k==='rows')?'1':'0';i.value=r2(sheetVal(k));i.title=fieldLabel(k);
    i.oninput=()=>applySheetEdit(k,num(i.value,sheetVal(k)),i);slot.replaceWith(i)});
  updateFinie()}
function updateFinie(){const s=S.sheet;document.querySelectorAll('.bmAplat').forEach(e=>{e.textContent=`${mmFmt(r2(s.cardW))} × ${mmFmt(r2(s.cardH))}`})}
/* applique une mesure (champ ou cote cliquée), met à jour les autres champs et signale ce qui a bougé */
function applySheetEdit(k,v,src){const before={};SHEET_FIELDS.forEach(([k2])=>before[k2]=r2(sheetVal(k2)));
  setSheetVal(k,v);const moved=[];
  SHEET_FIELDS.forEach(([k2])=>{const j=$('#sh_'+k2),nv=r2(sheetVal(k2));if(j&&j!==src){j.value=nv;if(k2!==k&&Math.abs(nv-before[k2])>.001&&!/^b[LRTB]$/.test(k2)){moved.push(fieldLabel(k2).replace(/\s*\(mm\)/,''));j.classList.add('auto');clearTimeout(j._t);j._t=setTimeout(()=>j.classList.remove('auto'),1400)}}});
  const an=$('#adjNote');if(an){an.className='note';an.textContent=moved.length?'Ajusté automatiquement : '+moved.join(', ').toLowerCase()+'.':''}
  updateFinie();sheetInfo();drawSheet();if(/^(cardW|cardH|fin[WH]|b[LRTB])$/.test(k)){drawArt();drawOverlay()}}
$('#adjSel').onchange=e=>{S.sheet.adjust=e.target.value;const an=$('#adjNote');if(an)an.textContent={marge:'La marge droite / bas s\'ajuste quand une autre mesure change.',ecart:'Les marges restent fixes : les écarts entre cartes s\'ajustent.',centre:'La planche reste centrée : les deux marges s\'ajustent (en modifiant une marge, ce sont les écarts qui s\'ajustent).'}[e.target.value];
  if(e.target.value==='centre'){S.sheet.mL=r2((S.sheet.pageW-gridW())/2);S.sheet.mT=r2((S.sheet.pageH-gridH())/2);syncSheetInputs()}sheetInfo();drawSheet();try{renderFormats()}catch(x){}};
function syncSheetInputs(){setTimeout(updateFinie);const adj=document.getElementById('adjSel');if(adj)adj.value=S.sheet.adjust||'marge';const fs=document.getElementById('fillSel');if(fs)fs.value=S.sheet.fillEnd?'end':'start';SHEET_FIELDS.forEach(([k])=>{const i=$('#sh_'+k);if(i)i.value=r2(sheetVal(k))})}
const gridW=()=>S.sheet.cols*S.sheet.cardW+(S.sheet.cols-1)*S.sheet.gapX;
const gridH=()=>S.sheet.rows*S.sheet.cardH+(S.sheet.rows-1)*S.sheet.gapY;
function sheetInfo(){try{renderFormats()}catch(e){}
  const s=S.sheet,rm=s.pageW-s.mL-gridW(),bm=s.pageH-s.mT-gridH(),n=$('#sheetNote');
  const bad=rm<-.01||bm<-.01||s.mL<0||s.mT<0||s.gapX<0||s.gapY<0;
  n.className='note '+(bad?'bad':'ok');
  n.textContent=`${s.cols*s.rows} cartes par planche · marge droite ${mmFmt(rm)} mm · marge bas ${mmFmt(bm)} mm`+(bad?(s.gapX<0||s.gapY<0?' · écart négatif : les cartes se chevauchent':' · les cartes dépassent de la page'):'');
  /* dimensions affichées par drawTrimGuides (aplat / carte finie) */
  updateInfo()}
function updateInfo(){try{renderNaming()}catch(e){}const per=S.sheet.cols*S.sheet.rows,n=S.data.rows.length;$('#genInfo').textContent=`${n} carte${n>1?'s':''} · ${Math.max(1,Math.ceil(n/per))} planche${Math.ceil(n/per)>1?'s':''} · ${per} par planche`;updateStatus()}
function updateStatus(){const ul=document.getElementById('status');if(!ul)return;const items=[];const add=(k,html)=>items.push(`<li class="${k}"><i>${k==='ok'?'✓':'!'}</i><span>${html}</span></li>`);
  const esc=t=>String(t).replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
  const f=(typeof allFormats==='function')?allFormats().find(x=>x.id===S.fmtId):null;
  add('ok',`<b>Format</b> : ${esc(f?f.label:'personnalisé')}`);
  if(S.art.demo)add('warn','<b>Carte</b> : carte d\'exemple, ouvre ta carte (étape 1)');else add('ok',`<b>Carte</b> : ${esc(S.art.name.replace(/\s*\(nettoy\S*\)/,''))}`);
  if(S.data.demo)add('warn','<b>Données</b> : lignes d\'exemple, ouvre ton Excel ou CSV (étape 2)');else add('ok',`<b>Données</b> : ${S.data.rows.length} ligne${S.data.rows.length>1?'s':''} (${esc(S.data.name)})`);
  const miss=new Set();S.els.forEach(e=>{if(e.type==='qr'){if(!hasCol(e.col))miss.add(e.col)}else tplMissing(e.tpl).forEach(k=>miss.add(k))});
  if(miss.size)add('bad',`<b>Colonnes introuvables</b> : ${esc([...miss].join(', '))} — choisis ci-dessous la colonne à utiliser`);else if(!S.data.demo)add('ok','<b>Champs</b> : chaque champ trouve sa colonne');
  {const bad=[...new Set(S.els.filter(e=>!fontOk(e)).map(e=>e.fontLabel||e.fontPs))];const used=[...new Set(S.els.filter(e=>e.type==='text').map(e=>fontById(e.font).label))];
    if(bad.length){const rp=[...new Set(S.els.filter(e=>!fontOk(e)).map(e=>fontById(e.font).label))];add('warn',`<b>Polices</b> : ta carte utilise ${esc(bad.join(', '))}, absente${bad.length>1?'s':''} de ce poste ; remplacée${bad.length>1?'s':''} par ${esc(rp.join(', '))} (le rendu sera différent).<span class="act"><label class="btn sm" for="fontIn" tabindex="0">Ajouter le fichier de police…</label><button class="btn sm" data-act="pickfont">Choisir une police installée…</button></span>`)}else if(used.length)add('ok',`<b>Polices</b> : ${esc(used.join(', '))}`)}
  {const ov=S.els.map(e=>[e,overflowOf(e)]).filter(x=>x[1]);if(ov.length)add('warn',`<b>Textes trop longs</b> : ${esc(ov.map(([e,o])=>'« '+(e.name||'Texte')+' » ('+o.n+' carte'+(o.n>1?'s':'')+')').join(', '))} — choisis une solution sous l'aperçu de la carte`)}
  const q=S.els.find(e=>e.type==='qr');
  if(!q)add('warn','<b>QR</b> : aucun QR sur la carte');else{const empty=S.data.rows.filter(r=>!applyTpl('{'+q.col+'}',r).trim()).length;if(empty)add('bad',`<b>QR</b> : lien vide pour ${empty} ligne${empty>1?'s':''}`);else add('ok',`<b>QR</b> : ${S.data.rows.length} code${S.data.rows.length>1?'s':''} (${esc(QS[q.style]?QS[q.style].label:'')})`)}
  ul.innerHTML=items.join('');{const pb=ul.querySelector('[data-act=pickfont]');if(pb)pb.onclick=()=>{const e=S.els.find(x=>!fontOk(x));if(e)openFontPicker('Police pour « '+(e.name||'texte')+' »'+(e.fontLabel?' (demandée : '+e.fontLabel+')':''),f=>applyFontChoice(e,f),(e.fontLabel||'').split(' ')[0])}}
  {let mb=document.getElementById('mapStatus');if(!mb){mb=document.createElement('div');mb.id='mapStatus';mb.className='mapq';ul.after(mb)}renderMap(mb,miss);renderMap(document.getElementById('mapData'),miss)}
  refreshSteps();refreshGenState(items)}
/* colonne introuvable : on demande quelle colonne du fichier utiliser */
function renderMap(box,miss){if(!box)return;box.innerHTML='';if(S.data.demo)return;
  const h=t=>String(t).replace(/[&<>"]/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[ch]));
  [...miss].forEach(k=>{const l=document.createElement('label');l.textContent=`Quelle colonne utiliser pour « ${k} » ?`;const sel=document.createElement('select');
    sel.innerHTML='<option value="">Choisir une colonne…</option>'+S.data.cols.map(c=>`<option value="${h(c)}">${h(c)}</option>`).join('')+'<option value="__none">Ne rien afficher à cet endroit</option>';
    sel.onchange=()=>{const v=sel.value;if(!v)return;const kn=norm(k);
      S.els.forEach(e=>{if(e.type==='qr'){if(norm(e.col)===kn&&v!=='__none')e.col=v}else e.tpl=e.tpl.replace(/\{([^}|]+?)(\|\w+)?\}/g,(m,kk,f)=>norm(kk)!==kn?m:v==='__none'?'':'{'+v+(f||'')+'}').replace(/\s{2,}/g,' ').trim()});
      S.elsAreDemo=false;renderList();renderForm();drawAll();drawArt().then(drawOverlay);reportMissing()};
    l.appendChild(sel);box.appendChild(l)})}
/* état des étapes : fait / à faire, et mise en avant de l'étape en cours */
function refreshSteps(){const set=(id,ok,txt)=>{const e=document.getElementById(id);if(e){e.className='st '+(ok?'ok':'todo');e.textContent=txt}};
  set('stArt',!S.art.demo,S.art.demo?'à faire':'✓ fait');set('stData',!S.data.demo,S.data.demo?'à faire':'✓ fait');
  const cur=S.art.demo?'stepArt':S.data.demo?'stepData':'stepFmt';['stepArt','stepData','stepFmt'].forEach(id=>{const e=document.getElementById(id);if(e)e.classList.toggle('cur',id===cur)})}
/* bouton Générer : bloqué en mode démo ; sinon affiche le nombre de points à vérifier */
let genBusy=false;
function refreshGenState(items){
  const demo=S.art.demo||S.data.demo,bad=items.filter(h=>h.startsWith('<li class="bad"')).length,warn=items.filter(h=>h.startsWith('<li class="warn"')).length;
  const ban=$('#demoBanner');if(ban){ban.hidden=!demo;$('#demoText').innerHTML=S.art.demo&&S.data.demo?'<b>Mode démonstration</b> : la carte et les noms affichés sont des exemples. Ouvre ta carte (étape 1) puis ton Excel ou CSV (étape 2) pour pouvoir générer la planche.':S.art.demo?'<b>Carte d\'exemple</b> : ouvre ta carte (étape 1) pour pouvoir générer la planche.':'<b>Noms d\'exemple</b> : ouvre ton Excel ou CSV (étape 2) pour pouvoir générer la planche.'}
  const tip=demo?'Ouvre d\'abord ta carte et ton fichier de données':'';
  ['#gen','#genTop'].forEach(id=>{const b=$(id);if(!b||genBusy)return;b.disabled=demo;b.title=tip;
    b.innerHTML='Générer la planche'+(!demo&&(bad||warn)?`<span class="gen-badge${bad?' bad':''}">${bad+warn} point${bad+warn>1?'s':''} à vérifier</span>`:'')})}
function genIssues(){return[...document.querySelectorAll('#status li.bad span,#status li.warn span')].map(x=>'• '+x.textContent)}
$('#genTop').onclick=()=>$('#gen').click();
const goRow=d=>{const n=S.data.rows.length;if(!n)return;S.rowIdx=(S.rowIdx+d+n)%n;$('#rowSel').value=S.rowIdx;drawAll();drawArt()};
$('#rowPrev').onclick=()=>goRow(-1);$('#rowNext').onclick=()=>goRow(1);
function drawSheet(){
  const s=S.sheet,svg=$('#sheetSvg');if(!svg)return;const opt=k=>{const e=document.getElementById(k);return!e||e.checked};
  const dims=opt('shDims'),showArt=opt('shArt'),showTrim=opt('shTrim');
  const zf=drawSheet.z||1,fs=Math.max(5,s.pageW/30)/Math.pow(zf,.75),pad=dims?Math.max(5,s.pageW/30)*3:fs*.6;
  svg.setAttribute('viewBox',`${-pad} ${-pad} ${s.pageW+2*pad} ${s.pageH+2*pad}`);svg.style.aspectRatio=`${s.pageW+2*pad}/${s.pageH+2*pad}`;svg.innerHTML='';
  const css=getComputedStyle(document.documentElement);const acc=css.getPropertyValue('--accent').trim()||'#50A6E1',ink=css.getPropertyValue('--ink').trim()||'#131a30';
  const MAG='#e0218a',GAP='#059669',CUT='#0891b2',sw=s.pageW/400;
  const mk=(tag,at,parent)=>{const e=document.createElementNS(NS,tag);for(const k in at)e.setAttribute(k,at[k]);(parent||svg).appendChild(e);return e};
  const txt=(x,y,t,c,rot,size)=>{const e=mk('text',{x,y,'font-size':size||fs,'font-family':'Poppins, sans-serif','font-weight':600,fill:c,'text-anchor':'middle','dominant-baseline':'central',stroke:'#fff','stroke-width':(size||fs)*.25,'paint-order':'stroke'});if(rot)e.setAttribute('transform',`rotate(-90 ${x} ${y})`);e.textContent=t;return e};
  /* cote : trait avec flèches + valeur */
  const dim=(x1,y1,x2,y2,c,label,off,rot,key)=>{const L=Math.hypot(x2-x1,y2-y1);if(L<.01)return;
    mk('line',{x1,y1,x2,y2,stroke:c,'stroke-width':sw*1.2});const hx=(x2-x1)/L*fs*.45,hy=(y2-y1)/L*fs*.45,px=-hy*.6,py=hx*.6;
    mk('path',{d:`M${x1} ${y1}l${hx+px} ${hy+py}M${x1} ${y1}l${hx-px} ${hy-py}M${x2} ${y2}l${-hx+px} ${-hy+py}M${x2} ${y2}l${-hx-px} ${-hy-py}`,stroke:c,'stroke-width':sw*1.2,fill:'none'});
    const mx=(x1+x2)/2,my=(y1+y2)/2,vert=Math.abs(x2-x1)<Math.abs(y2-y1);const t=txt(mx+(vert?(off||0):0),my+(vert?0:(off||0)),label,c,!!rot);if(key){t.dataset.k=key;t.classList.add('dimlbl');const ti=document.createElementNS(NS,'title');ti.textContent='Cliquer pour modifier';t.appendChild(ti)}};
  const f=v=>mmFmt(r2(v));
  mk('rect',{x:0,y:0,width:s.pageW,height:s.pageH,fill:'#fff',stroke:ink,'stroke-width':sw*1.5});
  const per0=s.cols*s.rows,n=Math.min(S.data.rows.length,per0),filled=new Set();for(let i=0;i<n;i++)filled.add(slotOf(i,S.data.rows.length,per0));
  const url=showArt?artUrl():null,B=trimBleed(),bx=B.l,by=B.t,hasB=B.l+B.r+B.t+B.b>.05,fw=s.cardW-B.l-B.r,fh=s.cardH-B.t-B.b;
  const X=c=>s.mL+c*(s.cardW+s.gapX),Y=r=>s.mT+r*(s.cardH+s.gapY);
  for(let r=0;r<s.rows;r++)for(let c=0;c<s.cols;c++){const i=r*s.cols+c,x=X(c),y=Y(r),on=filled.has(i);
    if(url){const im=mk('image',{x,y,width:s.cardW,height:s.cardH,preserveAspectRatio:'none',opacity:on?1:.3});im.setAttribute('href',url)}
    const sr=mk('rect',{x,y,width:s.cardW,height:s.cardH,fill:url?'none':acc,'fill-opacity':url?0:(on?.55:.08),stroke:acc,'stroke-width':sw,'stroke-dasharray':on?'0':`${fs*.5} ${fs*.3}`,'pointer-events':'all'});
    {const t=document.createElementNS(NS,'title');t.textContent=`Carte ${i+1} (ligne ${r+1}, colonne ${c+1})
Aplat : x ${f(x)} → ${f(x+s.cardW)} mm · y ${f(y)} → ${f(y+s.cardH)} mm`+(hasB?`
Coupe : x ${f(x+B.l)} → ${f(x+s.cardW-B.r)} mm · y ${f(y+B.t)} → ${f(y+s.cardH-B.b)} mm`:'')+(on?'':'\n(emplacement vide sur la dernière planche)');sr.appendChild(t)}
    if(showTrim&&hasB)mk('rect',{x:x+B.l,y:y+B.t,width:fw,height:fh,fill:'none',stroke:CUT,'stroke-width':sw})}
  if(!dims)return;
  const rm=s.pageW-s.mL-gridW(),bm=s.pageH-s.mT-gridH(),cy=Y(0)+s.cardH/2,cx=X(0)+s.cardW/2,lx=X(s.cols-1)+s.cardW/2,ly=Y(s.rows-1)+s.cardH/2;
  /* page */
  dim(0,-pad*.55,s.pageW,-pad*.55,ink,`Page ${f(s.pageW)} mm`,-fs*.9,false,'pageW');dim(-pad*.55,0,-pad*.55,s.pageH,ink,`${f(s.pageH)} mm`,-fs*.9,true,'pageH');
  /* marges */
  dim(0,cy,s.mL,cy,s.mL<0?'#dc2626':MAG,f(s.mL),-fs*.8,false,'mL');dim(s.pageW-rm,ly,s.pageW,ly,rm<0?'#dc2626':MAG,f(rm),-fs*.8,false,'mR');
  dim(cx,0,cx,s.mT,s.mT<0?'#dc2626':MAG,f(s.mT),fs*1.4,false,'mT');dim(lx,s.pageH-bm,lx,s.pageH,bm<0?'#dc2626':MAG,f(bm),fs*1.4,false,'mB');
  /* écarts */
  if(s.cols>1&&s.gapX>0)dim(X(0)+s.cardW,Y(0)+s.cardH*.25,X(1),Y(0)+s.cardH*.25,GAP,f(s.gapX),-fs*.8,false,'gapX');else if(s.cols>1)txt(X(1)-s.gapX/2,Y(0)+s.cardH*.25,'0',GAP,false,fs*.8);
  if(s.rows>1&&s.gapY>0)dim(X(0)+s.cardW*.25,Y(0)+s.cardH,X(0)+s.cardW*.25,Y(1),GAP,f(s.gapY),fs*1.4,false,'gapY');
  /* jusqu'à la coupe (carte finie) : marges et écarts réels entre cartes coupées */
  if(showTrim&&hasB){const o=fs*1.9;
    dim(0,cy+o,s.mL+B.l,cy+o,CUT,f(s.mL+B.l),-fs*.8,false,'cutL');dim(s.pageW-rm-B.r,ly+o,s.pageW,ly+o,CUT,f(rm+B.r),-fs*.8,false,'cutR');
    dim(cx+o*1.6,0,cx+o*1.6,s.mT+B.t,CUT,f(s.mT+B.t),fs*1.4,false,'cutT');dim(lx+o*1.6,s.pageH-bm-B.b,lx+o*1.6,s.pageH,CUT,f(bm+B.b),fs*1.4,false,'cutB');
    if(s.cols>1)dim(X(0)+s.cardW-B.r,Y(0)+s.cardH*.75,X(1)+B.l,Y(0)+s.cardH*.75,CUT,f(s.gapX+B.l+B.r),-fs*.8,false,'cutGapX');
    if(s.rows>1)dim(X(0)+s.cardW*.75,Y(0)+s.cardH-B.b,X(0)+s.cardW*.75,Y(1)+B.t,CUT,f(s.gapY+B.t+B.b),fs*1.4,false,'cutGapY')}
  /* carte (emplacement / aplat) et carte finie */
  {const t=txt(cx,cy-fs*.6,`carte ${f(s.cardW)} × ${f(s.cardH)}`,'#2F86C4',false,fs*.8);t.dataset.k='card';t.classList.add('dimlbl')}
  if(showTrim&&hasB){const t=txt(cx,cy+fs*.5,`finie ${f(fw)} × ${f(fh)}`,CUT,false,fs*.7);t.dataset.k='bleed';t.classList.add('dimlbl')}
}
/* clic sur une cote du schéma : petite fenêtre pour modifier la mesure */
const MEAS={pageW:['Largeur de page',[['pageW','mm']]],pageH:['Hauteur de page',[['pageH','mm']]],mL:['Marge gauche (jusqu\'à l\'aplat)',[['mL','mm']]],mR:['Marge droite (jusqu\'à l\'aplat)',[['mR','mm']]],
  mT:['Marge haut (jusqu\'à l\'aplat)',[['mT','mm']]],mB:['Marge bas (jusqu\'à l\'aplat)',[['mB','mm']]],gapX:['Écart horizontal entre aplats',[['gapX','mm']]],gapY:['Écart vertical entre aplats',[['gapY','mm']]],
  card:['Carte avec fond perdu (aplat)',[['cardW','largeur'],['cardH','hauteur']]],bleed:['Carte finie et fond perdu (ajouté autour)',[['finW','finie larg.'],['finH','finie haut.'],['bL','gauche'],['bR','droite'],['bT','haut'],['bB','bas']]],
  cutL:['Marge gauche jusqu\'à la coupe',[['cutL','mm']]],cutR:['Marge droite jusqu\'à la coupe',[['cutR','mm']]],cutT:['Marge haut jusqu\'à la coupe',[['cutT','mm']]],cutB:['Marge bas jusqu\'à la coupe',[['cutB','mm']]],
  cutGapX:['Écart horizontal entre cartes finies',[['cutGapX','mm']]],cutGapY:['Écart vertical entre cartes finies',[['cutGapY','mm']]]};
function measGet(k){const B=trimBleed();return k==='cutL'?sheetVal('mL')+B.l:k==='cutR'?sheetVal('mR')+B.r:k==='cutT'?sheetVal('mT')+B.t:k==='cutB'?sheetVal('mB')+B.b:k==='cutGapX'?S.sheet.gapX+B.l+B.r:k==='cutGapY'?S.sheet.gapY+B.t+B.b:sheetVal(k)}
function measSet(k,v){const B=trimBleed();const map={cutL:['mL',v-B.l],cutR:['mR',v-B.r],cutT:['mT',v-B.t],cutB:['mB',v-B.b],cutGapX:['gapX',v-B.l-B.r],cutGapY:['gapY',v-B.t-B.b]};const[kk,vv]=map[k]||[k,v];applySheetEdit(kk,r2(vv),null)}
function openMeasEdit(key,x,y){const M=MEAS[key];if(!M)return;let p=document.getElementById('measPop');if(p)p.remove();p=document.createElement('div');p.id='measPop';
  p.innerHTML=`<b style="font-size:12.5px">${M[0]}</b><div class="row">${M[1].map(([k,l])=>`<label class="f">${l}<input type="number" step="0.1" data-k="${k}" value="${r2(measGet(k))}"></label>`).join('')}</div><div class="row"><button class="btn sm primary">OK</button><button class="btn sm">Annuler</button></div>`;
  document.body.appendChild(p);const W=p.offsetWidth,H=p.offsetHeight;p.style.left=Math.max(8,Math.min(innerWidth-W-8,x-W/2))+'px';p.style.top=Math.max(8,Math.min(innerHeight-H-8,y+12))+'px';
  const ins=[...p.querySelectorAll('input')];ins[0].focus();ins[0].select();
  const ok=()=>{ins.forEach(i=>{const v=num(i.value,NaN);if(isFinite(v)&&Math.abs(v-measGet(i.dataset.k))>.0001)measSet(i.dataset.k,v)});p.remove()};
  const[bOk,bNo]=p.querySelectorAll('button');bOk.onclick=ok;bNo.onclick=()=>p.remove();
  p.addEventListener('keydown',ev=>{if(ev.key==='Enter'){ev.preventDefault();ok()}else if(ev.key==='Escape'){ev.stopPropagation();p.remove()}})}
$('#sheetSvg').addEventListener('click',ev=>{const t=ev.target.closest('[data-k]');if(t)openMeasEdit(t.dataset.k,ev.clientX,ev.clientY)});
document.addEventListener('pointerdown',ev=>{const p=document.getElementById('measPop');if(p&&!p.contains(ev.target)&&!ev.target.closest('[data-k]'))p.remove()});
/* zoom / déplacement / plein écran du schéma */
let sheetZ=1;function applyZoom(){const svg=$('#sheetSvg');if(!svg)return;svg.style.width=(100*sheetZ)+'%';if(drawSheet.z!==sheetZ){drawSheet.z=sheetZ;drawSheet()}const z=$('#zVal');if(z)z.textContent=Math.round(sheetZ*100)+' %'}
function zoomAt(f,cx,cy){const box=$('#sheetZoom');if(!box)return;const r=box.getBoundingClientRect(),px=(cx==null?r.width/2:cx-r.left)+box.scrollLeft,py=(cy==null?r.height/2:cy-r.top)+box.scrollTop;
  const z0=sheetZ;sheetZ=Math.min(8,Math.max(1,r2(sheetZ*f)));applyZoom();const k=sheetZ/z0;box.scrollLeft=px*k-(px-box.scrollLeft);box.scrollTop=py*k-(py-box.scrollTop)}
$('#zIn').onclick=()=>zoomAt(1.4);$('#zOut').onclick=()=>zoomAt(1/1.4);$('#zFit').onclick=()=>{sheetZ=1;applyZoom()};
$('#zFull').onclick=()=>{const c=$('#sheetZoom').closest('.sheetcol');const on=c.classList.toggle('full');$('#zFull').textContent=on?'✕ Fermer':'⛶ Plein écran';if(!on){sheetZ=1;applyZoom()}};
document.addEventListener('keydown',ev=>{if(ev.key==='Escape'){const c=document.querySelector('.sheetcol.full');if(c){c.classList.remove('full');$('#zFull').textContent='⛶ Plein écran'}}});
{const box=$('#sheetZoom');box.addEventListener('wheel',ev=>{if(!ev.ctrlKey)return;ev.preventDefault();zoomAt(ev.deltaY<0?1.15:1/1.15,ev.clientX,ev.clientY)},{passive:false});
  let d=null;box.addEventListener('pointerdown',ev=>{if(sheetZ<=1)return;d={x:ev.clientX,y:ev.clientY,l:box.scrollLeft,t:box.scrollTop};box.classList.add('drag')});
  window.addEventListener('pointermove',ev=>{if(!d)return;box.scrollLeft=d.l-(ev.clientX-d.x);box.scrollTop=d.t-(ev.clientY-d.y)});
  window.addEventListener('pointerup',()=>{d=null;box.classList.remove('drag')});
  box.addEventListener('dblclick',ev=>zoomAt(2,ev.clientX,ev.clientY))}
['shDims','shArt','shTrim'].forEach(id=>{const e=document.getElementById(id);if(!e)return;try{const v=localStorage.getItem('planche.'+id);if(v!=null)e.checked=v==='1'}catch(x){}
  e.onchange=()=>{try{localStorage.setItem('planche.'+id,e.checked?'1':'0')}catch(x){}drawSheet()}});
$('#fillSel').onchange=e=>{S.sheet.fillEnd=e.target.value==='end';drawSheet();renderFormats()};
$('#fitSel').onchange=e=>{S.fit=e.target.value;drawArt().then(drawOverlay)};
$('#centerX').onclick=()=>{S.sheet.mL=r2((S.sheet.pageW-gridW())/2);syncSheetInputs();sheetInfo();drawSheet()};
$('#centerY').onclick=()=>{S.sheet.mT=r2((S.sheet.pageH-gridH())/2);syncSheetInputs();sheetInfo();drawSheet()};
$('#useArt').onclick=()=>{if(!S.art.wpt)return;S.sheet.cardW=r2(S.art.wpt/MM);S.sheet.cardH=r2(S.art.hpt/MM);syncSheetInputs();sheetInfo();drawSheet();drawArt();drawOverlay();$('#artNote').className='note ok';$('#artNote').textContent='Taille de carte alignée sur le PDF.'};

/* Nom de police intégré : préfixe de sous-ensemble standard (ABCDEF+) + vrai nom PostScript, pour qu'Illustrator retrouve la police installée */
function subsetName(f){let ps=f.ps;if(!ps){try{ps=fontkit.create(f.bytes.slice(0)).postscriptName}catch(e){}ps=ps||f.label.replace(/\s+/g,'-');f.ps=ps}
  let tag='';for(let i=0;i<6;i++)tag+=String.fromCharCode(65+Math.floor(Math.random()*26));return tag+'+'+String(ps).replace(/[^\x21-\x7e]/g,'').replace(/[()<>\[\]{}\/%#]/g,'')}
/* ---------- enregistrement (application : boîte de dialogue native ; page : capability downloads) ---------- */
async function saveOut(filename,data,filters){
  if(window.api&&window.api.saveFile){const r=await window.api.saveFile(filename,data,filters);if(!r)throw Object.assign(new Error('annulé'),{code:'declined'});return r}
  const dl=window.claude&&window.claude.use?await window.claude.use('downloads'):null;
  if(!dl)throw new Error('Téléchargement indisponible dans cette vue.');
  await dl.save({filename,data});return filename}
/* texte en police variable : dessiné en contours (graisse exacte, aucune police manquante à l'ouverture) */
function vfWidth(vf,t){return vf.layout(t).positions.reduce((a,p)=>a+p.xAdvance,0)}
function drawVarText(page,vf,e,row,ox,oy,PH,col,i,warns){
  const up=vf.unitsPerEm,lines=textLines(e,row);if(!lines.length)return;
  const size=fitLines(e,lines,(t,sz)=>vfWidth(vf,t)*sz/up);if(size<e.size-.01)warns.push(`Ligne ${i+2} : « ${e.name} » réduit à ${size.toFixed(1)} pt.`);
  if((e.over||'ask')==='ask'&&e.maxW>0&&Math.max(...lines.map(t=>vfWidth(vf,t)*size/up))>e.maxW*MM+.01)warns.push(`Ligne ${i+2} : « ${e.name} » dépasse la largeur max.`);
  const sc=size/up,szmm=size/MM,f=v=>+(v*sc).toFixed(3);
  lines.forEach((t,k)=>{const run=vf.layout(t);let x=0,d='';
    run.glyphs.forEach((g,gi)=>{const P=run.positions[gi],dx=x+(P.xOffset||0),dy=P.yOffset||0;
      for(const c of g.path.commands){const a=c.args,X=j=>f(a[j]+dx),Y=j=>f(-(a[j]+dy));
        if(c.command==='moveTo')d+=`M${X(0)} ${Y(1)}`;else if(c.command==='lineTo')d+=`L${X(0)} ${Y(1)}`;
        else if(c.command==='quadraticCurveTo')d+=`Q${X(0)} ${Y(1)} ${X(2)} ${Y(3)}`;else if(c.command==='bezierCurveTo')d+=`C${X(0)} ${Y(1)} ${X(2)} ${Y(3)} ${X(4)} ${Y(5)}`;else if(c.command==='closePath')d+='Z'}
      x+=P.xAdvance});
    if(d)page.drawSvgPath(d,{x:(ox+e.x)*MM+alOff(e,x*sc),y:PH-(oy+effY(e,row)+szmm*ASC+k*szmm*e.lh)*MM,color:col,borderWidth:0})})}
/* texte à plusieurs polices : chaque morceau est écrit avec sa police (texte PDF ou contours si police variable) */
function drawRunsText(page,fmap,e,row,ox,oy,PH,col,i,warns){
  const lines=runsOf(e,row);if(!lines.length)return;
  const wOf=(r,sz)=>{const F=fmap[r.font];if(!F)return 0;if(F.vf)return vfWidth(F.vf,r.t)*sz/F.vf.unitsPerEm;try{return F.widthOfTextAtSize(r.t,sz)}catch(x){return 0}};
  const lineW=(L,sz)=>L.reduce((a,r)=>a+wOf(r,sz),0);
  let size=e.size;const w0=Math.max(...lines.map(L=>lineW(L,size)));
  if(e.maxW>0&&w0>e.maxW*MM+.01){if((e.over||'ask')==='shrink'){size=Math.max(3,size*e.maxW*MM/w0);warns.push(`Ligne ${i+2} : « ${e.name} » réduit à ${size.toFixed(1)} pt.`)}else if((e.over||'ask')==='ask')warns.push(`Ligne ${i+2} : « ${e.name} » dépasse la largeur max.`)}
  const szmm=size/MM;
  lines.forEach((L,k)=>{let x=(ox+e.x)*MM+alOff(e,lineW(L,size));const y=PH-(oy+effY(e,row)+szmm*ASC+k*szmm*e.lh)*MM;
    L.forEach(r=>{const F=fmap[r.font];if(!F)return;
      if(F.vf){const vf=F.vf,sc=size/vf.unitsPerEm,f=v=>+(v*sc).toFixed(3);const run=vf.layout(r.t);let ax=0,d='';
        run.glyphs.forEach((g,gi)=>{const P=run.positions[gi],dx=ax+(P.xOffset||0),dy=P.yOffset||0;
          for(const c of g.path.commands){const a=c.args,X=j=>f(a[j]+dx),Y=j=>f(-(a[j]+dy));
            if(c.command==='moveTo')d+=`M${X(0)} ${Y(1)}`;else if(c.command==='lineTo')d+=`L${X(0)} ${Y(1)}`;
            else if(c.command==='quadraticCurveTo')d+=`Q${X(0)} ${Y(1)} ${X(2)} ${Y(3)}`;else if(c.command==='bezierCurveTo')d+=`C${X(0)} ${Y(1)} ${X(2)} ${Y(3)} ${X(4)} ${Y(5)}`;else if(c.command==='closePath')d+='Z'}
          ax+=P.xAdvance});
        if(d)page.drawSvgPath(d,{x,y,color:col,borderWidth:0})}
      else{let t=r.t;try{F.encodeText(t)}catch(x){t=[...t].map(ch=>{try{F.encodeText(ch);return ch}catch(y){return '?'}}).join('');warns.push(`Ligne ${i+2} : caractère non géré par ${fontById(r.font).label} dans « ${r.t} ».`)}
        page.drawText(t,{x,y,size,font:F,color:col})}
      x+=wOf(r,size)})})}
/* emplacement de la i-ème carte : planches remplies dans l'ordre ; la dernière planche incomplète peut être calée à la fin (verso) */
function slotOf(i,n,per){const j=i%per,start=i-j,k=Math.min(per,n-start);return S.sheet.fillEnd&&k<per?per-k+j:j}
/* ---------- Nom des fichiers : CMD-CLIENT-PLANCHE-TYPE-MODELE-COULEUR[-FACE]-NN, en MAJUSCULES ---------- */
const NM=['cmd','client','model','color','face','type'],nmEl=k=>$('#nm'+k[0].toUpperCase()+k.slice(1));
S.naming={cmd:'',client:'',model:'',color:'',face:'',type:'',touched:{}};
const MODELS=['classique','classic','custom','premium','prestige','signature','essentiel','essentielle','minimal','minimaliste','design','standard','luxe','eco','elegance','origine','pro'];
const COLORS=[[/^(blanc|blanche|white)$/,'BLANC'],[/^(noir|noire|black)$/,'NOIR'],[/^(bambou|bamboo)$/,'BAMBOU'],[/^(gold|or|dore|doree|golden)$/,'GOLD'],[/^(silver|argent|argente|argentee)$/,'SILVER'],[/^(metal|metallique)$/,'METAL'],[/^(pvc)$/,'PVC']];
const NSTOP=new Set(['cmd','commande','cde','order','rv','r','v','type','vkard','planche','planches','board','aplat','a3','a4','carte','cartes','card','cards','pdf','ai','csv','xlsx','final','fichier','bat','nfc','fusion','merge','modele','model','template','gabarit','def','ok','v1','v2','v3']);
function parseNameInfo(fileName){const base=String(fileName||'').replace(/\.[a-z0-9]{2,4}$/i,'');const out={};const cl=[];
  for(const t of base.split(/[\s_\-.,()[\]+]+/).filter(Boolean)){const k=norm(t);
    if(/^[0-9a-f]{8}$/.test(k)&&/[a-f]/.test(k))continue; // préfixe technique (identifiant d'envoi)
    if(/^\d+$/.test(k)){if(!out.cmd&&k.length>=4&&!/^20[2-3]\d$/.test(k))out.cmd=k;continue}
    const c=COLORS.find(([re])=>re.test(k));if(c){if(!out.color||out.color==='METAL'||out.color==='PVC')out.color=c[1];continue}
    if(k==='recto'||k==='verso'){out.face=k.toUpperCase();continue}
    if(MODELS.includes(k)){if(!out.model)out.model=t.toUpperCase();continue}
    if(NSTOP.has(k)||k.length<2||/^\d/.test(k))continue;cl.push(t)}
  if(cl.length)out.client=cl.slice(0,3).join(' ');return out}
const clean=t=>String(t||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase().replace(/[^A-Z0-9]+/g,'-').replace(/^-+|-+$/g,'');
function fmtType(){const id=S.fmtId||'';if(id.startsWith('aplat'))return 'APLAT';if(id.startsWith('board'))return 'BOARD';const f=(typeof allFormats==='function')?allFormats().find(x=>x.id===id):null;return f?clean(f.label.split('·')[0]):'PLANCHE'}
function fmtMaterial(){const id=S.fmtId||'';return id.includes('bambou')?'BAMBOU':id.includes('metal')?'METAL':''}
function autoNaming(info){const N=S.naming;for(const k of NM){if(N.touched[k])continue;if(info&&info[k])N[k]=info[k]}
  if(info&&info.color)N._colorFmt=false;
  if(!N.touched.type)N.type=fmtType();if(!N.touched.color&&(!N.color||N._colorFmt)){const m=fmtMaterial();N.color=m;N._colorFmt=!!m}renderNaming()}
function fileBase(){const N=S.naming;return [N.cmd,N.client,'PLANCHE',N.type||fmtType(),N.model,N.color,N.face].map(clean).filter(Boolean).join('-')}
function renderNaming(){for(const k of NM){const el=nmEl(k);if(el&&document.activeElement!==el)el.value=S.naming[k]||''}
  const per=S.sheet.cols*S.sheet.rows,n=Math.max(1,Math.ceil(S.data.rows.length/per)),ext=$('#nmExt').value,b=fileBase();
  $('#nmPrev').textContent=n>1?`${n} fichiers dans le dossier « ${b} » : ${b}-01.${ext} … ${b}-${String(n).padStart(2,'0')}.${ext}`:`Fichier : ${b}-01.${ext}`}
NM.forEach(k=>{const el=nmEl(k);el.oninput=()=>{S.naming[k]=el.value;S.naming.touched[k]=el.value!=='';renderNaming()}});
$('#nmExt').onchange=()=>{LSset('planche.ext',$('#nmExt').value);renderNaming()};
$('#txtMode').onchange=()=>LSset('planche.textMode',$('#txtMode').value);
/* une planche = un fichier (pages séparées) */
async function splitSheets(bytes){const{PDFDocument}=PDFLib;const src=await PDFDocument.load(bytes);const n=src.getPageCount();if(n===1)return[bytes];const out=[];
  for(let i=0;i<n;i++){const d=await PDFDocument.create();const[pg]=await d.copyPages(src,[i]);d.addPage(pg);d.setTitle(fileBase()+'-'+String(i+1).padStart(2,'0'));d.setCreator('VKARD Planche QR');out.push(await d.save())}return out}
/* ---------- génération PDF ---------- */
async function generateBytes(log){
  const{PDFDocument,StandardFonts,cmyk}=PDFLib;const s=S.sheet,rows=S.data.rows;
  if(!rows.length)throw new Error('Aucune ligne de données.');
  const missing=[];S.els.filter(e=>e.type==='qr').forEach(e=>rows.forEach((r,i)=>{if(!applyTpl('{'+e.col+'}',r).trim())missing.push(i+2)}));
  if(missing.length)throw new Error(`URL du QR vide aux lignes ${[...new Set(missing)].slice(0,15).join(', ')} du fichier.`);
  if(s.mL+gridW()>s.pageW+.01||s.mT+gridH()>s.pageH+.01)throw new Error('Les cartes dépassent de la page : ajuste l\'étape 4.');
  const out=await PDFDocument.create();out.registerFontkit(fontkit);
  const src=await PDFDocument.load(S.art.bytes.slice(0));const[emb]=await out.embedPages([src.getPage(0)]);
  let emb2=null;if(S.art2){const s2=await PDFDocument.load(S.art2.bytes.slice(0));[emb2]=await out.embedPages([s2.getPage(0)])}
  const fmap={},warns0=[];for(const f of S.fonts){if(!S.els.some(e=>e.type==='text'&&(e.font===f.id||(isMixed(e)&&Object.values(e.fieldFonts).includes(f.id)))))continue;
    const mode=$('#txtMode').value;
    if(f.std)fmap[f.id]=await out.embedFont(StandardFonts[f.std]);
    else if(mode==='outline'||(mode==='auto'&&f.variable))fmap[f.id]={vf:f.variable?fkInst(f):fkOf(f)};
    else{if(f.variable&&f.wght!==Math.round(fkOf(f).variationAxes.wght.default))warns0.push(`Police variable ${f.label} gardée en texte : le PDF utilisera sa graisse par défaut (${weightName(fkOf(f).variationAxes.wght.default)}). Choisis « Automatique » ou « Tout vectoriser » pour la bonne graisse.`);
      fmap[f.id]=await out.embedFont(f.bytes.slice(0),{subset:true,customName:subsetName(f)})}}
  const PW=s.pageW*MM,PH=s.pageH*MM,per=s.cols*s.rows,warns=[...warns0];let page;
  rows.forEach((row,i)=>{
    if(i%per===0)page=out.addPage([PW,PH]);const slot=slotOf(i,rows.length,per);
    const ox=s.mL+(slot%s.cols)*(s.cardW+s.gapX),oy=s.mT+Math.floor(slot/s.cols)*(s.cardH+s.gapY);
    const useA2=S.art2&&emb2&&artFor(row)===S.art2,A=useA2?S.art2:S.art,pl=artPlace(A);
    if(pl.mode==='center'&&S.bg)page.drawRectangle({x:ox*MM,y:PH-(oy+s.cardH)*MM,width:s.cardW*MM,height:s.cardH*MM,color:cmyk(...S.bg.cmyk.map(v=>v/100)),borderWidth:0});
    page.pushOperators(PDFLib.pushGraphicsState(),PDFLib.rectangle(ox*MM,PH-(oy+s.cardH)*MM,s.cardW*MM,s.cardH*MM),PDFLib.clip(),PDFLib.endPath());
    page.drawPage(useA2?emb2:emb,{x:(ox+pl.ox)*MM,y:PH-(oy+pl.oy+pl.dh)*MM,width:pl.dw*MM,height:pl.dh*MM});
    page.pushOperators(PDFLib.popGraphicsState());
    S.els.forEach(e=>{
      const col=cmyk(...e.color.map(v=>v/100));
      if(e.type==='qr'){const m=qrMatrix(applyTpl('{'+e.col+'}',row).trim(),e.ecc);const G=qrGeom(e),sc=e.size*MM/QS_SIDE;
        if(G.st.box)page.drawSvgPath(roundRectPath(G.st.box.w*sc,G.st.box.h*sc,G.st.box.r*sc),{x:(ox+e.x)*MM,y:PH-(oy+e.y)*MM,color:cmyk(...(e.boxColor||[0,0,0,0]).map(v=>v/100)),borderWidth:0});
        page.drawSvgPath(qrPath(m,0,0,e.size*MM),{x:(ox+G.qx)*MM,y:PH-(oy+G.qy)*MM,color:col,borderWidth:0});
        if(G.st.text)page.drawSvgPath(G.st.text.d,{x:(ox+G.qx)*MM-G.st.text.ox*sc,y:PH-(oy+G.qy)*MM+G.st.text.oy*sc,scale:sc,color:col,borderWidth:0});
        if(m.length>45)warns.push(`Ligne ${i+2} : QR dense (${m.length} modules), URL longue.`)}
      else{
        if(isMixed(e)){drawRunsText(page,fmap,e,row,ox,oy,PH,col,i,warns);return}
        const font=fmap[e.font];if(font&&font.vf){drawVarText(page,font.vf,e,row,ox,oy,PH,col,i,warns);return}
        const clean=t=>{try{font.encodeText(t);return t}catch(x){const t2=[...t].map(ch=>{try{font.encodeText(ch);return ch}catch(y){return '?'}}).join('');warns.push(`Ligne ${i+2} : caractère non géré par ${fontById(e.font).label} dans « ${t} ».`);return t2}};
        const lines=textLines(e,row).map(clean);if(!lines.length)return;
        const size=fitLines(e,lines,(t,sz)=>font.widthOfTextAtSize(t,sz));
        if(size<e.size-.01)warns.push(`Ligne ${i+2} : « ${e.name} » réduit à ${size.toFixed(1)} pt.`);
        if((e.over||'ask')==='ask'&&e.maxW>0&&Math.max(...lines.map(t=>font.widthOfTextAtSize(t,size)))>e.maxW*MM+.01)warns.push(`Ligne ${i+2} : « ${e.name} » dépasse la largeur max.`);
        const szmm=size/MM;
        lines.forEach((t,k)=>page.drawText(t,{x:(ox+e.x)*MM+alOff(e,font.widthOfTextAtSize(t,size)),y:PH-(oy+effY(e,row)+szmm*ASC+k*szmm*e.lh)*MM,size,font,color:col}))}
    })});
  out.setTitle('Planche QR');out.setCreator('Planche QR');
  if(log)log(warns);
  return await out.save()}
$('#gen').onclick=async()=>{
  if(S.art.demo||S.data.demo)return;
  if(!$('#review').hidden)$('#rvOk').click();
  {const iss=genIssues();if(iss.length){$('#status').scrollIntoView({behavior:'smooth',block:'center'});if(!confirm('Avant de générer, vérifie :\n\n'+iss.join('\n')+'\n\nGénérer quand même ?'))return}}
  const lg=$('#log'),b=$('#gen');lg.textContent='';genBusy=true;b.disabled=true;b.textContent='Génération…';$('#genTop').disabled=true;
  try{
    const bytes=await generateBytes(w=>{lg.textContent=w.length?w.slice(0,40).join('\n')+(w.length>40?`\n… +${w.length-40}`:''):''});
    const docs=await splitSheets(bytes),ext=$('#nmExt').value,base=fileBase(),flt=[{name:ext==='ai'?'Illustrator (.ai)':'PDF',extensions:[ext]}];
    const names=docs.map((d,i)=>`${base}-${String(i+1).padStart(2,'0')}.${ext}`);let msg;
    if(docs.length===1){const path=await saveOut(names[0],docs[0],flt);msg='Planche enregistrée : '+path}
    else if(window.api&&window.api.saveFolder){const dir=await window.api.saveFolder(base,docs.map((d,i)=>({name:names[i],data:d})));if(!dir)throw Object.assign(new Error('annulé'),{code:'declined'});msg=`${docs.length} planches enregistrées dans le dossier : ${dir}`}
    else{const saved=[];for(let i=0;i<docs.length;i++){saved.push(await saveOut(names[i],docs[i],flt))}msg=`${docs.length} planches enregistrées :\n`+saved.join('\n')}
    lg.textContent=msg+(lg.textContent?'\n\nAjustements automatiques :\n'+lg.textContent:'')
  }catch(e){lg.textContent=e&&e.code==='declined'?'Enregistrement annulé.':'Erreur : '+(e&&e.message||e)}
  finally{genBusy=false;updateStatus()}};

/* ---------- modèle (.json) ---------- */
function b64(u8){let s='';for(let i=0;i<u8.length;i+=0x8000)s+=String.fromCharCode.apply(null,u8.subarray(i,i+0x8000));return btoa(s)}
function buildModel(){return{v:1,fit:S.fit,bg:S.bg,art2:S.art2?b64(new Uint8Array(S.art2.bytes)):null,art2Name:S.art2?S.art2.name:'',variantEl:S.variantEl,variantMin:S.variantMin,sheet:S.sheet,els:S.els.map(e=>{const c=Object.assign({},e);delete c._box;if(c.type==='text'){const f=fontById(c.font);if(!f.std){c.fontLabel=f.label;if(f.ps)c.fontPs=f.ps}}return c}),art:S.art.demo?null:b64(new Uint8Array(S.art.bytes)),artName:S.art.name,fonts:S.fonts.filter(f=>!f.std).map(f=>f.label),fmtId:S.fmtId||''}}
/* ---------- Mes modèles : bibliothèque enregistrée dans l'application (IndexedDB) ---------- */
const idb=()=>new Promise((res,rej)=>{const r=indexedDB.open('planche-qr',1);r.onupgradeneeded=()=>{r.result.createObjectStore('models',{keyPath:'name'})};r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)});
const idbDo=(mode,fn)=>idb().then(db=>new Promise((res,rej)=>{const st=db.transaction('models',mode).objectStore('models');const q=fn(st);q.onsuccess=()=>res(q.result);q.onerror=()=>rej(q.error)}));
const mdlAll=()=>EMBED?fetch('/api/planche/models').then(r=>r.json()).catch(()=>[]):idbDo('readonly',st=>st.getAll()).then(l=>l.sort((a,b)=>a.name.localeCompare(b.name,'fr'))).catch(()=>[]);
const srvOk=r=>{if(!r.ok)throw new Error('serveur ('+r.status+')');return r};
const mdlPut=m=>EMBED?fetch('/api/planche/models',{method:'PUT',headers:{'content-type':'application/json'},body:JSON.stringify(m)}).then(srvOk):idbDo('readwrite',st=>st.put(m));
const mdlDel=n=>EMBED?fetch('/api/planche/models?name='+encodeURIComponent(n),{method:'DELETE'}).then(srvOk):idbDo('readwrite',st=>st.delete(n));
async function renderModelSel(){const sel=$('#presetSel');const mine=await mdlAll();sel.innerHTML='<option value="">Choisir…</option>';
  const grp=(label,items)=>{if(!items.length)return;const g=document.createElement('optgroup');g.label=label;items.forEach(([v,t])=>{const o=document.createElement('option');o.value=v;o.textContent=t;g.appendChild(o)});sel.appendChild(g)};
  grp('Mes modèles',mine.map(m=>['u:'+m.name,m.name]));grp('Modèles fournis',Object.keys(window.PRESETS||{}).map(k=>['p:'+k,window.PRESETS[k].label]));
  const L=$('#mdlList');L.innerHTML='';if(!mine.length)L.innerHTML='<p class="note" style="margin:0">Aucun modèle enregistré pour l\'instant.</p>';
  mine.forEach(m=>{const d=document.createElement('div');d.className='item';const t=document.createElement('span');t.className='t';t.textContent=m.name;const sm=document.createElement('small');sm.textContent=m.savedAt?new Date(m.savedAt).toLocaleDateString('fr-FR'):'';t.appendChild(sm);
    const del=document.createElement('button');del.className='btn sm';del.textContent='Supprimer';del.onclick=async()=>{if(del.dataset.ok!=='1'){del.dataset.ok='1';del.textContent='Confirmer';setTimeout(()=>{del.dataset.ok='';del.textContent='Supprimer'},3000);return}await mdlDel(m.name);renderModelSel()};
    d.append(t,del);L.appendChild(d)})}
$('#presetSel').onchange=async()=>{const v=$('#presetSel').value;if(!v)return;$('#log').textContent='Chargement du modèle…';
  try{let m;if(v.startsWith('u:')){m=(await mdlAll()).find(x=>x.name===v.slice(2))}else m=(window.PRESETS||{})[v.slice(2)];
    if(!m)throw new Error('modèle introuvable');const r=await applyModel(m);S.modelName=v.startsWith('u:')?m.name:'';$('#log').textContent=modelMsg(r).replace('Modèle chargé.','Modèle « '+(m.name||m.label)+' » chargé.')}
  catch(e){$('#log').textContent='Erreur : '+(e&&e.message||e)}$('#presetSel').value=''};
$('#saveModel').onclick=()=>{const box=$('#mdlBox');box.hidden=!box.hidden;if(box.hidden)return;
  const N=S.naming||{};$('#mdlName').value=S.modelName||[N.client,N.model,N.color].filter(Boolean).join(' ')||(S.art.demo?'':S.art.name.replace(/\s*\(nettoyé\)/,'').replace(/\.(pdf|ai)$/i,''));
  $('#mdlHint').textContent='Le modèle garde la carte, les éléments (positions, polices, couleurs, styles de QR) et le format de planche. Les données ne sont pas incluses.';renderModelSel();$('#mdlName').focus()};
$('#mdlClose').onclick=()=>{$('#mdlBox').hidden=true};
{const tog=(id,others)=>()=>{const b=$(id);b.hidden=!b.hidden;others.forEach(o=>{$(o).hidden=true})};
  $('#mdlMenuBtn').onclick=tog('#mdlMenu',['#helpBox','#mdlBox']);$('#helpBtn').onclick=tog('#helpBox',['#mdlMenu','#mdlBox']);$('#helpClose').onclick=()=>{$('#helpBox').hidden=true};
  $('#saveModel').addEventListener('click',()=>{$('#mdlMenu').hidden=true});$('#modelIn').addEventListener('change',()=>{$('#mdlMenu').hidden=true});
  $('#presetSel').addEventListener('change',()=>{$('#mdlMenu').hidden=true});
  document.addEventListener('pointerdown',ev=>{if(!ev.target.closest('.pop,#mdlMenuBtn,#helpBtn,#fontPick'))['#mdlMenu','#helpBox'].forEach(o=>{$(o).hidden=true})})}
$('#mdlSave').onclick=async()=>{const name=$('#mdlName').value.trim();if(!name){$('#mdlName').focus();return}
  try{await mdlPut({...buildModel(),name,label:name,savedAt:Date.now()});S.modelName=name;await renderModelSel();$('#mdlHint').className='note ok';$('#mdlHint').textContent='« '+name+' » enregistré dans mes modèles.';$('#log').textContent='Modèle « '+name+' » enregistré dans mes modèles.'}
  catch(e){$('#mdlHint').className='note bad';$('#mdlHint').textContent='Enregistrement impossible : '+(e&&e.message||e)}};
$('#mdlExport').onclick=async()=>{const name=$('#mdlName').value.trim()||'modele-planche';
  try{await saveOut(clean(name)+'.json',JSON.stringify({...buildModel(),name,label:name}),[{name:'Modèle de planche',extensions:['json']}]);$('#mdlHint').className='note ok';$('#mdlHint').textContent='Fichier exporté.'}catch(e){if(!(e&&e.code==='declined')){$('#mdlHint').className='note bad';$('#mdlHint').textContent='Erreur : '+(e&&e.message||e)}}};
const fontByLabel=l=>S.fonts.find(f=>!f.std&&norm(f.label)===norm(l));
async function sysFontList(){if(!window.queryLocalFonts)return null;if(!sysFonts)sysFonts=(await window.queryLocalFonts()).sort((a,b)=>(a.fullName||'').localeCompare(b.fullName||''));return sysFonts}
async function loadSys(c){const ex=S.fonts.find(f=>f.ps&&f.ps===c.postscriptName);if(ex)return ex;const blob=await c.blob();const id=await addFont(await blob.arrayBuffer(),c.fullName,weightFromName(c.style||c.fullName));const f=S.fonts.find(x=>x.id===id);if(!f.ps||f.variable)f.ps=c.postscriptName;if(f.variable)f.label=c.fullName;return f}
/* police installée : 1) nom PostScript exact (Avenir-Book…) 2) nom complet 3) mots du nom */
async function localFontByLabel(label,ps){
  try{const L=await sysFontList();if(!L)return null;
    const psn=String(ps||label||'').replace(/^[A-Z]{6}\+/,'').replace(/\s+/g,'-').toLowerCase();
    const words=norm(label||ps||'').replace(/-/g,' ').split(' ').filter(Boolean);const hay=f=>norm((f.fullName||'')+' '+(f.family||'')+' '+(f.style||'')+' '+(f.postscriptName||'').replace(/-/g,' '));
    const c=L.find(f=>(f.postscriptName||'').toLowerCase()===psn)||L.find(f=>norm(f.fullName)===norm(label||''))||L.filter(f=>words.length&&words.every(w=>hay(f).includes(w))).sort((a,b)=>a.fullName.length-b.fullName.length)[0];
    return c?await loadSys(c):null}catch(e){return null}}
/* repli : Arial (présente sur tous les PC Windows) plutôt qu'Helvetica, absente de Windows */
async function fallbackFont(bold){try{const L=await sysFontList();if(!L)return null;const c=L.find(f=>f.postscriptName===(bold?'Arial-BoldMT':'ArialMT'));return c?await loadSys(c):null}catch(e){return null}}
/* polices remplacées par l'utilisateur (ex. Avenir Heavy -> Avenir LT 85 Heavy), retenues pour les prochaines cartes */
const fontKey=e=>norm(e.fontLabel||e.fontPs||'')+(e.fontWeight?'@'+e.fontWeight:'');
const fontMap=()=>LS('planche.fontMap',{});
function fontOk(e){if(e.type!=='text'||!(e.fontLabel||e.fontPs))return true;if(e.fontPicked)return true;const f=fontById(e.font);if(!f||f.std)return false;
  if(f.forKey&&f.forKey===fontKey(e))return true;
  if(f.variable&&e.fontWeight&&f.wght!==e.fontWeight)return false;
  return norm(f.label)===norm(e.fontLabel||'')||(!!e.fontPs&&f.ps===e.fontPs)||(!!f.ps&&fontMap()[fontKey(e)]===f.ps)}
async function mappedFont(e){const ps=fontMap()[fontKey(e)];if(!ps)return null;return S.fonts.find(x=>x.ps===ps)||await localFontByLabel(null,ps)}
let fpCb=null;
function openFontPicker(title,cb,query){fpCb=cb;$('#fpTitle').textContent=title;$('#fontPick').hidden=false;$('#fpFilter').value=query||'';renderFp();$('#fpFilter').focus()}
async function renderFp(){const L=$('#fpList');const all=await sysFontList();const q=norm($('#fpFilter').value);
  if(!all){L.innerHTML='<p class="note">La liste des polices installées n\'est pas disponible ici : choisis le fichier de la police.</p>';return}
  const words=q.split(' ').filter(Boolean),hay=f=>norm((f.fullName||'')+' '+(f.postscriptName||'').replace(/-/g,' '));
  const list=all.filter(f=>words.every(w=>hay(f).includes(w))).slice(0,120);L.innerHTML='';
  list.forEach(f=>{const b=document.createElement('button');b.textContent=f.fullName;b.title=f.postscriptName||'';b.onclick=async()=>{try{const x=await loadSys(f);closeFp(x)}catch(err){L.insertAdjacentHTML('afterbegin','<p class="note bad">Police inutilisable : '+(err.message||err)+'</p>')}};L.appendChild(b)});
  if(!list.length)L.innerHTML='<p class="note">Aucune police ne correspond.</p>'}
function closeFp(font){$('#fontPick').hidden=true;const cb=fpCb;fpCb=null;if(font&&cb)cb(font)}
$('#fpFilter').oninput=()=>renderFp();$('#fpClose').onclick=()=>closeFp(null);
$('#fontPick').onclick=e=>{if(e.target.id==='fontPick')closeFp(null)};
$('#fpFile').onchange=async ev=>{const f=ev.target.files[0];ev.target.value='';if(!f)return;try{const id=await addFont(await f.arrayBuffer(),f.name.replace(/\.(ttf|otf)$/i,''));closeFp(S.fonts.find(x=>x.id===id))}catch(err){$('#fpList').innerHTML='<p class="note bad">Police illisible : '+(err.message||err)+'</p>'}};
/* une police choisie pour une police demandée s'applique à tous les textes qui la demandent, et est retenue */
/* police choisie pour UN texte. Si la police demandée était introuvable, les autres textes qui demandaient
   la même police (encore introuvable) la reçoivent aussi et le choix est mémorisé pour les prochaines cartes ;
   si elle était déjà trouvée, seul ce texte change (polices réglables texte par texte). */
function applyFontChoice(e,font){if(font.variable&&e.fontWeight&&!weightFromName(font.label))font=variantOf(font,e.fontWeight);const k=fontKey(e),wasOk=fontOk(e);
  S.els.forEach(x=>{if(x.type==='text'&&(x===e||(!wasOk&&k&&fontKey(x)===k&&!fontOk(x)))){x.font=font.id;x.fontPicked=true}});
  if(!wasOk&&k&&font.ps){const m={...fontMap(),[k]:font.ps};LSset('planche.fontMap',m)}
  S.elsAreDemo=false;renderList();renderForm();drawAll();if(!$('#review').hidden)renderReview()}
async function resolveFonts(els){const missing=new Set(),found=new Set();
  for(const e of els){if(e.type!=='text'||!(e.fontLabel||e.fontPs))continue;
    let f=await mappedFont(e)||fontByLabel(e.fontLabel||'')||(e.fontPs&&S.fonts.find(x=>x.ps===e.fontPs))||await localFontByLabel(e.fontLabel,e.fontPs);
    if(f&&f.variable){ // police variable : graisse du texte (PDF, largeurs des lettres, ou nom)
      let w=matchWeight(f,e.fontWidths)||e.fontWeight||weightFromName(e.fontPs||e.fontLabel)||f.wght||400;w=Math.round(w/50)*50;e.fontWeight=w;
      const m=await mappedFont(e);f=m||variantOf(f,w);if(!m)f.forKey=fontKey(e)}
    if(f){e.font=f.id;found.add(f.label)}else{missing.add(e.fontLabel||e.fontPs);const fb=await fallbackFont(/black|bold|heavy|semibold/i.test((e.fontLabel||'')+(e.fontPs||''))||e.font==='helv-b');if(fb)e.font=fb.id;else if(!S.fonts.some(x=>x.id===e.font))e.font='helv'}}
  /* police d'un champ détectée dans le PDF (2e police sur la même ligne) */
  for(const e of els){if(e.type!=='text'||!e.fieldFontReq)continue;
    for(const[k,req]of Object.entries(e.fieldFontReq)){const ps={type:'text',font:req.bold?'helv-b':'helv',fontLabel:req.fontLabel,fontPs:req.fontPs,fontWeight:req.fontWeight,fontWidths:req.fontWidths};
      const r=await resolveFonts([ps]);r.found.forEach(x=>found.add(x));r.missing.forEach(x=>missing.add(x));
      /* même fichier de police que le texte mais autre graisse : variante de la police du texte */
      const base=fontById(e.font);if(base&&base.variable&&!r.found.length&&req.fontWidths){const w=matchWeight(base,req.fontWidths);if(w)ps.font=variantOf(base,Math.round(w/50)*50).id}
      if(ps.font&&ps.font!==e.font){e.fieldFonts={...(e.fieldFonts||{}),[k]:ps.font}}}}
  return{missing:[...missing],found:[...found]}}
async function applyModel(m){
  Object.assign(S.sheet,m.sheet);S.els=JSON.parse(JSON.stringify(m.els));S.nextId=1+Math.max(S.nextId,...S.els.map(e=>+String(e.id).replace(/\D/g,'')||0));S.sel=null;S.elsAreDemo=false;
  if(m.fmtId&&typeof allFormats==='function'&&allFormats().some(f=>f.id===m.fmtId))S.fmtId=m.fmtId;
  S.variantEl=m.variantEl||'';S.variantMin=m.variantMin||2;S.art2=null;S.fit=m.fit||'auto';S.bg=m.bg||null;$('#fitSel').value=S.fit;syncSheetInputs();
  if(m.art2)await setArt2(Uint8Array.from(atob(m.art2),c=>c.charCodeAt(0)),m.art2Name||'variante.pdf');
  if(m.art)await setArt(Uint8Array.from(atob(m.art),c=>c.charCodeAt(0)),m.artName||'carte.pdf',false);else await drawArt();
  S._place=null; /* positions du modèle = placement actuel */
  if(m.bg)S.bg=m.bg;
  const rf=await resolveFonts(S.els),missing=new Set(rf.missing),found=new Set(rf.found);
  S.els.forEach(e=>{if(e.type==='text'&&!S.fonts.some(x=>x.id===e.font))e.font='helv'});
  sheetInfo();drawSheet();renderList();renderForm();drawAll();drawArt();
  return{missing:[...missing],found:[...found]}}
function modelMsg(r){return 'Modèle chargé.'+(r.found.length?' Polices trouvées : '+r.found.join(', ')+'.':'')+(r.missing.length?' Polices introuvables : '+r.missing.join(', ')+' (remplacées par Arial ; ajoute-les avec « Polices installées… »).':'')+' Charge maintenant ton fichier de données.'}
$('#modelIn').onchange=async ev=>{const f=ev.target.files[0];if(!f)return;try{
  const m=JSON.parse(await f.text());const r=await applyModel(m);const name=m.name||f.name.replace(/\.json$/i,'');try{await mdlPut({...m,name,label:name,savedAt:Date.now()});S.modelName=name;renderModelSel()}catch(x){}
  $('#log').textContent=modelMsg(r)+' Ajouté à mes modèles sous « '+name+' ».'}catch(e){$('#log').textContent='Modèle illisible : '+e.message}ev.target.value=''};
renderModelSel();

/* ---------- fichiers ---------- */
async function onArt(f){autoNaming(parseNameInfo(f.name));try{const b=new Uint8Array(await f.arrayBuffer());await setArt(b,f.name,false)}catch(e){$('#artNote').className='note bad';$('#artNote').textContent='PDF illisible : '+e.message}}
$('#artIn').onchange=ev=>{if(ev.target.files[0])analyzeFile(ev.target.files[0]);ev.target.value=''};
$('#rawIn').onchange=ev=>{if(ev.target.files[0])onArt(ev.target.files[0]);ev.target.value=''};
$('#dataIn').onchange=ev=>{if(ev.target.files[0])loadData(ev.target.files[0]).catch(e=>{$('#dataNote').className='note bad';$('#dataNote').textContent='Fichier illisible : '+e.message});ev.target.value=''};
async function addFont(buf,label,wantW){
  const bytes=new Uint8Array(buf);let fk=null;try{fk=fontkit.create(bytes.slice(0))}catch(e){throw new Error('format de police non géré ('+(e.message||e)+')')}
  const ax=fk.variationAxes&&fk.variationAxes.wght,variable=!!ax;
  if(variable){ // police variable : un seul FontFace (toutes les graisses), une entrée par graisse utilisée
    let base=S.fonts.find(x=>x.variable&&!x.baseId&&x.bytes.length===bytes.length&&x.familyName===fk.familyName);
    if(!base){const id='f'+(S.nextId++),fam='uf'+id;const ff=new FontFace(fam,buf.slice(0),{weight:`${Math.round(ax.min)} ${Math.round(ax.max)}`});await ff.load();document.fonts.add(ff);
      base={id,label:fk.familyName+' '+weightName(ax.default||400),family:`"${fam}", sans-serif`,weight:Math.round(ax.default||400),wght:Math.round(ax.default||400),variable:true,familyName:fk.familyName,bytes,ps:fk.postscriptName||''};S.fonts.push(base)}
    const w=wantW||weightFromName(label);return (w?variantOf(base,w):base).id}
  const id='f'+(S.nextId++);const fam='uf'+id;const ff=new FontFace(fam,buf.slice(0));await ff.load();document.fonts.add(ff);
  try{await PDFLib.PDFDocument.create().then(d=>{d.registerFontkit(fontkit);return d.embedFont(bytes,{subset:true})})}catch(e){throw new Error('format de police non géré ('+(e.message||e)+')')}
  S.fonts.push({id,label,family:`"${fam}", sans-serif`,weight:400,bytes,ps:fk.postscriptName||'',familyName:fk.familyName});return id}
$('#fontIn').onchange=async ev=>{for(const f of ev.target.files){try{const nm=f.name.replace(/\.(ttf|otf)$/i,''),id=await addFont(await f.arrayBuffer(),nm);const font=S.fonts.find(x=>x.id===id);
      const flat=t=>norm(t||'').replace(/[\s_-]/g,'');const want=e=>(!!font.ps&&flat(e.fontPs)===flat(font.ps))||flat(e.fontLabel)===flat(nm)||flat(e.fontPs)===flat(nm);
      const hit=S.els.find(e=>e.type==='text'&&!fontOk(e)&&want(e));if(hit){applyFontChoice(hit,font);$('#log').textContent='Police '+font.label+' appliquée à « '+(hit.name||'texte')+' ».'}}catch(e){$('#log').textContent='Police illisible : '+e.message}}
  ev.target.value='';renderForm();drawAll()};
let sysFonts=null;
$('#sysFonts').onclick=async()=>{
  const box=$('#sysBox');box.hidden=!box.hidden;if(box.hidden)return;
  if(!window.queryLocalFonts){$('#sysList').textContent='Accès aux polices installées indisponible ici. Utilise « + Police ».';return}
  try{if(!sysFonts)sysFonts=(await window.queryLocalFonts()).sort((a,b)=>(a.fullName||'').localeCompare(b.fullName||''));renderSys()}catch(e){$('#sysList').textContent='Accès refusé : '+e.message}};
$('#sysFilter').oninput=()=>renderSys();
function renderSys(){const q=norm($('#sysFilter').value);const L=$('#sysList');L.innerHTML='';
  (sysFonts||[]).filter(f=>!q||norm(f.fullName+' '+f.family).includes(q)).slice(0,60).forEach(f=>{const b=document.createElement('button');b.className='chip';b.style.textAlign='left';b.textContent=f.fullName;b.onclick=async()=>{
    try{const blob=await f.blob();const id=await addFont(await blob.arrayBuffer(),f.fullName);const e=byId(S.sel);if(e&&e.type==='text'){e.font=id;S.elsAreDemo=false}renderForm();drawAll();$('#log').textContent='Police ajoutée : '+f.fullName+(e&&e.type==='text'?' (appliquée à « '+(e.name||'texte')+' »)':'')}catch(x){$('#log').textContent='Police inutilisable : '+x.message}};L.appendChild(b)});
  if(!L.children.length)L.textContent='Aucune police trouvée.'}
['artDrop','dataDrop'].forEach(id=>{const z=$('#'+id);
  z.addEventListener('dragover',e=>{e.preventDefault();z.classList.add('on')});z.addEventListener('dragleave',()=>z.classList.remove('on'));
  z.addEventListener('drop',e=>{e.preventDefault();z.classList.remove('on');const f=e.dataTransfer.files[0];if(!f)return;id==='artDrop'?analyzeFile(f):loadData(f).catch(x=>{$('#dataNote').className='note bad';$('#dataNote').textContent='Fichier illisible : '+x.message})})});
document.querySelectorAll('label.btn[tabindex]').forEach(l=>l.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();l.click()}}));
$('#rowSel').onchange=e=>{S.rowIdx=+e.target.value;drawAll();drawArt()};
$('#art2In').onchange=async ev=>{const f=ev.target.files[0];if(f){try{await setArt2(new Uint8Array(await f.arrayBuffer()),f.name)}catch(e){$('#artNote').className='note bad';$('#artNote').textContent='PDF illisible : '+e.message}}ev.target.value=''};
$('#art2Del').onclick=()=>{S.art2=null;refreshVariant();drawArt().then(drawOverlay)};
$('#varEl').onchange=e=>{S.variantEl=e.target.value;drawArt().then(drawOverlay)};
$('#varMin').oninput=e=>{S.variantMin=Math.max(2,Math.round(num(e.target.value,2)));drawArt().then(drawOverlay)};
$('#addText').onclick=()=>{const e={id:'e'+(S.nextId++),type:'text',name:'Texte',tpl:'{'+(S.data.cols[0]||'Colonne')+'}',font:'helv',size:6,x:7.3,y:40,color:[0,0,0,0],lh:1.2,maxW:42};S.els.push(e);S.elsAreDemo=false;select(e.id);drawAll()};
$('#delEl').onclick=()=>{const e=byId(S.sel);if(!e)return;S.els=S.els.filter(x=>x!==e);S.sel=null;S.elsAreDemo=false;renderList();renderForm();drawAll()};

function drawAll(skipList){drawOverlay();drawSheet();if(!skipList)renderList();updateStatus()}
new ResizeObserver(()=>{sizeBox();drawArt().then(drawOverlay)}).observe($('#stageWrap'));
function sizeBox(){const wrap=$('#stageWrap'),box=$('#cardBox');const W=Math.min(wrap.clientWidth-32,760);box.style.width=Math.max(200,W)+'px';box.style.aspectRatio=`${S.sheet.cardW}/${S.sheet.cardH}`}
new MutationObserver(()=>drawSheet()).observe(document.documentElement,{attributes:true,attributeFilter:['data-theme']});
if(window.matchMedia)window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change',drawSheet);

/* ---------- Analyse d'une carte PDF : détecte fond, QR (vectoriel ou image), textes, et crée le modèle ---------- */
const latin1=u8=>{let o='';for(let i=0;i<u8.length;i+=0x4000)o+=String.fromCharCode.apply(null,u8.subarray(i,i+0x4000));return o};
function csTokenize(src){const toks=[],n=src.length;let i=0;
  const WS=c=>c===32||c===10||c===13||c===9||c===12||c===0,DL=c=>'()<>[]{}/%'.indexOf(String.fromCharCode(c))>=0;
  while(i<n){const c=src.charCodeAt(i);
    if(WS(c)){i++;continue}
    if(c===37){while(i<n&&src.charCodeAt(i)!==10&&src.charCodeAt(i)!==13)i++;continue}
    const st=i;
    if(c===47){i++;while(i<n&&!WS(src.charCodeAt(i))&&!DL(src.charCodeAt(i)))i++;toks.push({t:'name',v:src.slice(st+1,i),s:st,e:i});continue}
    if(c===40){let d=1;i++;while(i<n&&d>0){const ch=src[i];if(ch==='\\')i+=2;else{if(ch==='(')d++;else if(ch===')')d--;i++}}toks.push({t:'str',s:st,e:i});continue}
    if(c===60){if(src[i+1]==='<'){i+=2;toks.push({t:'dopen',s:st,e:i});continue}i++;while(i<n&&src[i]!=='>')i++;i++;toks.push({t:'str',s:st,e:i});continue}
    if(c===62){if(src[i+1]==='>'){i+=2;toks.push({t:'dclose',s:st,e:i});continue}i++;continue}
    if(c===91){i++;toks.push({t:'aopen',s:st,e:i});continue}
    if(c===93){i++;toks.push({t:'aclose',s:st,e:i});continue}
    if(c===123||c===125){i++;continue}
    while(i<n&&!WS(src.charCodeAt(i))&&!DL(src.charCodeAt(i)))i++;
    if(i===st){i++;continue}
    const w=src.slice(st,i);
    if(w==='BI'){const re=/\sEI(?=\s|$)/g;re.lastIndex=i;const r=re.exec(src);i=r?r.index+r[0].length:n;toks.push({t:'op',v:'BI',s:st,e:i});continue}
    toks.push(/^[+-]?(\d+\.?\d*|\.\d+)$/.test(w)?{t:'num',v:parseFloat(w),s:st,e:i}:{t:'op',v:w,s:st,e:i})}
  return toks}
function csParse(src){const toks=csTokenize(src),ops=[];let args=[],start=-1;
  for(let i=0;i<toks.length;i++){const t=toks[i];
    if(t.t==='op'){ops.push({op:t.v,args,s:start<0?t.s:start,e:t.e});args=[];start=-1;continue}
    if(start<0)start=t.s;
    if(t.t==='aopen'){const arr=[];i++;while(i<toks.length&&toks[i].t!=='aclose'){arr.push(toks[i]);i++}args.push({t:'arr',v:arr});continue}
    if(t.t==='dopen'){let d=1;i++;while(i<toks.length&&d>0){if(toks[i].t==='dopen')d++;else if(toks[i].t==='dclose')d--;i++}i--;args.push({t:'dict'});continue}
    args.push(t)}
  return ops}
const mmul=(a,b)=>[a[0]*b[0]+a[1]*b[2],a[0]*b[1]+a[1]*b[3],a[2]*b[0]+a[3]*b[2],a[2]*b[1]+a[3]*b[3],a[4]*b[0]+a[5]*b[2]+b[4],a[4]*b[1]+a[5]*b[3]+b[5]];
const mapp=(m,x,y)=>[m[0]*x+m[2]*y+m[4],m[1]*x+m[3]*y+m[5]];
function toCmyk(c){if(!c)return[0,0,0,100];if(c.k)return c.k.map(v=>Math.round(v*1000)/10);if(c.g!=null)return[0,0,0,Math.round((1-c.g)*1000)/10];if(c.rgb)return[...c.rgb.map(v=>Math.round((1-v)*1000)/10),0];return[0,0,0,100]}
const isWhite=c=>{if(!c)return false;if(c.k)return c.k.every(v=>v<.03);if(c.g!=null)return c.g>.97;if(c.rgb)return c.rgb.every(v=>v>.97);return false};
function csInterpret(ops,sid=0,out=null,init=null,onDo=null){
  let ctm=init?init.ctm.slice():[1,0,0,1,0,0];const stack=[];let fill=init?init.fill:null,tm=[1,0,0,1,0,0],tlm=[1,0,0,1,0,0],font='',fsize=1,lead=0;
  out=out||{shows:[],paths:[],dos:[],shs:[]};const{shows,paths,dos,shs}=out;let path=null;
  const nums=o=>o.args.filter(a=>a.t==='num').map(a=>a.v);
  const newPath=()=>({sid,idx:[],x0:1e9,y0:1e9,x1:-1e9,y1:-1e9,reOnly:true,nsub:0,clip:false,rects:[]});
  const pt=(p,x,y)=>{const q=mapp(ctm,x,y);p.x0=Math.min(p.x0,q[0]);p.x1=Math.max(p.x1,q[0]);p.y0=Math.min(p.y0,q[1]);p.y1=Math.max(p.y1,q[1])};
  const show=(i)=>{const m=mmul(tm,ctm);shows.push({sid,i,x:m[4],y:m[5],size:fsize*Math.hypot(m[2],m[3]),font,color:fill})};
  ops.forEach((o,i)=>{const a=nums(o);
    switch(o.op){
      case 'q':stack.push({ctm,fill});break;
      case 'Q':{const t=stack.pop();if(t){ctm=t.ctm;fill=t.fill}break}
      case 'cm':if(a.length===6)ctm=mmul(a,ctm);break;
      case 'k':fill={k:a.slice(0,4)};break;
      case 'g':fill={g:a[0]};break;
      case 'rg':fill={rgb:a.slice(0,3)};break;
      case 'sc':case 'scn':if(a.length===4)fill={k:a};else if(a.length===3)fill={rgb:a};else if(a.length===1)fill={g:a[0]};break;
      case 'BT':tm=[1,0,0,1,0,0];tlm=[1,0,0,1,0,0];break;
      case 'Tm':if(a.length===6){tm=a.slice();tlm=a.slice()}break;
      case 'Td':tlm=mmul([1,0,0,1,a[0],a[1]],tlm);tm=tlm.slice();break;
      case 'TD':lead=-a[1];tlm=mmul([1,0,0,1,a[0],a[1]],tlm);tm=tlm.slice();break;
      case 'TL':lead=a[0];break;
      case 'T*':tlm=mmul([1,0,0,1,0,-lead],tlm);tm=tlm.slice();break;
      case 'Tf':{const nm=o.args.find(x=>x.t==='name');font=nm?nm.v:'';fsize=a[0]||1;break}
      case 'Tj':case 'TJ':show(i);break;
      case "'":tlm=mmul([1,0,0,1,0,-lead],tlm);tm=tlm.slice();show(i);break;
      case '"':tlm=mmul([1,0,0,1,0,-lead],tlm);tm=tlm.slice();show(i);break;
      case 'm':case 'l':if(!path)path=newPath();path.idx.push(i);if(o.op==='m'){path.nsub++}path.reOnly=false;pt(path,a[0],a[1]);break;
      case 'c':if(!path)path=newPath();path.idx.push(i);path.reOnly=false;pt(path,a[0],a[1]);pt(path,a[2],a[3]);pt(path,a[4],a[5]);break;
      case 'v':case 'y':if(!path)path=newPath();path.idx.push(i);path.reOnly=false;pt(path,a[0],a[1]);pt(path,a[2],a[3]);break;
      case 'h':if(path){path.idx.push(i)}break;
      case 're':{if(!path)path=newPath();path.idx.push(i);path.nsub++;const[x,y,w,h]=a;const c=[mapp(ctm,x,y),mapp(ctm,x+w,y),mapp(ctm,x+w,y+h),mapp(ctm,x,y+h)];
        const xs=c.map(p=>p[0]),ys=c.map(p=>p[1]);const r={x0:Math.min(...xs),x1:Math.max(...xs),y0:Math.min(...ys),y1:Math.max(...ys)};path.rects.push(r);
        path.x0=Math.min(path.x0,r.x0);path.x1=Math.max(path.x1,r.x1);path.y0=Math.min(path.y0,r.y0);path.y1=Math.max(path.y1,r.y1);break}
      case 'W':case 'W*':if(path)path.clip=true;break;
      case 'f':case 'F':case 'f*':case 'B':case 'B*':case 'b':case 'b*':case 'S':case 's':case 'n':
        if(path){path.idx.push(i);path.paint=o.op;path.fill=(['f','F','f*','B','B*','b','b*'].includes(o.op))?fill:null;path.w=path.x1-path.x0;path.h=path.y1-path.y0;paths.push(path);path=null}break;
      case 'sh':shs.push({sid,i});break;
      case 'Do':{const nm=o.args.find(x=>x.t==='name');const isForm=onDo?onDo(nm?nm.v:'',ctm.slice(),fill):false;if(!isForm)dos.push({sid,i,name:nm?nm.v:'',ctm:ctm.slice()});break}
    }});
  return out}
const decodeSt=st=>st instanceof PDFLib.PDFRawStream?PDFLib.decodePDFRawStream(st).decode():st.getContents();
/* dictionnaire de police du PDF : graisse (FontWeight) et largeurs des caractères (Widths) */
function pdfFontInfo(cc,sid,name){try{const{PDFName}=PDFLib;const st=cc.streams[sid];const F=st&&st.res&&st.res.lookup(PDFName.of('Font'));const fd=F&&F.lookup(PDFName.of(name));if(!fd)return{};
  const num=x=>{const v=cc.doc.context.lookup(x);return v&&v.asNumber?v.asNumber():null};
  let weight=null,desc=fd.lookup(PDFName.of('FontDescriptor'));const widths={};
  const W=fd.lookup(PDFName.of('Widths')),fc=fd.lookup(PDFName.of('FirstChar'));
  if(W&&fc){const f0=fc.asNumber();W.asArray().forEach((x,i)=>{const n=num(x);if(n!=null)widths[String.fromCharCode(f0+i)]=n})}
  else{const D=fd.lookup(PDFName.of('DescendantFonts'));const df=D&&cc.doc.context.lookup(D.asArray()[0]);
    if(df){desc=desc||df.lookup(PDFName.of('FontDescriptor'));const cw={};const A=df.lookup(PDFName.of('W'));
      if(A){const a=A.asArray().map(x=>cc.doc.context.lookup(x));for(let i=0;i<a.length;){const c0=a[i].asNumber();const nx=a[i+1];
        if(nx&&nx.asArray){nx.asArray().forEach((x,k)=>{const n=num(x);if(n!=null)cw[c0+k]=n});i+=2}else{const c1=nx.asNumber(),w=a[i+2].asNumber();for(let c=c0;c<=c1;c++)cw[c]=w;i+=3}}}
      const TU=fd.lookup(PDFName.of('ToUnicode'));if(TU){const t=latin1(decodeSt(TU));const hx=h=>parseInt(h,16),u=h=>{let r='';for(let i=0;i<h.length;i+=4)r+=String.fromCharCode(hx(h.slice(i,i+4)));return r};
        for(const blk of t.split('beginbfchar').slice(1)){for(const m of blk.split('endbfchar')[0].matchAll(/<([0-9a-fA-F]+)>\s*<([0-9a-fA-F]+)>/g)){const c=hx(m[1]);if(cw[c]!=null)widths[u(m[2])]=cw[c]}}
        for(const blk of t.split('beginbfrange').slice(1)){for(const m of blk.split('endbfrange')[0].matchAll(/<([0-9a-fA-F]+)>\s*<([0-9a-fA-F]+)>\s*<([0-9a-fA-F]+)>/g)){const a0=hx(m[1]),a1=hx(m[2]),b0=hx(m[3]);for(let c=a0;c<=a1&&c-a0<512;c++)if(cw[c]!=null)widths[String.fromCharCode(b0+c-a0)]=cw[c]}}}}}
  if(desc){const fw=desc.lookup(PDFName.of('FontWeight'));if(fw&&fw.asNumber)weight=fw.asNumber()}
  return{weight,widths}}catch(e){return{}}}
async function cardContent(bytes){
  const{PDFDocument,PDFArray,PDFName,PDFDict}=PDFLib;const doc=await PDFDocument.load(bytes.slice(0));const page=doc.getPage(0);const c=page.node.Contents();
  const parts=[];const add=o=>parts.push(decodeSt(doc.context.lookup(o)));
  if(c instanceof PDFArray){for(let i=0;i<c.size();i++)add(c.get(i))}else if(c)add(c);
  const src=parts.map(latin1).join('\n');const ops=csParse(src);
  const streams=[{sid:0,src,ops,res:page.node.Resources()}],out={shows:[],paths:[],dos:[],shs:[]};
  const xobj=res=>{try{const d=res&&res.lookup(PDFName.of('XObject'));return d instanceof PDFDict?d:null}catch(e){return null}};
  const run=(ops,sid,res,init,depth)=>csInterpret(ops,sid,out,init,(name,ctm,fill)=>{
    if(depth>8)return false;const X=xobj(res);if(!X)return false;const ref=X.get(PDFName.of(name));if(!ref)return false;const st=doc.context.lookup(ref);
    if(!st||!st.dict||st.dict.get(PDFName.of('Subtype'))!==PDFName.of('Form'))return false;
    let m=[1,0,0,1,0,0];try{const a=st.dict.lookup(PDFName.of('Matrix'));if(a)m=a.asArray().map(n=>n.asNumber())}catch(e){}
    let fsrc;try{fsrc=latin1(decodeSt(st))}catch(e){return false}
    const sid2=streams.length;const fops=csParse(fsrc);
    let fres=null;try{fres=st.dict.lookup(PDFName.of('Resources'))}catch(e){}
    streams.push({sid:sid2,src:fsrc,ops:fops,ref,st,res:fres||res});
    run(fops,sid2,fres||res,{ctm:mmul(m,ctm),fill},depth+1);return true});
  run(ops,0,page.node.Resources(),null,0);
  return{doc,page,src,ops,streams,...out,mb:page.getMediaBox()}}
async function detectBg(){ // fond uni = 1er aplat couvrant toute la page (couleur CMJN exacte)
  try{const cc=await cardContent(S.art.bytes);const{x,y,width:w,height:h}=cc.mb;
    const bg=cc.paths.find(p=>p.fill&&p.paint!=='n'&&!p.clip&&p.w>=w*.985&&p.h>=h*.985);
    S.bg=bg&&!isWhite(bg.fill)?{cmyk:toCmyk(bg.fill)}:null;
    const imgBg=cc.dos.some(d=>Math.hypot(d.ctm[0],d.ctm[1])>=w*.9&&Math.hypot(d.ctm[2],d.ctm[3])>=h*.9);
    S.bgKind=S.bg?'solid':(imgBg||cc.shs.length?'complex':'none')}catch(e){S.bg=null;S.bgKind='none'}}
function qrFromContent(cc){
  const{dos,mb}=cc;const inPage=p=>p.x0>=mb.x-1&&p.x1<=mb.x+mb.width+1&&p.y0>=mb.y-1&&p.y1<=mb.y+mb.height+1;const paths=cc.paths.filter(inPage);let cand=paths.filter(p=>p.fill&&!p.clip&&p.reOnly&&p.rects.length&&Math.min(p.w,p.h)>=.4&&Math.min(p.w,p.h)<=5&&Math.max(p.w,p.h)<=90);
  const bins=new Map();cand.forEach(p=>{const k=Math.round(Math.min(p.w,p.h)/p.rects.length>0.4?Math.min(...p.rects.map(r=>Math.min(r.x1-r.x0,r.y1-r.y0)))*20:0);if(!bins.has(k))bins.set(k,[]);bins.get(k).push(p)});
  let best=[];bins.forEach(v=>{if(v.length>best.length)best=v});
  let q=null;
  if(best.length>=60){q={paths:best,x0:Math.min(...best.map(p=>p.x0)),y0:Math.min(...best.map(p=>p.y0)),x1:Math.max(...best.map(p=>p.x1)),y1:Math.max(...best.map(p=>p.y1)),color:best[0].fill,kind:'vector'}}
  else{const big=paths.filter(p=>p.fill&&!p.clip&&p.reOnly&&p.nsub>=100&&p.w>30&&p.w<150&&Math.abs(p.w-p.h)<p.w*.15);
    if(big.length)q={paths:[big[0]],x0:big[0].x0,y0:big[0].y0,x1:big[0].x1,y1:big[0].y1,color:big[0].fill,kind:'vector'}}
  if(q){const w=q.x1-q.x0,h=q.y1-q.y0;if(w<25||w>150||Math.abs(w-h)>Math.max(w,h)*.2)q=null}
  if(!q){ // QR en image (carré)
    const im=dos.map(d=>({d,w:Math.hypot(d.ctm[0],d.ctm[1]),h:Math.hypot(d.ctm[2],d.ctm[3])})).find(o=>o.w>35&&o.w<150&&Math.abs(o.w-o.h)<o.w*.08);
    if(im){const c=im.d.ctm;q={paths:[],dos:[im.d],x0:c[4],y0:c[5],x1:c[4]+im.w,y1:c[5]+im.h,color:{k:[0,0,0,1]},kind:'image'}}}
  if(!q)return null;
  const qw=q.x1-q.x0,inBox=p=>p.x0<=q.x0-2&&p.x1>=q.x1+2&&p.y0<=q.y0-2&&p.y1>=q.y1+2&&p.w<qw*1.6&&p.h<qw*1.9;
  const box=paths.filter(p=>p.fill&&isWhite(p.fill)&&!p.clip&&inBox(p)).sort((a,b)=>a.w*a.h-b.w*b.h)[0]||null;
  const lim={x0:(box?box.x0:q.x0)-2,x1:(box?box.x1:q.x1)+2,y0:(box?box.y0:q.y0-16),y1:q.y0+1};
  const letters=paths.filter(p=>p.fill&&!isWhite(p.fill)&&!p.clip&&p!==box&&!q.paths.includes(p)&&p.y1<=lim.y1&&p.y0>=lim.y0&&p.x0>=lim.x0&&p.x1<=lim.x1&&p.h<10&&p.w<qw*1.1);
  const style=box&&letters.length?'boxtext':box?'box':letters.length?'text':'plain';
  const info=qrGridInfo(q);
  return{...q,box,letters,style,w:qw,h:q.y1-q.y0,...info}}
/* Lit la grille de modules du QR vectoriel : version, niveau de correction d'erreur (L/M/Q/H) et masque, depuis les bits de format */
function qrGridInfo(q){
  if(q.kind!=='vector'||!q.paths.length)return{};
  const rects=q.paths.flatMap(p=>p.rects);if(!rects.length)return{};
  const dims=rects.map(r=>Math.min(r.x1-r.x0,r.y1-r.y0)).sort((a,b)=>a-b),m=dims[Math.floor(dims.length/2)];
  const w=q.x1-q.x0,n=Math.round(w/m);if(n<21||n>177||(n-17)%4)return{n,version:(n-17)/4,ecc:null};
  const pitch=w/n,M=Array.from({length:n},()=>new Array(n).fill(false));
  rects.forEach(r=>{const c0=Math.round((r.x0-q.x0)/pitch),c1=Math.round((r.x1-q.x0)/pitch),r0=Math.round((q.y1-r.y1)/pitch),r1=Math.round((q.y1-r.y0)/pitch);
    for(let i=r0;i<r1;i++)for(let j=c0;j<c1;j++)if(i>=0&&j>=0&&i<n&&j<n)M[i][j]=true});
  const bit=(r,c)=>M[r][c]?1:0;let bits=0;
  [[8,0],[8,1],[8,2],[8,3],[8,4],[8,5],[8,7],[8,8],[7,8],[5,8],[4,8],[3,8],[2,8],[1,8],[0,8]].forEach(([r,c])=>{bits=(bits<<1)|bit(r,c)});
  let best=null;for(let d=0;d<32;d++){let rem=d<<10;for(let i=14;i>=10;i--)if(rem&(1<<i))rem^=0x537<<(i-10);const code=((d<<10)|rem)^0x5412;
    let x=code^bits,dist=0;while(x){dist+=x&1;x>>=1}if(!best||dist<best.dist)best={d,dist}}
  const ecc=best&&best.dist<=3?['M','L','H','Q'][best.d>>3]:null;
  return{n,version:(n-17)/4,ecc,mask:best&&best.dist<=3?best.d&7:null}}
const BOLD=/black|bold|heavy|semibold|extrabold/i;
async function textLinesOf(bytes,cc){
  const pd=await pdfjsLib.getDocument({isEvalSupported:false,data:bytes.slice(0)}).promise,pg=await pd.getPage(1);
  try{await pg.getOperatorList()}catch(e){}
  const tc=await pg.getTextContent({disableCombineTextItems:true});
  const items=tc.items.filter(it=>it.str!==undefined&&it.str.length).map(it=>({str:it.str,x:it.transform[4],y:it.transform[5],size:Math.hypot(it.transform[2],it.transform[3]),w:it.width,fontName:it.fontName}));
  const fname=id=>{try{const o=pg.commonObjs.get(id);return String(o&&o.name||'').replace(/^[A-Z]{6}\+/,'')}catch(e){return''}};
  items.sort((a,b)=>Math.abs(a.y-b.y)>.6?b.y-a.y:a.x-b.x);
  const lines=[];
  for(const it of items){const L=lines[lines.length-1];
    if(L&&Math.abs(L.y-it.y)<.6&&it.x-L.x1<it.size*2.5&&it.x>=L.x0-.5){const gap=it.x-L.x1;L.text+=(gap>it.size*.28&&!/\s$/.test(L.text)&&!/^\s/.test(it.str)?' ':'')+it.str;L.x1=Math.max(L.x1,it.x+it.w);L.segs.push(it)}
    else lines.push({text:it.str,x0:it.x,x1:it.x+it.w,y:it.y,size:it.size,font:fname(it.fontName),segs:[it]})}
  lines.forEach((l,i)=>{l.id=i;l.text=l.text.replace(/\s+/g,' ').trim();
    const sh=cc.shows.find(s=>Math.abs(s.y-l.y)<1&&s.x>=l.x0-1.5&&s.x<=l.x1+1);l.color=sh?sh.color:null;
    /* plusieurs polices sur la ligne (ex. prénom Regular + NOM Bold) : un morceau par police, avec ses largeurs de lettres */
    {const parts=[];(l.segs||[]).forEach(it=>{const q=parts[parts.length-1];if(q&&q.fid===it.fontName){q.text+=it.str;q.x1=it.x+it.w}else parts.push({fid:it.fontName,font:fname(it.fontName),text:it.str,x0:it.x,x1:it.x+it.w})});
      if(parts.length>1&&parts.some(q=>q.text.trim())){parts.forEach(q=>{q.text=q.text.trim();const s2=cc.shows.find(s=>Math.abs(s.y-l.y)<1&&s.x>=q.x0-1.5&&s.x<=q.x1-.5);
          if(s2){const fi=pdfFontInfo(cc,s2.sid,s2.font);q.weight=fi.weight||null;const wd={};for(const ch of q.text){const c=ch.charCodeAt(0);if(fi.widths&&fi.widths[ch]!=null&&c>32)wd[c]=fi.widths[ch]}q.widths=Object.keys(wd).length?wd:null}});
        l.parts=parts.filter(q=>q.text)}}
    if(sh){const fi=pdfFontInfo(cc,sh.sid,sh.font);l.weight=fi.weight||null;const wd={};for(const ch of l.text){const c=ch.charCodeAt(0);if(fi.widths&&fi.widths[ch]!=null&&c>32)wd[c]=fi.widths[ch]}l.widths=Object.keys(wd).length?wd:null}
    if(l.parts&&l.parts.length>1&&l.parts[0].widths){l.widths=l.parts[0].widths;if(l.parts[0].weight)l.weight=l.parts[0].weight}l.showIdx=cc.shows.filter(s=>Math.abs(s.y-l.y)<1&&s.x>=l.x0-1.5&&s.x<=l.x1+1).map(s=>[s.sid,s.i])});
  const mb=cc.mb;return lines.filter(l=>l.text&&l.x1>=mb.x&&l.x0<=mb.x+mb.width&&l.y>=mb.y&&l.y<=mb.y+mb.height)}
const PHONE=/^[+(]?[\d\s().-]{8,}$/;
const PH=/<<\s*([^<>]+?)\s*>>/g,PHQR=['url','lien','qr','qrcode','qrcodes','qr code','qr codes','code qr','lien qr','url qr'];
const compact=t=>t.replace(/\s+/g,'').toLowerCase();
function guessRoles(lines){
  if(lines.some(l=>/<<[^<>]+>>/.test(l.text))){ // fichier de fusion (InDesign) : chaque <<champ>> = colonne du CSV
    lines.forEach(l=>{const f=[...l.text.matchAll(PH)].map(m=>m[1]);
      if(!f.length)l.role=compact(l.text)==='vkard.io'?'qrlabel':'fixe';
      else if(f.length===1&&PHQR.includes(norm(f[0]))&&l.text.replace(PH,'').trim()==='')l.role='qr';
      else l.role='champ';l.fields=f});
    return}
  const cand=lines.filter(l=>!l.text.includes('@')&&!PHONE.test(l.text));
  lines.forEach(l=>{l.role='fixe'});
  const cand2=cand.filter(l=>compact(l.text)!=='vkard.io');cand.length=0;cand.push(...cand2);
  lines.forEach(l=>{if(compact(l.text)==='vkard.io')l.role='qrlabel'});
  lines.forEach(l=>{if(l.role==='qrlabel')return;if(l.text.includes('@'))l.role='email';else if(PHONE.test(l.text)&&(l.text.match(/\d/g)||[]).length>=8)l.role='tel'});
  const byPh=cand.find(l=>/pr[ée]nom/i.test(l.text));
  const bold=cand.filter(l=>BOLD.test(l.font)).sort((a,b)=>b.y-a.y);
  const name=byPh||bold[0]||cand.slice().sort((a,b)=>b.size-a.size||b.y-a.y)[0];
  if(name){name.role='nom_complet';
    // prénom et nom sur deux lignes (ex. « Sulyvan » puis « ALVES ») : ligne voisine au même alignement
    const isUp=t=>t===t.toUpperCase()&&/[A-ZÀ-Ý]/.test(t),near=l=>l!==name&&l.role==='fixe'&&Math.abs(l.x0-name.x0)<2&&Math.abs(l.y-name.y)<Math.max(l.size,name.size)*1.8&&l.text.split(' ').length<=3;
    const other=cand.find(l=>near(l)&&isUp(name.text)!==isUp(l.text));
    if(other&&!/pr[ée]nom/i.test(name.text)){const[pre,nom]=isUp(name.text)?[other,name]:[name,other];pre.role='prenom';nom.role='nom'}
    let prev=cand.filter(l=>l.role==='prenom'||l.role==='nom').sort((a,b)=>a.y-b.y)[0]||name;for(const l of cand.filter(l=>l.y<prev.y).sort((a,b)=>b.y-a.y)){
      if(l===prev||l.role!=='fixe')continue;if(Math.abs(l.x0-name.x0)>4||prev.y-l.y>prev.size*2.2||l.size>name.size)break;
      if(BOLD.test(l.font)&&!/^poste$/i.test(l.text)&&l.font!==name.font&&l.size>=name.size*.8)break;
      l.role='poste';prev=l}}
}
/* rôle probable d'un texte qu'on passe de « fixe » à « variable » */
const guessRole=t=>/@/.test(t)?'email':/\d[\d .]{7,}/.test(t)?'tel':/\b[A-ZÉÈÀÇ]{2,}\b/.test(t)&&t.trim().split(/\s+/).length<=4?'nom_complet':'poste';
const ROLES=[['champ','Champ <<…>> de mon fichier'],['qr','C\'est l\'emplacement du QR'],['qrlabel','Texte VKARD.IO sous le QR (retiré)'],['nom_complet','Prénom + NOM'],['prenom','Prénom'],['nom','Nom'],['poste','Poste'],['email','E-mail'],['tel','Téléphone'],['fixe','Texte fixe (conservé)']];
/* Emplacement du QR d'après le repère <<QRCodes>> : le plus petit aplat qui contient le repère = cadre du QR (boîte charte) */
function qrFromPlaceholder(cc,lines){
  const L=lines.find(l=>l.role==='qr');if(!L)return null;const{x,y,width:W,height:H}=cc.mb;
  const tx0=L.x0,tx1=L.x1,ty0=L.y-L.size*.2,ty1=L.y+L.size*.8;
  const frame=cc.paths.filter(p=>p.fill&&!p.clip&&p.x0<=tx0+1&&p.x1>=tx1-1&&p.y0<=ty0+1&&p.y1>=ty1-1&&p.w<W*.9&&p.h<H*.95).sort((a,b)=>a.w*a.h-b.w*b.h)[0];
  let fx0,fy0,fx1,fy1;if(frame){fx0=frame.x0;fy0=frame.y0;fx1=frame.x1;fy1=frame.y1}else{const w=Math.max(tx1-tx0,40);fx0=(tx0+tx1)/2-w/2;fx1=fx0+w;fy1=ty1+w*.15;fy0=fy1-w}
  const fw=fx1-fx0,fh=fy1-fy0,lab=lines.find(l=>l.role==='qrlabel'&&l.x0>=fx0-3&&l.x1<=fx1+3&&l.y<=fy1+2&&l.y>=fy0-20);
  let style,qx0,qy1,qs;
  if(fh/fw>1.05){style='boxtext';const u=fw/73.7;qs=QS_SIDE*u;qx0=fx0+5.67*u;qy1=fy1-5.63*u}
  else if(lab&&lab.y<fy0){style='text';qs=fw;qx0=fx0;qy1=fy1}
  else{style='box';const u=fw/73.7;qs=QS_SIDE*u;qx0=fx0+5.67*u;qy1=fy1-5.67*u}
  return{kind:'placeholder',paths:frame?[frame]:[],letters:[],box:null,style,x0:qx0,x1:qx0+qs,y1:qy1,y0:qy1-qs,w:qs,h:qs,color:{k:[0,0,0,1]},col:L.fields&&L.fields[0]||'url',frame:{x0:fx0,y0:fy0,x1:fx1,y1:fy1}}}
let ana=null;
async function analyzeFile(file){autoNaming(parseNameInfo(file.name));
  const box=$('#anaBox');box.hidden=false;box.innerHTML='<p class="note">Analyse en cours…</p>';
  try{const bytes=new Uint8Array(await file.arrayBuffer());const cc=await cardContent(bytes);
    if(cc.page.getRotation().angle)throw new Error('page pivotée non gérée');
    let qr=qrFromContent(cc);const lines=await textLinesOf(bytes,cc);guessRoles(lines);
    if(lines.some(l=>l.role==='qr')){const ph=qrFromPlaceholder(cc,lines);if(ph&&(!qr||qr.kind!=='vector'))qr=ph;else if(ph&&qr)qr.col=ph.col}
    const bgp=cc.paths.find(p=>p.fill&&!p.clip&&p.w>=cc.mb.width*.985&&p.h>=cc.mb.height*.985);
    ana={bytes,cc,qr,lines,name:file.name,bg:bgp&&!isWhite(bgp.fill)?{cmyk:toCmyk(bgp.fill)}:null,style:qr?qr.style:'boxtext'};
    renderAna(false);await createFromAna();openReview()}catch(e){box.innerHTML='<p class="note bad">Analyse impossible : '+(e&&e.message||e)+'</p>'}}
const STYLE_TXT={boxtext:'boîte blanche + texte VKARD.IO',box:'boîte blanche',text:'QR + texte VKARD.IO (sans boîte)',plain:'QR seul'};
function renderAna(done){
  const box=$('#anaBox'),A=ana;box.innerHTML='';if(!A)return;
  const h=document.createElement('h3');h.textContent=(done?'Carte : ':'Détection : ')+A.name;box.appendChild(h);
  const vars=A.lines.filter(l=>!['fixe','qr','qrlabel'].includes(l.role)).map(l=>l.role==='champ'?(l.fields||[]).join(' '):(ROLES.find(r=>r[0]===l.role)||['',''])[1]);
  const sum=document.createElement('p');sum.className='note '+(A.qr?'ok':'warn');sum.style.margin='0 0 8px';
  sum.textContent=(A.qr?`QR ${mmFmt(A.qr.w/MM)} mm (${STYLE_TXT[A.style]})`:'Aucun QR détecté')+' · '+(vars.length?`${vars.length} champ${vars.length>1?'s':''} : ${vars.join(', ')}`:'aucun champ texte')+' · '+(A.bg?'fond uni':'sans fond uni');
  const b=document.createElement('button');b.className='btn sm';b.textContent='Vérifier / corriger la carte';b.onclick=()=>openReview();
  box.append(sum,b)}
/* ---------- Fenêtre « Vérifier la nouvelle carte » : carte en grand, éléments numérotés, rôles, polices, style du QR ---------- */
function openReview(){if(!ana)return;$('#review').hidden=false;renderReview()}
$('#rvOk').onclick=()=>{$('#review').hidden=true;drawArt().then(drawOverlay)};
let rvSel=null,rvBusy=false;
async function rvApply(){if(rvBusy)return;rvBusy=true;try{await createFromAna()}finally{rvBusy=false}renderReview()}
function renderReview(){
  const A=ana;if(!A)return;const mb=A.cc.mb;
  $('#rvTitle').textContent='Vérifier la nouvelle carte : '+A.name;
  $('#rvSum').textContent=`Carte ${mmFmt(mb.width/MM)} × ${mmFmt(mb.height/MM)} mm · ${A.bg?'fond : aplat uni (CMJN '+A.bg.cmyk.map(v=>Math.round(v)).join('/')+')':'sans aplat uni'}`;
  // aperçu (rendu une seule fois par carte)
  const cv=$('#rvCv'),W=Math.max(320,Math.min(900,$('#rvCard').clientWidth||700)),k=W/mb.width,H=mb.height*k;
  if(cv.dataset.for!==A.name+A.bytes.length){cv.dataset.for=A.name+A.bytes.length;cv.width=W*2;cv.height=H*2;
    pdfjsLib.getDocument({isEvalSupported:false,data:A.bytes.slice(0)}).promise.then(d=>d.getPage(1)).then(pg=>{const vp=pg.getViewport({scale:1});return pg.render({canvasContext:cv.getContext('2d'),viewport:vp,transform:[cv.width/vp.width,0,0,cv.height/vp.height,0,0]}).promise}).catch(()=>{})}
  const ov=$('#rvOv');ov.setAttribute('viewBox',`0 0 ${W} ${H}`);ov.innerHTML='';
  const items=[];if(A.qr)items.push({kind:'qr'});A.lines.forEach(l=>items.push({kind:'line',l}));
  const colorOf=it=>it.kind==='qr'?'#2F86C4':it.l.role==='fixe'?'#9aa0a6':it.l.role==='qrlabel'?'#2F86C4':'#e67e22';
  const boxOf=it=>it.kind==='qr'?(A.qr.frame||A.qr.box||A.qr):{x0:it.l.x0,y0:it.l.y-it.l.size*.25,x1:it.l.x1,y1:it.l.y+it.l.size*.85};
  items.forEach((it,i)=>{const b=boxOf(it),x=(b.x0-mb.x)*k,y=(mb.y+mb.height-b.y1)*k,w=(b.x1-b.x0)*k,h=(b.y1-b.y0)*k,c=colorOf(it);
    const g=document.createElementNS(NS,'g');g.style.cursor='pointer';g.onclick=()=>{rvSel=i;renderReview();const r=document.getElementById('rv'+i);if(r)r.scrollIntoView({block:'nearest'})};
    const r=document.createElementNS(NS,'rect');r.setAttribute('x',x);r.setAttribute('y',y);r.setAttribute('width',w);r.setAttribute('height',h);r.setAttribute('fill',rvSel===i?'rgba(80,166,225,.18)':'transparent');r.setAttribute('stroke',c);r.setAttribute('stroke-width',rvSel===i?2.5:1.5);if(it.kind==='line'&&it.l.role==='fixe')r.setAttribute('stroke-dasharray','4 3');
    const cx=Math.max(9,x-2),cy=Math.max(9,y-2),ci=document.createElementNS(NS,'circle');ci.setAttribute('cx',cx);ci.setAttribute('cy',cy);ci.setAttribute('r',8);ci.setAttribute('fill',c);
    const t=document.createElementNS(NS,'text');t.setAttribute('x',cx);t.setAttribute('y',cy+3.5);t.setAttribute('text-anchor','middle');t.setAttribute('font-size','10');t.setAttribute('font-weight','700');t.setAttribute('fill','#fff');t.textContent=i+1;
    g.append(r,ci,t);ov.appendChild(g)});
  // lignes
  const L=$('#rvList');L.innerHTML='';
  items.forEach((it,i)=>{const row=document.createElement('div');row.id='rv'+i;row.className='rv-row'+(rvSel===i?' on':'')+(it.kind==='qr'?' qr':it.l.role==='fixe'?' fixe':'');
    row.onclick=ev=>{if(ev.target.closest('select,button'))return;rvSel=i;renderReview()};
    const n=document.createElement('span');n.className='n';n.textContent=i+1;row.appendChild(n);
    if(it.kind==='qr'){const q=A.qr;
      const t=document.createElement('div');t.className='txt';t.textContent='QR code';
      const sub=document.createElement('div');sub.className='sub';sub.textContent=`QR de ${mmFmt(q.w/MM)} mm, remplacé par le lien de chaque carte`;sub.title=`${q.kind==='image'?'image':q.kind==='placeholder'?'repère <<'+q.col+'>>':'vectoriel'}`+(q.version?` · version ${q.version} (${q.n}×${q.n})`:'')+(q.ecc?` · correction ${q.ecc}`:'');
      const ctl=document.createElement('div');ctl.className='ctl';const st=document.createElement('select');Object.keys(QS).forEach(kk=>{const o=document.createElement('option');o.value=kk;o.textContent=QS[kk].label;st.appendChild(o)});st.value=A.style;st.onchange=()=>{A.style=st.value;rvApply()};
      ctl.append('Style :',st);row.append(t,sub,ctl)}
    else{const l=it.l;const t=document.createElement('div');t.className='txt';t.textContent=l.text;
      const sub=document.createElement('div');sub.className='sub';{const el=l.elId?byId(l.elId):null,w=(el&&el.fontWeight)||l.weight;sub.textContent=`Police ${(l.font||'?').replace(/-/g,' ')} · ${+l.size.toFixed(1)} pt`;sub.title=w?'graisse '+weightName(w)+' ('+w+')':''}
      const ctl=document.createElement('div');ctl.className='ctl';
      const isFix=l.role==='fixe',q=document.createElement('div');q.className='rv-q';q.textContent='Ce texte change-t-il d\'une carte à l\'autre ?';
      const seg=document.createElement('div');seg.className='seg';
      const bV=document.createElement('button');bV.textContent='Oui, il vient de mon fichier';bV.className=isFix?'':'on';
      const bF=document.createElement('button');bF.textContent='Non, identique partout';bF.className=isFix?'on':'';
      bV.onclick=()=>{if(l.role!=='fixe')return;l.role=l._varRole||guessRole(l.text);rvApply()};
      bF.onclick=()=>{if(l.role==='fixe')return;l._varRole=l.role;l.role='fixe';rvApply()};
      seg.append(bV,bF);ctl.append(q,seg);
      if(!isFix){const sel=document.createElement('select');sel.title='Ce que ce texte affiche';
        const grp=(lab,list)=>{const g=document.createElement('optgroup');g.label=lab;list.forEach(([v,t])=>{const o=document.createElement('option');o.value=v;o.textContent=t;g.appendChild(o)});sel.appendChild(g)};
        grp('Ce texte affiche…',ROLES.filter(r=>!['fixe','qr','qrlabel'].includes(r[0])));grp('Autre',ROLES.filter(r=>['qr','qrlabel'].includes(r[0])));
        sel.value=l.role;sel.onchange=()=>{l.role=sel.value;rvApply()};ctl.appendChild(sel)}
      const e=l.elId&&!['fixe','qr','qrlabel'].includes(l.role)?byId(l.elId):null;
      if(e){const ok=fontOk(e),f=fontById(e.font);const chip=document.createElement('span');chip.className='fchip '+(ok?'ok':'warn');chip.textContent=ok?'✓ '+f.label:'⚠ '+(e.fontLabel||e.fontPs)+' → '+f.label;chip.title=ok?'Police trouvée sur ce poste':'Police demandée introuvable sur ce poste : remplacée';
        const pick=document.createElement('button');pick.className='btn sm';pick.textContent=ok?'Changer':'Choisir la police';pick.onclick=()=>openFontPicker('Police pour « '+l.text+' »'+(e.fontLabel?' (demandée : '+e.fontLabel+')':''),font=>applyFontChoice(e,font),(e.fontLabel||'').split(' ')[0]);
        ctl.append(chip,pick)}
      row.append(t,sub,ctl)}
    L.appendChild(row)})}
async function createFromAna(){
  const A=ana,mb=A.cc.mb;const cc=await cardContent(A.bytes);const remove=new Set();
  const RM=(sid,i)=>remove.add(sid+':'+i);
  A.lines.filter(l=>l.role!=='fixe').forEach(l=>l.showIdx.forEach(([sid,i])=>RM(sid,i)));
  const varLines=A.lines.filter(l=>!['fixe','qr','qrlabel'].includes(l.role));
  const qr=A.qr;
  if(qr){qr.paths.forEach(p=>p.idx.forEach(i=>RM(p.sid,i)));(qr.dos||[]).forEach(d=>RM(d.sid,d.i));
    qr.letters.forEach(p=>p.idx.forEach(i=>RM(p.sid,i)));if(qr.box)qr.box.idx.forEach(i=>RM(qr.box.sid,i))}
  // visuel nettoyé : on réécrit le flux de contenu sans les opérations retirées
  const ctx=cc.doc.context,touched=new Set([...remove].map(k=>+k.split(':')[0]));
  for(const st of cc.streams){if(st.sid!==0&&!touched.has(st.sid))continue;
    const kept=st.ops.filter((o,i)=>!remove.has(st.sid+':'+i)).map(o=>st.src.slice(o.s,o.e)).join('\n');
    const enc=new Uint8Array(kept.length);for(let i=0;i<kept.length;i++)enc[i]=kept.charCodeAt(i)&255;
    if(st.sid===0)cc.page.node.set(PDFLib.PDFName.of('Contents'),ctx.register(ctx.flateStream(enc)));
    else{const ns=ctx.flateStream(enc);for(const[k,v]of st.st.dict.entries()){const kn=k.asString();if(!['/Length','/Filter','/DecodeParms'].includes(kn))ns.dict.set(k,v)}ctx.assign(st.ref,ns)}}
  const clean=await cc.doc.save();
  const art={bytes:clean};S.fit='auto';$('#fitSel').value='auto';
  await setArt(new Uint8Array(clean),A.name.replace(/\.pdf$/i,'')+' (nettoyé).pdf',false);
  S.bg=A.bg;await drawArt();
  const pl=artPlace(S.art),offX=pl.ox,offY=pl.oy,sx=pl.sx,sy=pl.sy,top=ypdf=>(mb.y+mb.height-ypdf)/MM;
  const mk=o=>Object.assign({id:'e'+(S.nextId++)},o),els=[];
  if(qr){const u=(qr.w/MM*sx)/QS_SIDE,st=QS[A.style];
    els.push(mk({type:'qr',name:'QR code',col:qr.col||'url',style:A.style,x:r2((qr.x0-mb.x)/MM*sx+offX-st.qx*u),y:r2(top(qr.y1)*sy+offY-st.qy*u),size:r2(qr.w/MM*sx),ecc:qr.ecc||'M',color:toCmyk(qr.color),boxColor:[0,0,0,0]}))}
  const qb=qr?(qr.box||qr.frame||qr):null,qLeft=qr?(qb.x0-mb.x)/MM*sx+offX:null,qTop=qr?top(qb.y1)*sy+offY:0,qBot=qr?top(qb.y0)*sy+offY:0;
  const phTpl=l=>{let t=l.text;t=t.replace(/(\+\s*)?<<\s*([^<>]+?)\s*>>/g,(m,plus,f)=>ALIAS[4].includes(norm(f))?`{${f}|tel}`:(plus?'+':'')+`{${f}}`);return t.replace(PH,'{$1}')};
  const tpl={champ:phTpl,nom_complet:l=>/\b[A-ZÉÈÀÇ]{2,}\b/.test(l.text)?'{Prénom} {Nom|upper}':'{Prénom} {Nom}',prenom:()=>'{Prénom}',nom:l=>l.text===l.text.toUpperCase()?'{Nom|upper}':'{Nom}',email:()=>'{Email}',tel:()=>'{Téléphone|tel}',poste:()=>'{Poste}'};
  const labels={champ:'Champ',nom_complet:'Nom',prenom:'Prénom',nom:'Nom',poste:'Poste',email:'Email',tel:'Téléphone'};
  const groups=[];varLines.forEach(l=>{if(l.role==='poste'&&groups.length&&groups[groups.length-1].role==='poste')groups[groups.length-1].lines.push(l);else groups.push({role:l.role,lines:[l]})});
  for(const g of groups){const l=g.lines[0],last=g.lines[g.lines.length-1];if(g.role==='champ')labels.champ=(l.fields||[]).join(' ')||'Champ';
    const size=l.size,x=(l.x0-mb.x)/MM*sx+offX,ytop=(top(l.y)-size/MM*ASC)*sy+offY;
    const lab=(l.font||'').replace(/-/g,' ').trim();const bold=BOLD.test(l.font);
    let maxW=0;if(qLeft!=null&&ytop+size/MM>qTop-1&&ytop<qBot&&qLeft>x)maxW=r2(qLeft-x-1.2);
    /* texte centré sur la carte (ou sur le QR) : on mémorise le centre, pour que les noms plus courts/longs restent centrés */
    let align,ax=x;{const c=(l.x0+l.x1)/2,tol=1.5*MM,ctrs=[mb.x+mb.width/2];if(qr)ctrs.push((qr.x0+qr.x1)/2);
      if(ctrs.some(v=>Math.abs(c-v)<tol)){align='center';ax=(c-mb.x)/MM*sx+offX;maxW=0}}
    g.lines.forEach(x=>x.elId='e'+S.nextId);
    let fieldFontReq;{const t0=tpl[g.role](l),flds=tplFields(t0),P=l.parts;
      if(P&&P.length>1&&flds.length>1){const a=P[0],z=P[P.length-1];if(z.fid!==a.fid)fieldFontReq={[flds[flds.length-1]]:{fontLabel:(z.font||'').replace(/-/g,' ').trim()||undefined,fontPs:z.font||undefined,fontWeight:z.weight||undefined,fontWidths:z.widths||undefined,bold:BOLD.test(z.font||'')}}}}
    els.push(mk({type:'text',name:labels[g.role]||'Texte',tpl:tpl[g.role](l),fieldFontReq,font:bold?'helv-b':'helv',fontLabel:lab||undefined,fontPs:l.font||undefined,fontWeight:l.weight||undefined,fontWidths:l.widths||undefined,size:r2(size*sy),x:r2(ax),align,y:r2(ytop),color:toCmyk(l.color),lh:g.lines.length>1?r2((l.y-g.lines[1].y)/size):1.2,maxW}))}
  const keepEls=!els.length&&S.els.length;if(!keepEls){S.els=els;S.sel=null;S.elsAreDemo=false;S._place=null}S.variantEl='';S.art2=null;
  // polices : Avenir etc. depuis les polices installées si disponibles
  const miss=new Set(),found=new Set();
  {const rf=await resolveFonts(S.els);rf.found.forEach(x=>found.add(x));rf.missing.forEach(x=>miss.add(x))}
  refreshVariant();renderList();renderForm();drawAll();drawArt().then(drawOverlay);reportMissing();
  $('#log').textContent='Modèle créé depuis la carte : '+els.length+' éléments.'+(found.size?' Polices trouvées : '+[...found].join(', ')+'.':'')+(miss.size?' Polices introuvables : '+[...miss].join(', ')+' (remplacées par Arial ; ajoute-les avec « Polices installées… »).':'')+(S.data.demo?' Ouvre maintenant ton Excel ou CSV (étape 2).':'');
  renderAna(true);if(!$('#review').hidden)renderReview()}
$('#anaIn').onchange=ev=>{const f=ev.target.files[0];if(f)analyzeFile(f);ev.target.value=''};

/* ---------- Formats de planche : formats fournis (mis à jour en direct) + formats enregistrés sur ce poste ---------- */
const BUILTIN_FORMATS=[ // nom : Support · Matière · nombre de cartes · taille de carte
  {id:'aplat-304x412-18',label:'À plat · 18 cartes · 89,5 × 58 mm',sheet:{pageW:304,pageH:412,cols:3,rows:6,cardW:89.5,cardH:58,gapX:7,gapY:9,mL:11.5,mT:8,fillEnd:true}},
  {id:'board-pvc-21',label:'Board A3 · PVC blanc / noir · 21 cartes · 85,5 × 54 mm',card:{w:85.5,h:54},sheet:{pageW:300,pageH:420,cols:3,rows:7,cardW:85.5,cardH:54,gapX:0,gapY:0,mL:43.5,mT:42,fillEnd:true}},
  {id:'board-bambou-21',label:'Board A3 · Bambou · 21 cartes · 85,2 × 53,7 mm',card:{w:85.2,h:53.7},sheet:{pageW:300,pageH:420,cols:3,rows:7,cardW:85.2,cardH:53.7,gapX:0,gapY:0,mL:44.4,mT:44.1,fillEnd:true}},
  {id:'board-metal-21',label:'Board A3 · Métal Silver / Gold · 21 cartes · 85 × 54 mm',card:{w:85,h:54},sheet:{pageW:300,pageH:420,cols:3,rows:7,cardW:85,cardH:54,gapX:0,gapY:0,mL:45,mT:42,fillEnd:true}}];
const LS=(k,d)=>{if(EMBED){const v=REMOTE[k];return v===undefined||v===null?d:v}try{return JSON.parse(localStorage.getItem(k)||'null')??d}catch(e){return d}},
  LSset=(k,v)=>{if(EMBED){REMOTE[k]=v;fetch('/api/planche/store/'+encodeURIComponent(k),{method:'PUT',headers:{'content-type':'application/json'},body:JSON.stringify({value:v})}).catch(()=>{});return}try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}};
const userFormats=()=>LS('planche.formats',[]),saveUserFormats=l=>LSset('planche.formats',l);
const overrides=()=>LS('planche.formatOverrides',{}),saveOverrides=o=>LSset('planche.formatOverrides',o);
const allFormats=()=>{const o=overrides();return[...BUILTIN_FORMATS.map(f=>o[f.id]?{...f,...o[f.id],builtin:true,modified:true}:{...f,builtin:true}),...userFormats()]};
const KEYS=['pageW','pageH','cols','rows','cardW','cardH','gapX','gapY','mL','mT'];
const sameSheet=(a,b)=>KEYS.every(x=>Math.abs((a[x]||0)-(b[x]||0))<.001);
const fmtDesc=sh=>`Page ${mmFmt(sh.pageW)} × ${mmFmt(sh.pageH)} mm · ${sh.cols} × ${sh.rows} = ${sh.cols*sh.rows} cartes de ${mmFmt(sh.cardW)} × ${mmFmt(sh.cardH)} mm · écarts ${mmFmt(sh.gapX)} / ${mmFmt(sh.gapY)} mm · marges ${mmFmt(sh.mL)} / ${mmFmt(sh.mT)} mm`;
function renderFormats(){
  const sel=$('#fmtSel'),L=allFormats();if(!S.fmtId||!L.some(f=>f.id===S.fmtId)){const m=L.find(f=>sameSheet(f.sheet,S.sheet));S.fmtId=m?m.id:''}
  const f=L.find(x=>x.id===S.fmtId),changed=f&&!sameSheet(f.sheet,S.sheet);sel.innerHTML='';
  L.forEach(x=>{const o=document.createElement('option');o.value=x.id;o.textContent=x.label+(x.builtin?(x.modified?' (fourni, modifié)':''):' (enregistré)')+(x.id===S.fmtId&&changed?' — réglages modifiés':'');sel.appendChild(o)});
  if(!f){const o=document.createElement('option');o.value='';o.textContent='Format personnalisé (non enregistré)';sel.appendChild(o)}
  sel.value=S.fmtId;$('#fmtNote').textContent=(f&&f.card?`Carte finie ${mmFmt(f.card.w)} × ${mmFmt(f.card.h)} mm`+((S.sheet.cardW-f.card.w)>.05?` + ${mmFmt((S.sheet.cardW-f.card.w)/2)} mm de fond perdu · `:' · sans fond perdu, cartes jointives · '):'')+fmtDesc(S.sheet)+(S.sheet.fillEnd?' · planche incomplète calée à la fin':' · planche incomplète remplie depuis le début')+(changed?' · différent du format enregistré':'');
  $('#fmtUpdate').hidden=!changed;$('#fmtUpdate').textContent=f?'Mettre à jour « '+f.label+' »':'';
  $('#fmtReset').hidden=!(f&&f.builtin&&f.modified);$('#fmtDel').hidden=!f||f.builtin;$('#fmtRename').hidden=!f}
function applyFormat(f){Object.assign(S.sheet,f.sheet);S.fmtId=f.id;setTimeout(()=>autoNaming(null));syncSheetInputs();sheetInfo();drawSheet();sizeBox();drawArt().then(drawOverlay);LSset('planche.lastFormat',f.id)}
$('#fmtSel').onchange=e=>{const f=allFormats().find(x=>x.id===e.target.value);if(f)applyFormat(f)};
$('#fmtUpdate').onclick=()=>{const f=allFormats().find(x=>x.id===S.fmtId);if(!f)return;
  if(f.builtin){const o=overrides();o[f.id]={label:f.label,sheet:{...S.sheet}};saveOverrides(o)}else saveUserFormats(userFormats().map(x=>x.id===f.id?{...x,sheet:{...S.sheet}}:x));
  LSset('planche.lastFormat',f.id);  renderFormats();$('#log').textContent='Format « '+f.label+' » mis à jour sur ce poste.'};
$('#fmtReset').onclick=()=>{const o=overrides();delete o[S.fmtId];saveOverrides(o);const f=allFormats().find(x=>x.id===S.fmtId);if(f)applyFormat(f);$('#log').textContent='Format d\'origine rétabli.'};
$('#fmtSave').onclick=()=>{const name=$('#fmtName').value.trim()||('Format '+mmFmt(S.sheet.pageW)+' × '+mmFmt(S.sheet.pageH)+' · '+S.sheet.cols*S.sheet.rows+' cartes');
  const id='u'+Date.now();saveUserFormats([...userFormats(),{id,label:name,sheet:{...S.sheet}}]);S.fmtId=id;LSset('planche.lastFormat',id);$('#fmtName').value='';renderFormats();$('#log').textContent='Format « '+name+' » enregistré sur ce poste.'};
$('#fmtRename').onclick=()=>{const name=$('#fmtName').value.trim();if(!name){$('#fmtName').focus();return}const f=allFormats().find(x=>x.id===S.fmtId);if(!f)return;
  if(f.builtin){const o=overrides();o[f.id]={label:name,sheet:{...(o[f.id]?o[f.id].sheet:f.sheet)}};saveOverrides(o)}else saveUserFormats(userFormats().map(x=>x.id===f.id?{...x,label:name}:x));
  $('#fmtName').value='';renderFormats()};
$('#fmtDel').onclick=()=>{saveUserFormats(userFormats().filter(f=>f.id!==S.fmtId));S.fmtId='';renderFormats()};
/* job BAT : { meta:{client,orderNumber}, material, file:{id,name,page}, face } */
const MAT_FMT={'pvc-white':'board-pvc-21','pvc-black':'board-pvc-21',bamboo:'board-bambou-21','metal-silver':'board-metal-21','metal-gold':'board-metal-21'};
const MAT_COLOR={'pvc-white':'BLANC','pvc-black':'NOIR',bamboo:'BAMBOU','metal-silver':'SILVER','metal-gold':'GOLD'};
async function onBatJob(j){
  if(!j)return;const lg=$('#log');lg.textContent='Ouverture du dossier BAT…';
  const f=allFormats().find(x=>x.id===MAT_FMT[j.material]);if(f)applyFormat(f);
  if(j.file&&j.file.id){
    const r=await fetch('/api/files/'+encodeURIComponent(j.file.id)+'/original');if(!r.ok)throw new Error('fichier introuvable');
    let bytes=new Uint8Array(await r.arrayBuffer());
    if(latin1(bytes.subarray(0,5))!=='%PDF-')throw new Error('la face '+(j.face||'')+' n\'est pas un PDF : ouvre la carte PDF avec « Ouvrir la carte »');
    const src=await PDFLib.PDFDocument.load(bytes.slice(0));const pg=Math.min(j.file.page||0,src.getPageCount()-1);
    if(src.getPageCount()>1){const d=await PDFLib.PDFDocument.create();const[p]=await d.copyPages(src,[pg]);d.addPage(p);bytes=await d.save()}
    const name=(j.file.name||'carte.pdf').replace(/\.[a-z0-9]{2,4}$/i,'')+(src.getPageCount()>1?'-'+(j.face||'page'+(pg+1)).toUpperCase():'')+'.pdf';
    await analyzeFile(new File([bytes],name,{type:'application/pdf'}))}
  const N=S.naming,m=j.meta||{};
  const set=(k,v)=>{if(v){N[k]=String(v);N.touched[k]=true}};
  // client BAT nettoyé des mots que la planche range ailleurs (modèle, couleur, face, mots techniques)
  const cl=String(m.client||'').split(/\s+/).filter(w=>{const k=norm(w);return k&&!MODELS.includes(k)&&!NSTOP.has(k)&&!COLORS.some(([re])=>re.test(k))&&k!=='recto'&&k!=='verso'}).join(' ');
  set('cmd',m.orderNumber);set('client',cl);set('color',MAT_COLOR[j.material]);
  renderNaming();updateStatus();
  lg.textContent='Dossier BAT ouvert'+(m.client||m.orderNumber?' : '+[m.orderNumber,m.client].filter(Boolean).join(' · '):'')+'. Ouvre maintenant l\'Excel ou le CSV (étape 3).'}
/* ---------- démarrage ---------- */
(async function init(){
  S.els=defaultEls();S.sel=S.els[1].id;
  S.data={cols:['Prénom','Nom','Poste','Email','Téléphone','URL QR'],rows:demoRows(),name:'',demo:true};
  if(EMBED){try{REMOTE=await(await fetch('/api/planche/store')).json()||{}}catch(e){REMOTE={}}}
  {const e=LS('planche.ext','');if(e==='ai'||e==='pdf')$('#nmExt').value=e}
  {const t=LS('planche.textMode','auto');if(['auto','text','outline'].includes(t))$('#txtMode').value=t}
  {const last=LS('planche.lastFormat','');const f=allFormats().find(x=>x.id===last)||allFormats()[0];if(f){Object.assign(S.sheet,f.sheet);S.fmtId=f.id}}
  buildSheetInputs();syncSheetInputs();refreshData();sheetInfo();sizeBox();renderList();renderForm();
  await setArt(await demoCard(),'',true);drawAll();
  autoNaming(null);
  window.__planche={S,generateBytes,setArt,loadData,applyTpl,cardContent,qrFromContent,parseNameInfo,fileBase};
  if(window.api&&window.api.contentReady)window.api.contentReady();
  if(window.api&&window.api.appInfo)window.api.appInfo().then(i=>{const t=document.querySelector('.brand span');if(t)t.title='Version '+i.version+(i.downloaded?' (mise à jour)':'')}).catch(()=>{});
})();
})();
