(function(){
'use strict';
const $=s=>document.querySelector(s);
const MM=72/25.4, ASC=0.8; // une position de texte = haut du bloc ; ligne de base = haut + 0,8 x corps
const NS='http://www.w3.org/2000/svg';
try{pdfjsLib.GlobalWorkerOptions.workerSrc='vendor/pdf.worker.min.js'}catch(e){}
try{qrcode.stringToBytes=qrcode.stringToBytesFuncs['UTF-8']}catch(e){}

/* ---------- état ---------- */
const S={
  art:{bytes:null,wpt:0,hpt:0,name:'',doc:null,demo:true},
  art2:null,variantEl:'',variantMin:2,
  sheet:{pageW:304,pageH:412,cols:3,rows:6,cardW:89.5,cardH:58,gapX:7,gapY:9,mL:11.5,mT:8},
  data:{cols:[],rows:[],name:'',demo:true},
  rowIdx:0,
  fonts:[
    {id:'helv',label:'Helvetica',family:'Helvetica, Arial, "Liberation Sans", sans-serif',weight:400,std:'Helvetica'},
    {id:'helv-b',label:'Helvetica Gras',family:'Helvetica, Arial, "Liberation Sans", sans-serif',weight:700,std:'HelveticaBold'}],
  els:[],sel:null,nextId:1,elsAreDemo:true
};
const byId=id=>S.els.find(e=>e.id===id);
const fontById=id=>S.fonts.find(f=>f.id===id)||S.fonts[0];

/* ---------- utilitaires ---------- */
const norm=s=>String(s==null?'':s).normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase().replace(/[\s_]+/g,' ').trim();
const num=(v,d)=>{const n=parseFloat(String(v).replace(',','.'));return isFinite(n)?n:d};
const r2=v=>Math.round(v*100)/100;
function cmykRgb(c){const[C,M,Y,K]=c.map(v=>v/100);return `rgb(${Math.round(255*(1-C)*(1-K))},${Math.round(255*(1-M)*(1-K))},${Math.round(255*(1-Y)*(1-K))})`}
const ALIAS=[['prenom','firstname','first name'],['nom','name','lastname','nom de famille'],['poste','titre','fonction','title','job','intitule'],['email','e-mail','mail','courriel'],['tel','telephone','mobile','portable','phone'],['url','lien','url qr','qr','lien qr','url du qr','qrcode','qr code']];
function rowKey(row,name){const n=norm(name);for(const k in row){if(norm(k)===n)return row[k]}
  const g=ALIAS.find(g=>g.includes(n));if(g)for(const k in row){if(g.includes(norm(k)))return row[k]}return undefined}
function hasCol(k){const n=norm(k);if(S.data.cols.some(c=>norm(c)===n))return true;const g=ALIAS.find(g=>g.includes(n));return !!g&&S.data.cols.some(c=>g.includes(norm(c)))}
function applyTpl(tpl,row){
  return String(tpl).replace(/\{([^}|]+?)(?:\|(upper|lower|title))?\}/g,(m,k,f)=>{
    let v=rowKey(row,k);if(v===undefined)return '';v=String(v);
    if(f==='upper')v=v.toUpperCase();else if(f==='lower')v=v.toLowerCase();else if(f==='title')v=v.toLowerCase().replace(/(^|[\s'’-])(\p{L})/gu,(a,b,c)=>b+c.toUpperCase());
    return v});
}
function tplMissing(tpl){const out=[];String(tpl).replace(/\{([^}|]+?)(?:\|\w+)?\}/g,(m,k)=>{if(!hasCol(k))out.push(k)});return out}
const curRow=()=>S.data.rows[S.rowIdx]||{};
function effY(e,row){if(e.type!=='text'||!e.flow)return e.y;const ref=byId(e.flow);if(!ref||ref.type!=='text'||ref===e)return e.y;const extra=Math.max(0,nLines(ref,row)-1);const step=e.flowStep>0?e.flowStep:ref.size/MM*ref.lh;return e.y+extra*step}
const mmFmt=v=>String(r2(v)).replace('.',',');

/* ---------- Styles de QR (charte : fichier QRCODE-01.svg ; unités = points du fichier, QR = 62,37 pt de côté) ---------- */
const QS_SIDE=62.37;
const QS={
  boxtext:{label:'Boîte blanche + VKARD.IO',box:{w:73.7,h:82.21,r:3.61},qx:5.67,qy:5.63,text:{ox:228.87,oy:81.44,d:'M290.89,148.38c-.24-.42-.57-.75-.98-.98-.41-.24-.87-.35-1.38-.35s-.96.12-1.37.35c-.41.23-.74.56-.98.98-.24.42-.36.89-.36,1.41s.12,1,.36,1.42c.24.42.57.75.98.98.41.24.87.36,1.37.36s.96-.12,1.37-.35c.41-.24.74-.57.98-.99.24-.42.36-.89.36-1.42s-.12-1-.36-1.41M289.7,149.8c0,.41-.1.72-.32.96-.21.23-.49.35-.84.35s-.64-.11-.85-.35c-.21-.24-.32-.55-.32-.96s.1-.73.32-.97c.21-.23.49-.34.85-.34s.64.11.85.35c.21.23.32.55.32.96M279.94 147.13h1.53v5.37h-1.53zM274.06 150.97h1.57v1.53h-1.57zM268.6,147.46c-.42-.22-.92-.33-1.48-.33h-2.07v5.37h2.07c.56,0,1.06-.11,1.48-.34.42-.23.75-.55.98-.96.22-.4.34-.88.34-1.4s-.11-.99-.34-1.39c-.23-.4-.55-.72-.98-.95M268.38,149.8c0,.42-.12.73-.35.96-.24.23-.58.34-1.01.34h-.43v-2.6h.43c.44,0,.77.11,1.01.34.23.22.35.55.35.96M260.43,149.92c.22-.28.34-.63.34-1.03,0-.34-.08-.64-.23-.9-.15-.27-.39-.48-.69-.63-.3-.15-.66-.22-1.09-.22h-2.24v5.37h1.53v-1.92h.04l1.1,1.92h1.71l-1.24-2.06c.33-.11.59-.29.78-.53M258.05,148.46h.61c.2,0,.34.04.43.13.09.09.13.21.13.36,0,.17-.04.29-.12.37-.09.08-.23.12-.44.12h-.61v-.98ZM248.86,147.16l-1.97,5.34h1.61l.32-.93h1.69l.32.93h1.63l-1.97-5.34h-1.62ZM250.09,150.34h-.85l.43-1.25.42,1.25ZM241.44 147.13 L239.93 149.07 L239.93 147.13 L238.4 147.13 L238.4 152.5 L239.93 152.5 L239.93 150.52 L241.43 152.5 L243.3 152.5 L241.13 149.76 L243.3 147.13 L241.44 147.13ZM231.56 150.61 L230.46 147.23 L230.43 147.13 L228.79 147.13 L230.66 152.5 L232.45 152.5 L234.32 147.13 L232.69 147.13 L231.56 150.61Z'}},
  box:{label:'Boîte blanche',box:{w:73.7,h:73.7,r:3.61},qx:5.67,qy:5.67,text:null},
  text:{label:'QR + VKARD.IO (sans boîte)',box:null,qx:0,qy:0,text:{ox:134.99,oy:88.57,d:'M194.65,158.38c-.4,0-.72-.13-.96-.4s-.36-.62-.36-1.06.12-.81.36-1.07c.24-.26.56-.39.96-.39s.72.13.96.4.35.62.35,1.06-.12.8-.36,1.06c-.24.26-.56.4-.95.4M194.65,159.53c.47,0,.9-.11,1.29-.33.39-.22.7-.53.93-.93.23-.4.34-.84.34-1.34s-.11-.94-.34-1.34c-.22-.39-.53-.7-.92-.92-.39-.22-.82-.33-1.3-.33s-.9.11-1.29.33c-.39.22-.7.53-.93.92-.23.4-.34.84-.34,1.34s.11.94.34,1.34c.23.4.54.71.93.93.39.22.82.33,1.29.33M187.43,154.41h-1.23v5.07h1.23v-5.07ZM181.6,158.26h-1.27v1.23h1.27v-1.23ZM175.56,155.62c-.21-.38-.52-.68-.92-.89-.4-.21-.87-.32-1.41-.32h-1.92v5.07h1.92c.54,0,1.01-.11,1.41-.32.4-.22.71-.51.92-.9.21-.39.32-.83.32-1.32s-.11-.94-.32-1.32M174.24,158c-.27.25-.64.38-1.12.38h-.58v-2.9h.58c.48,0,.85.13,1.12.38.26.25.4.61.4,1.07s-.13.81-.4,1.07M166.43,156.96c.2-.26.31-.57.31-.94,0-.31-.07-.59-.21-.83-.14-.24-.35-.43-.62-.57-.28-.14-.62-.21-1.02-.21h-2.1v5.07h1.23v-1.92h.28l1.1,1.92h1.36l-1.21-1.99c.39-.1.68-.27.89-.53M165.31,156.57c-.12.11-.29.16-.54.16h-.76v-1.28h.76c.24,0,.42.06.53.17.12.12.18.27.18.47,0,.21-.06.37-.17.48M155.08,154.45l-1.86,5.04h1.29l.32-.93h1.9l.32.93h1.31l-1.86-5.04h-1.41ZM155.14,157.62l.64-1.87.63,1.87h-1.27ZM147.63 154.41 L145.89 156.64 L145.89 154.41 L144.67 154.41 L144.67 159.48 L145.89 159.48 L145.89 157.21 L147.62 159.48 L149.1 159.48 L147.06 156.89 L149.1 154.41 L147.63 154.41ZM137.67 158.23 L136.43 154.41 L135.12 154.41 L136.88 159.48 L138.46 159.48 L140.23 154.41 L138.91 154.41 L137.67 158.23Z',h:70.96}},
  plain:{label:'QR seul',box:null,qx:0,qy:0,text:null}};
function roundRectPath(w,h,r){const k=r*.5523,i=r-k;return `M${r} 0H${w-r}c${k} 0 ${r} ${i} ${r} ${r}V${h-r}c0 ${k} ${-i} ${r} ${-r} ${r}H${r}c${-k} 0 ${-r} ${-i} ${-r} ${-r}V${r}c0 ${-k} ${i} ${-r} ${r} ${-r}Z`}
/* géométrie d'un bloc QR en mm : le bloc (boîte + QR + texte) est homothétique, e.size = côté du QR */
function qrGeom(e){const st=QS[e.style]||QS.boxtext,u=e.size/QS_SIDE;
  const w=(st.box?st.box.w:QS_SIDE)*u,h=(st.box?st.box.h:(st.text&&st.text.h?st.text.h:QS_SIDE))*u;
  return{st,u,w,h,qx:e.x+st.qx*u,qy:e.y+st.qy*u}}

/* ---------- QR ---------- */
function qrMatrix(text,ecc){
  const q=qrcode(0,ecc||'M');q.addData(text,'Byte');q.make();const n=q.getModuleCount(),m=[];
  for(let r=0;r<n;r++){const row=[];for(let c=0;c<n;c++)row.push(q.isDark(r,c));m.push(row)}return m}
function qrPath(m,x0,y0,size){ // tracé unique, runs fusionnés
  const n=m.length,mod=size/n,runs=new Map();
  for(let r=0;r<n;r++){let c=0;while(c<n){if(m[r][c]){const s=c;while(c<n&&m[r][c])c++;const k=s+'-'+c;if(!runs.has(k))runs.set(k,[]);runs.get(k).push(r)}else c++}}
  let d='';const f=v=>(+v.toFixed(4));
  for(const[k,rows]of runs){const[s,e]=k.split('-').map(Number);let a=rows[0],p=a;
    for(let i=1;i<=rows.length;i++){const r=rows[i];if(r===undefined||r!==p+1){d+=`M${f(x0+s*mod)} ${f(y0+a*mod)}h${f((e-s)*mod)}v${f((p+1-a)*mod)}h${f(-(e-s)*mod)}z`;a=r}p=r}}
  return d}

/* ---------- police : mesure (aperçu) ---------- */
const mctx=document.createElement('canvas').getContext('2d');
function measure(fontId,text,sizePt){const f=fontById(fontId);mctx.font=`${f.weight>=600?'bold ':''}${sizePt}px ${f.family}`;return mctx.measureText(text).width}
function fitLines(el,lines,measureFn){
  let size=el.size;if(!(el.maxW>0))return size;const maxPt=el.maxW*MM;
  const w=Math.max(0,...lines.map(l=>measureFn(l,size)));
  return w>maxPt?Math.max(3,size*maxPt/w):size}

/* ---------- éléments par défaut (exemple) ---------- */
function defaultEls(){
  const mk=(o)=>Object.assign({id:'e'+(S.nextId++)},o);
  const L=[
    mk({type:'qr',name:'QR code',col:'URL QR',style:'boxtext',x:50.3,y:14.9,size:+(QS_SIDE/MM).toFixed(2),ecc:'M',color:[0,0,0,100],boxColor:[0,0,0,0]}),
    mk({type:'text',name:'Nom',tpl:'{Prénom} {Nom|upper}',font:'helv-b',size:8.5,x:7.3,y:19.5,color:[66,19,0,0],lh:1.2,maxW:42}),
    mk({type:'text',name:'Poste',tpl:'{Poste}',font:'helv',size:6.5,x:7.3,y:22.9,color:[66,19,0,0],lh:1.2,maxW:42}),
    mk({type:'text',name:'Email',tpl:'{Email}',font:'helv',size:5.5,x:11.5,y:26.5,color:[0,0,0,0],lh:1.2,maxW:38,flow:'@poste'}),
    mk({type:'text',name:'Téléphone',tpl:'{Téléphone}',font:'helv',size:5.5,x:11.5,y:29.8,color:[0,0,0,0],lh:1.2,maxW:38,flow:'@poste'})];
  const poste=L.find(e=>e.name==='Poste');L.forEach(e=>{if(e.flow==='@poste')e.flow=poste.id});return L;
}
function autoMapCols(){ // quand l'utilisateur charge ses données et n'a pas encore modifié les éléments
  const find=(...a)=>S.data.cols.find(c=>a.includes(norm(c)));
  const pre=find('prenom','firstname','first name'),nom=find('nom','name','lastname','nom de famille'),full=find('nom complet','fullname');
  const poste=find('poste','titre','fonction','title','job'),mail=find('email','e-mail','mail','courriel'),tel=find('tel','telephone','mobile','portable','phone');
  const url=find('url','lien','url qr','qr','lien qr','url du qr','qrcode','qr code');
  for(const e of S.els){
    if(e.type==='qr'&&url)e.col=url;
    if(e.name==='Nom')e.tpl=full?`{${full}}`:(pre&&nom?`{${pre}} {${nom}|upper}`:(nom?`{${nom}}`:e.tpl));
    if(e.name==='Poste'&&poste)e.tpl=`{${poste}}`;
    if(e.name==='Email'&&mail)e.tpl=`{${mail}}`;
    if(e.name==='Téléphone'&&tel)e.tpl=`{${tel}}`;
  }}

/* ---------- carte de démonstration (générée) ---------- */
async function demoCard(){
  const{PDFDocument,cmyk}=PDFLib;const d=await PDFDocument.create();const w=S.sheet.cardW*MM,h=S.sheet.cardH*MM;const p=d.addPage([w,h]);
  p.drawRectangle({x:0,y:0,width:w,height:h,color:cmyk(0,0,0,1)});
  p.drawCircle({x:w-16,y:22,size:46,borderColor:cmyk(.9,.1,.5,0),borderWidth:5});
  p.drawCircle({x:w-4,y:6,size:62,borderColor:cmyk(.75,.2,0,0),borderWidth:5});
  const f=await d.embedFont(PDFLib.StandardFonts.HelveticaBold);
  p.drawText('ENTREPRISE',{x:7.3*MM,y:h-9*MM,size:11,font:f,color:cmyk(0,0,0,0)});
  p.drawText('CARTE DE BASE (EXEMPLE)',{x:7.3*MM,y:h-12.2*MM,size:5,font:f,color:cmyk(.66,.19,0,0)});
  const b=await d.save();return b}
const demoRows=()=>[
  {'Prénom':'Camille','Nom':'Martin','Poste':'Responsable Achats','Email':'camille.martin@exemple.fr','Téléphone':'+33 6 12 34 56 78','URL QR':'https://exemple.fr/c/camille-martin'},
  {'Prénom':'Julien','Nom':'Dubois','Poste':'Chargé d’Affaires','Email':'julien.dubois@exemple.fr','Téléphone':'+33 6 98 76 54 32','URL QR':'https://exemple.fr/c/julien-dubois'},
  {'Prénom':'Inès','Nom':'Ait Ayoub','Poste':'Alternante Manager\nde la Performance Commerciale','Email':'ines.aitayoub@exemple.fr','Téléphone':'+33 7 64 75 24 08','URL QR':'https://exemple.fr/c/ines-ait-ayoub'}];

/* ---------- chargement carte ---------- */
async function setArt(bytes,name,demo){
  const src=await PDFLib.PDFDocument.load(bytes.slice(0));const sz=src.getPage(0).getSize();
  const doc=await pdfjsLib.getDocument({data:bytes.slice(0)}).promise;
  S.art={bytes,wpt:sz.width,hpt:sz.height,name,doc,demo:!!demo};
  $('#artInfo').textContent=demo?'exemple':`${name} · ${mmFmt(sz.width/MM)} × ${mmFmt(sz.height/MM)} mm`;
  const dw=sz.width/MM-S.sheet.cardW,dh=sz.height/MM-S.sheet.cardH;
  const n=$('#artNote');
  if(!demo&&(Math.abs(dw)>.5||Math.abs(dh)>.5)){n.className='note warn';n.textContent=`Le PDF fait ${mmFmt(sz.width/MM)} × ${mmFmt(sz.height/MM)} mm ; la carte de la planche fait ${mmFmt(S.sheet.cardW)} × ${mmFmt(S.sheet.cardH)} mm. Le visuel sera étiré. Étape 4 : « Taille de carte = taille du PDF » pour garder la taille d'origine.`}
  else if(!demo){n.className='note ok';n.textContent='Taille cohérente avec la carte de la planche.'}
  else{n.className='note';n.textContent='Carte d\'exemple. Remplace-la par le PDF de ta carte, sans QR ni texte variable.'}
  await drawArt();drawAll()}
const nLines=(e,row)=>applyTpl(e.tpl,row).split('\n').map(t=>t.trim()).filter(Boolean).length;
function artFor(row){if(S.art2&&S.variantEl){const e=byId(S.variantEl);if(e&&e.type==='text'&&nLines(e,row)>=S.variantMin)return S.art2}return S.art}
async function setArt2(bytes,name){
  const src=await PDFLib.PDFDocument.load(bytes.slice(0));const sz=src.getPage(0).getSize();
  S.art2={bytes,wpt:sz.width,hpt:sz.height,name,doc:await pdfjsLib.getDocument({data:bytes.slice(0)}).promise};refreshVariant();await drawArt();drawOverlay()}
function refreshVariant(){
  $('#art2Info').textContent=S.art2?S.art2.name:'aucune';$('#art2Del').hidden=!S.art2;
  const sel=$('#varEl');sel.innerHTML='<option value="">—</option>';S.els.filter(e=>e.type==='text').forEach(e=>{const o=document.createElement('option');o.value=e.id;o.textContent=e.name||e.tpl;sel.appendChild(o)});
  if(S.variantEl&&!byId(S.variantEl))S.variantEl='';sel.value=S.variantEl;$('#varMin').value=S.variantMin;
  if(S.art2)$('#varBox').open=true}
let curDoc=null;
async function drawArt(){
  const art=artFor(curRow());const cv=$('#artCanvas');const box=$('#cardBox');const W=box.clientWidth;if(!W||!art.doc)return;curDoc=art.doc;
  const H=W*S.sheet.cardH/S.sheet.cardW,dpr=Math.min(2,window.devicePixelRatio||1)*1.5;
  cv.width=Math.round(W*dpr);cv.height=Math.round(H*dpr);
  const page=await art.doc.getPage(1);const vp=page.getViewport({scale:1});
  const ctx=cv.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,cv.width,cv.height);
  const token=++drawArt.t;
  const task=page.render({canvasContext:ctx,viewport:vp,transform:[cv.width/vp.width,0,0,cv.height/vp.height,0,0]});
  try{await task.promise}catch(e){}
}
drawArt.t=0;

/* ---------- chargement données ---------- */
function parseDelimited(text){
  text=text.replace(/^﻿/,'');const first=text.split(/\r?\n/)[0]||'';
  const delim=[';','\t',','].map(d=>[d,first.split(d).length]).sort((a,b)=>b[1]-a[1])[0][0];
  const rows=[];let row=[],cur='',q=false;
  for(let i=0;i<text.length;i++){const c=text[i];
    if(q){if(c==='"'){if(text[i+1]==='"'){cur+='"';i++}else q=false}else cur+=c}
    else if(c==='"')q=true;else if(c===delim){row.push(cur);cur=''}
    else if(c==='\n'||c==='\r'){if(c==='\r'&&text[i+1]==='\n')i++;row.push(cur);rows.push(row);row=[];cur=''}
    else cur+=c}
  if(cur!==''||row.length){row.push(cur);rows.push(row)}return rows}
async function loadData(file){
  let aoa;
  if(/\.(xlsx|xls|xlsm)$/i.test(file.name)){
    const wb=XLSX.read(await file.arrayBuffer(),{type:'array'});
    aoa=XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]],{header:1,raw:false,defval:''})}
  else aoa=parseDelimited(new TextDecoder('utf-8').decode(await file.arrayBuffer()));
  aoa=aoa.filter(r=>r.some(v=>String(v).trim()!==''));
  if(aoa.length<2){$('#dataNote').className='note bad';$('#dataNote').textContent='Fichier vide ou sans ligne de données.';return}
  const cols=aoa[0].map((h,i)=>String(h).trim()||('Colonne '+(i+1)));
  const rows=aoa.slice(1).map(r=>{const o={};cols.forEach((c,i)=>o[c]=String(r[i]==null?'':r[i]).replace(/\r/g,'').trim());return o});
  S.data={cols,rows,name:file.name,demo:false};S.rowIdx=0;
  if(S.elsAreDemo)autoMapCols();
  refreshData();drawAll();drawArt()}
function refreshData(){
  const d=S.data;$('#dataInfo').textContent=d.demo?'exemple':`${d.name} · ${d.rows.length} ligne${d.rows.length>1?'s':''}`;
  $('#cols').innerHTML='';d.cols.forEach(c=>{const b=document.createElement('button');b.className='chip';b.textContent=c;b.title='Insérer {'+c+'} dans le texte sélectionné';b.onclick=()=>insertToken(c);$('#cols').appendChild(b)});
  const n=$('#dataNote');n.className='note';n.textContent=d.demo?'Lignes d\'exemple. Remplace-les par ton fichier.':`${d.cols.length} colonnes détectées. Clique sur une colonne pour l'insérer dans le texte sélectionné.`;
  const sel=$('#rowSel');sel.innerHTML='';d.rows.forEach((r,i)=>{const o=document.createElement('option');o.value=i;o.textContent=(i+1)+' · '+(r[d.cols[0]]||'')+' '+(r[d.cols[1]]||'');sel.appendChild(o)});sel.value=S.rowIdx;
  updateInfo()}
function insertToken(c){const e=byId(S.sel);if(!e||e.type!=='text')return;e.tpl+=`{${c}}`;e.name=e.name||'Texte';renderForm();drawAll()}

/* ---------- éléments : liste + formulaire ---------- */
function renderList(){
  refreshVariant();const L=$('#elList');L.innerHTML='';
  S.els.forEach(e=>{const d=document.createElement('div');d.className='item';d.setAttribute('role','option');d.tabIndex=0;d.setAttribute('aria-selected',e.id===S.sel);
    const sw=document.createElement('span');sw.className='sw';sw.style.background=e.type==='qr'?'#222':cmykRgb(e.color);
    const k=document.createElement('span');k.className='k';k.textContent=e.type==='qr'?'QR':'Aa';
    const t=document.createElement('span');t.className='t';t.textContent=e.type==='qr'?`QR · ${e.col||'—'}`:`${e.name||'Texte'} · ${e.tpl}`;
    d.append(k,t,sw);d.onclick=()=>select(e.id);d.onkeydown=ev=>{if(ev.key==='Enter'||ev.key===' '){ev.preventDefault();select(e.id)}};L.appendChild(d)})}
function select(id){S.sel=id;renderList();renderForm();drawOverlay()}
function afterRowChange(){drawArt().then(drawOverlay)}
function field(label,el){const l=document.createElement('label');l.className='f';l.append(label,el);return l}
function inp(val,type,onchange,attrs){const i=document.createElement('input');i.type=type||'text';i.value=val;if(attrs)for(const k in attrs)i.setAttribute(k,attrs[k]);i.oninput=()=>onchange(i.value);return i}
function renderForm(){
  const F=$('#editor');F.innerHTML='';const e=byId(S.sel);if(!e){F.innerHTML='<p class="note" style="margin:0">Sélectionne un élément dans la liste ou sur la carte.</p>';return}
  const upd=(k,conv)=>v=>{e[k]=conv?conv(v):v;S.elsAreDemo=false;if(k==='tpl'||k==='col')renderList();drawAll(true)};
  const n=(k,min,step)=>inp(e[k],'number',upd(k,v=>num(v,e[k])),{step:step||'0.1',min:min==null?'':min});
  if(e.type==='qr'){
    const s=document.createElement('select');const cl=S.data.cols.includes(e.col)?S.data.cols:[e.col,...S.data.cols];cl.forEach(c=>{const o=document.createElement('option');o.value=c;o.textContent=c;s.appendChild(o)});s.value=e.col;s.onchange=()=>upd('col')(s.value);
    F.appendChild(field('Colonne contenant l\'URL du QR',s));
    const ss=document.createElement('select');Object.keys(QS).forEach(k=>{const o=document.createElement('option');o.value=k;o.textContent=QS[k].label;ss.appendChild(o)});ss.value=e.style||'boxtext';ss.onchange=()=>{e.style=ss.value;S.elsAreDemo=false;drawAll(true)};
    F.appendChild(field('Style du QR (charte)',ss));
    const g=document.createElement('div');g.className='grid3';g.append(field('X bloc (mm)',n('x')),field('Y bloc (mm)',n('y')),field('Côté du QR (mm)',n('size',5)));F.appendChild(g);
    const ec=document.createElement('select');['L','M','Q','H'].forEach(v=>{const o=document.createElement('option');o.value=v;o.textContent=v+(v==='M'?' (standard)':'');ec.appendChild(o)});ec.value=e.ecc;ec.onchange=()=>upd('ecc')(ec.value);
    F.appendChild(field('Correction d\'erreur',ec));
  }else{
    F.appendChild(field('Nom de l\'élément',inp(e.name,'text',upd('name'))));
    F.appendChild(field('Contenu',inp(e.tpl,'text',upd('tpl'))));
    const miss=tplMissing(e.tpl);if(miss.length){const p=document.createElement('p');p.className='note bad';p.style.margin='0';p.textContent='Colonne introuvable : '+miss.join(', ');F.appendChild(p)}
    const fs=document.createElement('select');S.fonts.forEach(f=>{const o=document.createElement('option');o.value=f.id;o.textContent=f.label;fs.appendChild(o)});fs.value=e.font;fs.onchange=()=>upd('font')(fs.value);
    const g=document.createElement('div');g.className='grid2';g.append(field('Police',fs),field('Corps (pt)',n('size',2,'0.1')));F.appendChild(g);
    const g2=document.createElement('div');g2.className='grid2';g2.append(field('X (mm)',n('x')),field('Y haut du texte (mm)',n('y')));F.appendChild(g2);
    const g3=document.createElement('div');g3.className='grid2';g3.append(field('Interligne (×)',n('lh',0.8,'0.05')),field('Largeur max (mm, 0 = libre)',n('maxW',0,'0.5')));F.appendChild(g3);
    const fl=document.createElement('select');fl.innerHTML='<option value="">Position fixe</option>';S.els.filter(x=>x.type==='text'&&x!==e).forEach(x=>{const o=document.createElement('option');o.value=x.id;o.textContent='Descend si « '+(x.name||x.tpl)+' » a plusieurs lignes';fl.appendChild(o)});fl.value=e.flow||'';fl.onchange=()=>{e.flow=fl.value;S.elsAreDemo=false;renderForm();drawAll(true)};
    const g4=document.createElement('div');g4.className='grid2';g4.append(field('Décalage automatique',fl),field('Décalage par ligne (mm, 0 = auto)',n('flowStep',0,'0.1')));F.appendChild(g4);
  }
  const cg=document.createElement('div');cg.className='grid4';
  ['C','M','J','N'].forEach((l,i)=>cg.appendChild(field(l+' %',inp(e.color[i],'number',v=>{e.color[i]=Math.min(100,Math.max(0,num(v,0)));S.elsAreDemo=false;renderList();drawAll(true)},{min:0,max:100,step:1}))));
  F.append(Object.assign(document.createElement('h3'),{textContent:e.type==='qr'?'Couleur du QR (CMJN)':'Couleur CMJN',style:'margin:4px 0 0'}),cg);
  if(e.type==='qr'){e.boxColor=e.boxColor||[0,0,0,0];const bg=document.createElement('div');bg.className='grid4';['C','M','J','N'].forEach((l,i)=>bg.appendChild(field(l+' %',inp(e.boxColor[i],'number',v=>{e.boxColor[i]=Math.min(100,Math.max(0,num(v,0)));drawAll(true)},{min:0,max:100,step:1}))));F.append(Object.assign(document.createElement('h3'),{textContent:'Couleur de la boîte (CMJN)',style:'margin:4px 0 0'}),bg)}}

/* ---------- aperçu : overlay SVG (unités = mm) ---------- */
let drag=null;
function drawOverlay(){
  const svg=$('#ov');const W=S.sheet.cardW,H=S.sheet.cardH;svg.setAttribute('viewBox',`0 0 ${W} ${H}`);svg.innerHTML='';
  const row=curRow();const stageMsgs=[];
  S.els.forEach(e=>{
    const g=document.createElementNS(NS,'g');g.setAttribute('class','el');g.dataset.id=e.id;svg.appendChild(g);
    if(e.type==='qr'){
      const url=applyTpl('{'+e.col+'}',row),G=qrGeom(e),W2=G.w,H2=G.h;
      if(G.st.box){const bx=document.createElementNS(NS,'path');bx.setAttribute('d',roundRectPath(G.st.box.w*G.u,G.st.box.h*G.u,G.st.box.r*G.u));bx.setAttribute('transform',`translate(${e.x} ${e.y})`);bx.setAttribute('fill',cmykRgb(e.boxColor||[0,0,0,0]));g.appendChild(bx)}
      if(url){try{const m=qrMatrix(url,e.ecc);const p=document.createElementNS(NS,'path');p.setAttribute('d',qrPath(m,G.qx,G.qy,e.size));p.setAttribute('fill',cmykRgb(e.color));g.appendChild(p);
        if(G.st.text){const t=document.createElementNS(NS,'path');t.setAttribute('d',G.st.text.d);t.setAttribute('transform',`translate(${G.qx-G.st.text.ox*G.u} ${G.qy-G.st.text.oy*G.u}) scale(${G.u})`);t.setAttribute('fill',cmykRgb(e.color));g.appendChild(t)}
        const hit=document.createElementNS(NS,'rect');hit.setAttribute('x',e.x);hit.setAttribute('y',e.y);hit.setAttribute('width',W2);hit.setAttribute('height',H2);hit.setAttribute('fill','transparent');g.appendChild(hit)}catch(err){stageMsgs.push('QR impossible : '+err.message)}}
      else{const r=document.createElementNS(NS,'rect');r.setAttribute('x',e.x);r.setAttribute('y',e.y);r.setAttribute('width',W2);r.setAttribute('height',H2);r.setAttribute('fill','rgba(179,38,30,.15)');r.setAttribute('stroke','#b3261e');r.setAttribute('stroke-dasharray','1 .6');r.setAttribute('stroke-width','.3');g.appendChild(r);stageMsgs.push('URL manquante pour la ligne affichée.')}
      if(e.id===S.sel){const hd=document.createElementNS(NS,'circle');hd.setAttribute('cx',e.x+W2);hd.setAttribute('cy',e.y+H2);hd.setAttribute('r','1.3');hd.setAttribute('fill','#2F86C4');hd.setAttribute('stroke','#fff');hd.setAttribute('stroke-width','.3');hd.dataset.handle='1';hd.style.cursor='nwse-resize';g.appendChild(hd)}
    }else{
      const lines=applyTpl(e.tpl,row).split('\n').map(s=>s.trim()).filter(Boolean);const f=fontById(e.font);const ey=effY(e,row);
      const size=fitLines(e,lines,(t,s)=>measure(e.font,t,s));const szmm=size/MM;
      lines.forEach((t,i)=>{const tx=document.createElementNS(NS,'text');tx.setAttribute('x',e.x);tx.setAttribute('y',ey+szmm*ASC+i*szmm*e.lh);tx.setAttribute('font-size',szmm);tx.setAttribute('font-family',f.family);tx.setAttribute('font-weight',f.weight);tx.setAttribute('fill',cmykRgb(e.color));tx.textContent=t;g.appendChild(tx)});
      const hh=lines.length?szmm*ASC+(lines.length-1)*szmm*e.lh+szmm*.3:szmm;
      const ww=Math.max(1,...lines.map(t=>measure(e.font,t,size)/MM));
      const hit=document.createElementNS(NS,'rect');hit.setAttribute('x',e.x);hit.setAttribute('y',ey);hit.setAttribute('width',ww);hit.setAttribute('height',hh);hit.setAttribute('fill','transparent');g.insertBefore(hit,g.firstChild);e._box=[e.x,ey,ww,hh];
      if(size<e.size-.01)stageMsgs.push(`« ${e.name} » réduit à ${size.toFixed(1)} pt (largeur max).`)}
    if(e.id===S.sel){const b=e.type==='qr'?(()=>{const G=qrGeom(e);return[e.x,e.y,G.w,G.h]})():(e._box||[e.x,e.y,5,3]);const o=document.createElementNS(NS,'rect');o.setAttribute('x',b[0]-.4);o.setAttribute('y',b[1]-.4);o.setAttribute('width',b[2]+.8);o.setAttribute('height',b[3]+.8);o.setAttribute('fill','none');o.setAttribute('stroke','#2F86C4');o.setAttribute('stroke-width','.3');o.setAttribute('stroke-dasharray','1 .7');o.setAttribute('pointer-events','none');svg.appendChild(o)}
  });
  const sn=$('#stageNote');sn.className=stageMsgs.length?'note warn':'note';sn.textContent=stageMsgs.length?stageMsgs.join(' '):'Aperçu de la ligne sélectionnée. Les couleurs CMJN sont approchées à l\'écran.';
}
function svgPt(ev){const svg=$('#ov');const pt=svg.createSVGPoint();pt.x=ev.clientX;pt.y=ev.clientY;return pt.matrixTransform(svg.getScreenCTM().inverse())}
const snap=v=>Math.round(v*20)/20;
$('#ov').addEventListener('pointerdown',ev=>{
  const g=ev.target.closest('[data-id]');if(!g){select(null);return}
  const e=byId(g.dataset.id);if(S.sel!==e.id){S.sel=e.id;renderList();renderForm()}
  const p=svgPt(ev);const sh=e.type==='text'?effY(e,curRow())-e.y:0;drag={e,shift:sh,dx:p.x-e.x,dy:p.y-e.y-sh,resize:!!ev.target.dataset.handle};try{$('#ov').setPointerCapture(ev.pointerId)}catch(x){}
  drawOverlay();ev.preventDefault()});
$('#ov').addEventListener('pointermove',ev=>{if(!drag)return;const p=svgPt(ev),e=drag.e;
  if(drag.resize){const G=qrGeom(e);const k=Math.max((p.x-e.x)/(G.w/e.size),(p.y-e.y)/(G.h/e.size));e.size=Math.max(8,Math.round(k*20)/20)}else{e.x=snap(p.x-drag.dx);e.y=snap(p.y-drag.dy-(drag.shift||0))}
  S.elsAreDemo=false;drawOverlay();syncPos(e)});
const endDrag=()=>{if(drag){drag=null;renderForm()}};
$('#ov').addEventListener('pointerup',endDrag);$('#ov').addEventListener('pointercancel',endDrag);
function syncPos(e){const ins=[...document.querySelectorAll('#editor input[type=number]')];/* champs X/Y/Côté suivent le glisser */}
document.addEventListener('keydown',ev=>{
  const e=byId(S.sel);if(!e||/INPUT|SELECT|TEXTAREA/.test(document.activeElement.tagName))return;
  const st=ev.shiftKey?1:.1;let h=true;
  if(ev.key==='ArrowLeft')e.x=r2(e.x-st);else if(ev.key==='ArrowRight')e.x=r2(e.x+st);else if(ev.key==='ArrowUp')e.y=r2(e.y-st);else if(ev.key==='ArrowDown')e.y=r2(e.y+st);else h=false;
  if(h){ev.preventDefault();S.elsAreDemo=false;renderForm();drawOverlay()}});

/* ---------- planche : champs + schéma ---------- */
const SHEET_FIELDS=[['pageW','Page larg. (mm)'],['pageH','Page haut. (mm)'],['cols','Colonnes'],['rows','Lignes'],['cardW','Carte larg. (mm)'],['cardH','Carte haut. (mm)'],['gapX','Écart X (mm)'],['gapY','Écart Y (mm)'],['mL','Marge gauche (mm)'],['mT','Marge haut (mm)']];
function buildSheetInputs(){
  const c=$('#sheetInputs');c.innerHTML='';
  SHEET_FIELDS.forEach(([k,l])=>{const i=document.createElement('input');i.type='number';i.id='sh_'+k;i.step=(k==='cols'||k==='rows')?'1':'0.1';i.min=(k==='cols'||k==='rows')?'1':'0';i.value=S.sheet[k];
    i.oninput=()=>{const v=num(i.value,S.sheet[k]);S.sheet[k]=(k==='cols'||k==='rows')?Math.max(1,Math.round(v)):v;sheetInfo();drawSheet();if(k==='cardW'||k==='cardH'){drawArt();drawOverlay()}};
    c.appendChild(field(l,i))})}
function syncSheetInputs(){SHEET_FIELDS.forEach(([k])=>{const i=$('#sh_'+k);if(i)i.value=r2(S.sheet[k])})}
const gridW=()=>S.sheet.cols*S.sheet.cardW+(S.sheet.cols-1)*S.sheet.gapX;
const gridH=()=>S.sheet.rows*S.sheet.cardH+(S.sheet.rows-1)*S.sheet.gapY;
function sheetInfo(){
  const s=S.sheet,rm=s.pageW-s.mL-gridW(),bm=s.pageH-s.mT-gridH(),n=$('#sheetNote');
  const bad=rm<-.01||bm<-.01||s.mL<0||s.mT<0;
  n.className='note '+(bad?'bad':'ok');
  n.textContent=`${s.cols*s.rows} cartes par planche · marge droite ${mmFmt(rm)} mm · marge bas ${mmFmt(bm)} mm`+(bad?' · les cartes dépassent de la page':'');
  $('#cardDims').textContent=`${mmFmt(s.cardW)} × ${mmFmt(s.cardH)} mm`;
  updateInfo()}
function updateInfo(){const per=S.sheet.cols*S.sheet.rows,n=S.data.rows.length;$('#genInfo').textContent=`${n} carte${n>1?'s':''} · ${Math.max(1,Math.ceil(n/per))} planche${Math.ceil(n/per)>1?'s':''}`}
function drawSheet(){
  const s=S.sheet,svg=$('#sheetSvg');svg.setAttribute('viewBox',`0 0 ${s.pageW} ${s.pageH}`);svg.style.aspectRatio=`${s.pageW}/${s.pageH}`;svg.innerHTML='';
  const css=getComputedStyle(document.documentElement);const acc=css.getPropertyValue('--accent').trim(),ink=css.getPropertyValue('--ink').trim();
  const pg=document.createElementNS(NS,'rect');pg.setAttribute('width',s.pageW);pg.setAttribute('height',s.pageH);pg.setAttribute('fill','none');svg.appendChild(pg);
  const n=Math.min(S.data.rows.length,s.cols*s.rows);
  for(let r=0;r<s.rows;r++)for(let c=0;c<s.cols;c++){const i=r*s.cols+c;const rc=document.createElementNS(NS,'rect');
    rc.setAttribute('x',s.mL+c*(s.cardW+s.gapX));rc.setAttribute('y',s.mT+r*(s.cardH+s.gapY));rc.setAttribute('width',s.cardW);rc.setAttribute('height',s.cardH);
    rc.setAttribute('fill',i<n?acc:'none');rc.setAttribute('fill-opacity',i<n?.85:0);rc.setAttribute('stroke',acc);rc.setAttribute('stroke-width',s.pageW/300);rc.setAttribute('stroke-dasharray',i<n?'0':`${s.pageW/100} ${s.pageW/200}`);svg.appendChild(rc)}
}
$('#centerX').onclick=()=>{S.sheet.mL=r2((S.sheet.pageW-gridW())/2);syncSheetInputs();sheetInfo();drawSheet()};
$('#centerY').onclick=()=>{S.sheet.mT=r2((S.sheet.pageH-gridH())/2);syncSheetInputs();sheetInfo();drawSheet()};
$('#useArt').onclick=()=>{if(!S.art.wpt)return;S.sheet.cardW=r2(S.art.wpt/MM);S.sheet.cardH=r2(S.art.hpt/MM);syncSheetInputs();sheetInfo();drawSheet();drawArt();drawOverlay();$('#artNote').className='note ok';$('#artNote').textContent='Taille de carte alignée sur le PDF.'};

/* ---------- enregistrement (application : boîte de dialogue native ; page : capability downloads) ---------- */
async function saveOut(filename,data,filters){
  if(window.api&&window.api.saveFile){const r=await window.api.saveFile(filename,data,filters);if(!r)throw Object.assign(new Error('annulé'),{code:'declined'});return r}
  const dl=window.claude&&window.claude.use?await window.claude.use('downloads'):null;
  if(!dl)throw new Error('Téléchargement indisponible dans cette vue.');
  await dl.save({filename,data});return filename}
/* ---------- génération PDF ---------- */
async function generateBytes(log){
  const{PDFDocument,StandardFonts,cmyk}=PDFLib;const s=S.sheet,rows=S.data.rows;
  if(!rows.length)throw new Error('Aucune ligne de données.');
  const missing=[];S.els.filter(e=>e.type==='qr').forEach(e=>rows.forEach((r,i)=>{if(!applyTpl('{'+e.col+'}',r).trim())missing.push(i+2)}));
  if(missing.length)throw new Error(`URL du QR vide aux lignes ${[...new Set(missing)].slice(0,15).join(', ')} du fichier.`);
  if(s.mL+gridW()>s.pageW+.01||s.mT+gridH()>s.pageH+.01)throw new Error('Les cartes dépassent de la page : ajuste l\'étape 4.');
  const out=await PDFDocument.create();out.registerFontkit(fontkit);
  const src=await PDFDocument.load(S.art.bytes.slice(0));const[emb]=await out.embedPages([src.getPage(0)]);
  let emb2=null;if(S.art2){const s2=await PDFDocument.load(S.art2.bytes.slice(0));[emb2]=await out.embedPages([s2.getPage(0)])}
  const fmap={};for(const f of S.fonts){if(!S.els.some(e=>e.type==='text'&&e.font===f.id))continue;
    fmap[f.id]=f.std?await out.embedFont(StandardFonts[f.std]):await out.embedFont(f.bytes.slice(0),{subset:true})}
  const PW=s.pageW*MM,PH=s.pageH*MM,per=s.cols*s.rows,warns=[];let page;
  rows.forEach((row,i)=>{
    const slot=i%per;if(slot===0)page=out.addPage([PW,PH]);
    const ox=s.mL+(slot%s.cols)*(s.cardW+s.gapX),oy=s.mT+Math.floor(slot/s.cols)*(s.cardH+s.gapY);
    page.drawPage((S.art2&&emb2&&artFor(row)===S.art2)?emb2:emb,{x:ox*MM,y:PH-(oy+s.cardH)*MM,width:s.cardW*MM,height:s.cardH*MM});
    S.els.forEach(e=>{
      const col=cmyk(...e.color.map(v=>v/100));
      if(e.type==='qr'){const m=qrMatrix(applyTpl('{'+e.col+'}',row).trim(),e.ecc);const G=qrGeom(e),sc=e.size*MM/QS_SIDE;
        if(G.st.box)page.drawSvgPath(roundRectPath(G.st.box.w*sc,G.st.box.h*sc,G.st.box.r*sc),{x:(ox+e.x)*MM,y:PH-(oy+e.y)*MM,color:cmyk(...(e.boxColor||[0,0,0,0]).map(v=>v/100)),borderWidth:0});
        page.drawSvgPath(qrPath(m,0,0,e.size*MM),{x:(ox+G.qx)*MM,y:PH-(oy+G.qy)*MM,color:col,borderWidth:0});
        if(G.st.text)page.drawSvgPath(G.st.text.d,{x:(ox+G.qx)*MM-G.st.text.ox*sc,y:PH-(oy+G.qy)*MM+G.st.text.oy*sc,scale:sc,color:col,borderWidth:0});
        if(m.length>45)warns.push(`Ligne ${i+2} : QR dense (${m.length} modules), URL longue.`)}
      else{
        const font=fmap[e.font];const clean=t=>{try{font.encodeText(t);return t}catch(x){const t2=[...t].map(ch=>{try{font.encodeText(ch);return ch}catch(y){return '?'}}).join('');warns.push(`Ligne ${i+2} : caractère non géré par ${fontById(e.font).label} dans « ${t} ».`);return t2}};
        const lines=applyTpl(e.tpl,row).split('\n').map(t=>clean(t.trim())).filter(Boolean);if(!lines.length)return;
        const size=fitLines(e,lines,(t,sz)=>font.widthOfTextAtSize(t,sz));
        if(size<e.size-.01)warns.push(`Ligne ${i+2} : « ${e.name} » réduit à ${size.toFixed(1)} pt.`);
        const szmm=size/MM;
        lines.forEach((t,k)=>page.drawText(t,{x:(ox+e.x)*MM,y:PH-(oy+effY(e,row)+szmm*ASC+k*szmm*e.lh)*MM,size,font,color:col}))}
    })});
  out.setTitle('Planche QR');out.setCreator('Planche QR');
  if(log)log(warns);
  return await out.save()}
$('#gen').onclick=async()=>{
  const lg=$('#log'),b=$('#gen');lg.textContent='';b.disabled=true;b.textContent='Génération…';
  try{
    const bytes=await generateBytes(w=>{lg.textContent=w.length?w.slice(0,40).join('\n')+(w.length>40?`\n… +${w.length-40}`:''):''});
    const path=await saveOut('planche.pdf',bytes,[{name:'PDF (ouvrable dans Illustrator)',extensions:['pdf']},{name:'Illustrator (.ai)',extensions:['ai']}]);
    lg.textContent=(lg.textContent?lg.textContent+'\n\n':'')+'Planche enregistrée : '+path+' ('+(bytes.length/1024/1024).toFixed(1)+' Mo).'
  }catch(e){lg.textContent=e&&e.code==='declined'?'Enregistrement annulé.':'Erreur : '+(e&&e.message||e)}
  finally{b.disabled=false;b.textContent='Générer la planche'}};

/* ---------- modèle (.json) ---------- */
function b64(u8){let s='';for(let i=0;i<u8.length;i+=0x8000)s+=String.fromCharCode.apply(null,u8.subarray(i,i+0x8000));return btoa(s)}
$('#saveModel').onclick=async()=>{
  const m={v:1,art2:S.art2?b64(new Uint8Array(S.art2.bytes)):null,art2Name:S.art2?S.art2.name:'',variantEl:S.variantEl,variantMin:S.variantMin,sheet:S.sheet,els:S.els.map(e=>{const c=Object.assign({},e);delete c._box;if(c.type==='text'){const f=fontById(c.font);if(!f.std)c.fontLabel=f.label}return c}),art:S.art.demo?null:b64(new Uint8Array(S.art.bytes)),artName:S.art.name,fonts:S.fonts.filter(f=>!f.std).map(f=>f.label)};
  const lg=$('#log');
  try{await saveOut('modele-planche.json',JSON.stringify(m),[{name:'Modèle de planche',extensions:['json']}]);lg.textContent='Modèle enregistré (carte, positions et réglages de planche). Les polices et les données ne sont pas incluses.'}catch(e){lg.textContent=e&&e.code==='declined'?'Enregistrement annulé.':'Erreur : '+(e&&e.message||e)}};
const fontByLabel=l=>S.fonts.find(f=>!f.std&&norm(f.label)===norm(l));
async function localFontByLabel(label){
  if(!window.queryLocalFonts)return null;
  try{if(!sysFonts)sysFonts=(await window.queryLocalFonts()).sort((a,b)=>(a.fullName||'').localeCompare(b.fullName||''));
    const words=norm(label).split(' ');const hay=f=>norm((f.fullName||'')+' '+(f.family||'')+' '+(f.style||''));
    const c=sysFonts.find(f=>norm(f.fullName)===norm(label))||sysFonts.filter(f=>words.every(w=>hay(f).includes(w))).sort((a,b)=>a.fullName.length-b.fullName.length)[0];
    if(!c)return null;const blob=await c.blob();const id=await addFont(await blob.arrayBuffer(),c.fullName);return S.fonts.find(f=>f.id===id)}catch(e){return null}}
async function applyModel(m){
  Object.assign(S.sheet,m.sheet);S.els=JSON.parse(JSON.stringify(m.els));S.nextId=1+Math.max(S.nextId,...S.els.map(e=>+String(e.id).replace(/\D/g,'')||0));S.sel=null;S.elsAreDemo=false;
  S.variantEl=m.variantEl||'';S.variantMin=m.variantMin||2;S.art2=null;syncSheetInputs();
  if(m.art2)await setArt2(Uint8Array.from(atob(m.art2),c=>c.charCodeAt(0)),m.art2Name||'variante.pdf');
  if(m.art)await setArt(Uint8Array.from(atob(m.art),c=>c.charCodeAt(0)),m.artName||'carte.pdf',false);else await drawArt();
  const missing=new Set(),found=new Set();
  for(const e of S.els){if(e.type!=='text')continue;
    if(e.fontLabel){const f=fontByLabel(e.fontLabel)||await localFontByLabel(e.fontLabel);if(f){e.font=f.id;found.add(f.label)}else{missing.add(e.fontLabel);if(!S.fonts.some(x=>x.id===e.font))e.font='helv'}}
    else if(!S.fonts.some(x=>x.id===e.font))e.font='helv'}
  sheetInfo();drawSheet();renderList();renderForm();drawAll();drawArt();
  return{missing:[...missing],found:[...found]}}
function modelMsg(r){return 'Modèle chargé.'+(r.found.length?' Polices trouvées : '+r.found.join(', ')+'.':'')+(r.missing.length?' Polices introuvables : '+r.missing.join(', ')+' (Helvetica en attendant, ajoute-les avec « Polices installées »).':'')+' Charge maintenant ton fichier de données.'}
$('#modelIn').onchange=async ev=>{const f=ev.target.files[0];if(!f)return;try{
  const r=await applyModel(JSON.parse(await f.text()));$('#log').textContent=modelMsg(r)}catch(e){$('#log').textContent='Modèle illisible : '+e.message}ev.target.value=''};
if(window.PRESETS){const ps=$('#presetSel');ps.hidden=false;Object.keys(window.PRESETS).forEach(k=>{const o=document.createElement('option');o.value=k;o.textContent=window.PRESETS[k].label;ps.appendChild(o)});
  ps.onchange=async()=>{if(!ps.value)return;$('#log').textContent='Chargement du modèle…';try{const r=await applyModel(window.PRESETS[ps.value]);$('#log').textContent=modelMsg(r)}catch(e){$('#log').textContent='Erreur : '+e.message}ps.value=''}}

/* ---------- fichiers ---------- */
async function onArt(f){try{const b=new Uint8Array(await f.arrayBuffer());await setArt(b,f.name,false)}catch(e){$('#artNote').className='note bad';$('#artNote').textContent='PDF illisible : '+e.message}}
$('#artIn').onchange=ev=>{if(ev.target.files[0])onArt(ev.target.files[0]);ev.target.value=''};
$('#dataIn').onchange=ev=>{if(ev.target.files[0])loadData(ev.target.files[0]).catch(e=>{$('#dataNote').className='note bad';$('#dataNote').textContent='Fichier illisible : '+e.message});ev.target.value=''};
async function addFont(buf,label){
  const id='f'+(S.nextId++);const fam='uf'+id;const ff=new FontFace(fam,buf.slice(0));await ff.load();document.fonts.add(ff);
  const bytes=new Uint8Array(buf);try{await PDFLib.PDFDocument.create().then(d=>{d.registerFontkit(fontkit);return d.embedFont(bytes,{subset:true})})}catch(e){throw new Error('format de police non géré ('+(e.message||e)+')')}
  S.fonts.push({id,label,family:`"${fam}", sans-serif`,weight:400,bytes});return id}
$('#fontIn').onchange=async ev=>{for(const f of ev.target.files){try{await addFont(await f.arrayBuffer(),f.name.replace(/\.(ttf|otf)$/i,''))}catch(e){$('#log').textContent='Police illisible : '+e.message}}
  ev.target.value='';renderForm();drawAll()};
let sysFonts=null;
$('#sysFonts').onclick=async()=>{
  const box=$('#sysBox');box.hidden=!box.hidden;if(box.hidden)return;
  if(!window.queryLocalFonts){$('#sysList').textContent='Accès aux polices installées indisponible ici. Utilise « + Police ».';return}
  try{if(!sysFonts)sysFonts=(await window.queryLocalFonts()).sort((a,b)=>(a.fullName||'').localeCompare(b.fullName||''));renderSys()}catch(e){$('#sysList').textContent='Accès refusé : '+e.message}};
$('#sysFilter').oninput=()=>renderSys();
function renderSys(){const q=norm($('#sysFilter').value);const L=$('#sysList');L.innerHTML='';
  (sysFonts||[]).filter(f=>!q||norm(f.fullName+' '+f.family).includes(q)).slice(0,60).forEach(f=>{const b=document.createElement('button');b.className='chip';b.style.textAlign='left';b.textContent=f.fullName;b.onclick=async()=>{
    try{const blob=await f.blob();const id=await addFont(await blob.arrayBuffer(),f.fullName);const e=byId(S.sel);if(e&&e.type==='text'){e.font=id;S.elsAreDemo=false}renderForm();drawAll();$('#log').textContent='Police ajoutée : '+f.fullName+(e&&e.type==='text'?' (appliquée à « '+(e.name||'texte')+' »)':'')}catch(x){$('#log').textContent='Police inutilisable : '+x.message}};L.appendChild(b)});
  if(!L.children.length)L.textContent='Aucune police trouvée.'}
['artDrop','dataDrop'].forEach(id=>{const z=$('#'+id);
  z.addEventListener('dragover',e=>{e.preventDefault();z.classList.add('on')});z.addEventListener('dragleave',()=>z.classList.remove('on'));
  z.addEventListener('drop',e=>{e.preventDefault();z.classList.remove('on');const f=e.dataTransfer.files[0];if(!f)return;id==='artDrop'?onArt(f):loadData(f).catch(x=>{$('#dataNote').className='note bad';$('#dataNote').textContent='Fichier illisible : '+x.message})})});
document.querySelectorAll('label.btn[tabindex]').forEach(l=>l.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();l.click()}}));
$('#rowSel').onchange=e=>{S.rowIdx=+e.target.value;drawAll();drawArt()};
$('#art2In').onchange=async ev=>{const f=ev.target.files[0];if(f){try{await setArt2(new Uint8Array(await f.arrayBuffer()),f.name)}catch(e){$('#artNote').className='note bad';$('#artNote').textContent='PDF illisible : '+e.message}}ev.target.value=''};
$('#art2Del').onclick=()=>{S.art2=null;refreshVariant();drawArt().then(drawOverlay)};
$('#varEl').onchange=e=>{S.variantEl=e.target.value;drawArt().then(drawOverlay)};
$('#varMin').oninput=e=>{S.variantMin=Math.max(2,Math.round(num(e.target.value,2)));drawArt().then(drawOverlay)};
$('#addText').onclick=()=>{const e={id:'e'+(S.nextId++),type:'text',name:'Texte',tpl:'{'+(S.data.cols[0]||'Colonne')+'}',font:'helv',size:6,x:7.3,y:40,color:[0,0,0,0],lh:1.2,maxW:42};S.els.push(e);S.elsAreDemo=false;select(e.id);drawAll()};
$('#delEl').onclick=()=>{const e=byId(S.sel);if(!e)return;S.els=S.els.filter(x=>x!==e);S.sel=null;S.elsAreDemo=false;renderList();renderForm();drawAll()};

function drawAll(skipList){drawOverlay();drawSheet();if(!skipList)renderList()}
new ResizeObserver(()=>{sizeBox();drawArt().then(drawOverlay)}).observe($('#stageWrap'));
function sizeBox(){const wrap=$('#stageWrap'),box=$('#cardBox');const W=Math.min(wrap.clientWidth-32,760);box.style.width=Math.max(200,W)+'px';box.style.aspectRatio=`${S.sheet.cardW}/${S.sheet.cardH}`}
new MutationObserver(()=>drawSheet()).observe(document.documentElement,{attributes:true,attributeFilter:['data-theme']});
if(window.matchMedia)window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change',drawSheet);

/* ---------- démarrage ---------- */
(async function init(){
  S.els=defaultEls();S.sel=S.els[1].id;
  S.data={cols:['Prénom','Nom','Poste','Email','Téléphone','URL QR'],rows:demoRows(),name:'',demo:true};
  buildSheetInputs();refreshData();sheetInfo();sizeBox();renderList();renderForm();
  await setArt(await demoCard(),'',true);drawAll();
  window.__planche={S,generateBytes,setArt,loadData,applyTpl};
  if(window.api&&window.api.contentReady)window.api.contentReady();
  if(window.api&&window.api.appInfo)window.api.appInfo().then(i=>{const t=document.querySelector('.brand span');if(t)t.title='Version '+i.version+(i.downloaded?' (mise à jour)':'')}).catch(()=>{});
})();
})();
