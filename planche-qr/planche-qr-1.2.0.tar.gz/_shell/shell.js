/**
 * VKARD Planche QR — coquille (fenêtre, menus, enregistrement des fichiers, mises à jour).
 * Livrée avec les mises à jour en direct (dans renderer/_shell/) : chargée par l'amorce main.js.
 * Une évolution de ce fichier ne demande donc plus de réinstaller l'application.
 */
const { app, BrowserWindow, dialog, ipcMain, session, Menu, shell } = require('electron');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');

module.exports = function start(ctx) {
const APP_NAME = ctx.APP_NAME;
const RELEASES = process.env.PLANCHE_RELEASES || 'https://raw.githubusercontent.com/koalartpro-ai/vkard-bat-studio-releases/main/planche-qr';
const AUTOTEST = !!process.env.PLANCHE_AUTOTEST;
const { bundledDir, bundledVersion, contentRoot, stateFile, badFile, logFile, log, readJson, newer, content } = ctx;
let win = null, readyVersion = null, busy = false, shellNoticeShown = false, contentReady = false;

const box = (opts) => AUTOTEST ? Promise.resolve({ response: 0 }) : dialog.showMessageBox(win || undefined, Object.assign({ type: 'info', title: APP_NAME }, opts));
const untar = (archive, dir) => new Promise((res, rej) => {
  const bin = process.platform === 'win32' ? path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'tar.exe') : 'tar';
  execFile(bin, ['-xzf', archive, '-C', dir], { windowsHide: true }, (e) => e ? rej(e) : res());
});

async function checkContentUpdate(manual) {
  if (busy) return; busy = true;
  const info = (message, detail) => manual && box({ message, detail });
  try {
    const r = await fetch(`${RELEASES}/manifest.json?t=${Date.now()}`, { cache: 'no-store' });
    if (!r.ok) throw new Error(`manifeste indisponible (${r.status})`);
    const m = await r.json();
    if (!m || !m.version || !m.archive || !m.sha256) throw new Error('manifeste invalide');
    const active = readyVersion || content.version;
    if (!newer(m.version, active)) { info('Vous utilisez la dernière version', `Version ${content.version}`); return; }
    if ((m.minShell || 1) > ctx.BOOT_VERSION) {
      log('maj', `version ${m.version} : nouvel installateur requis (minShell ${m.minShell})`);
      if (manual || !shellNoticeShown) {
        shellNoticeShown = true;
        const { response } = await box({ buttons: m.installerUrl ? ['Télécharger', 'Plus tard'] : ['OK'], defaultId: 0, cancelId: 1,
          message: `La version ${m.version} nécessite un nouvel installateur`, detail: 'Vos modèles et réglages sont conservés : il suffit d’installer par-dessus la version actuelle.' });
        if (response === 0 && m.installerUrl) shell.openExternal(m.installerUrl);
      }
      return;
    }
    if (readJson(badFile, []).includes(m.version)) return;
    log('maj', `téléchargement de la version ${m.version}`);
    if (win) win.setProgressBar(2);
    const res = await fetch(`${RELEASES}/${m.archive}?t=${Date.now()}`, { cache: 'no-store' });
    if (!res.ok) throw new Error(`archive indisponible (${res.status})`);
    const buf = Buffer.from(await res.arrayBuffer());
    if (crypto.createHash('sha256').update(buf).digest('hex') !== m.sha256) throw new Error('empreinte SHA-256 incorrecte');
    fs.mkdirSync(contentRoot, { recursive: true });
    const archive = path.join(contentRoot, `${m.version}.tar.gz`), tmp = path.join(contentRoot, `${m.version}.tmp`), dir = path.join(contentRoot, m.version);
    fs.writeFileSync(archive, buf);
    fs.rmSync(tmp, { recursive: true, force: true }); fs.mkdirSync(tmp, { recursive: true });
    await untar(archive, tmp);
    if (!fs.existsSync(path.join(tmp, 'index.html'))) throw new Error('archive incomplète');
    fs.rmSync(dir, { recursive: true, force: true }); fs.renameSync(tmp, dir); fs.rmSync(archive, { force: true });
    fs.writeFileSync(stateFile, JSON.stringify({ version: m.version, installedAt: new Date().toISOString() }));
    readyVersion = m.version;
    for (const d of fs.readdirSync(contentRoot)) if (![m.version, content.version, 'current.json', 'bad.json'].includes(d)) fs.rmSync(path.join(contentRoot, d), { recursive: true, force: true });
    if (win) win.setProgressBar(-1);
    log('maj', `version ${m.version} prête`);
    const notes = typeof m.notes === 'string' ? m.notes.trim().slice(0, 700) : '';
    const { response } = await box({ buttons: ['Redémarrer maintenant', 'Plus tard'], defaultId: 0, cancelId: 1,
      message: `La version ${m.version} est prête`, detail: `${notes ? notes + '\n\n' : ''}Vos modèles et réglages sont conservés. Avec « Plus tard », elle sera utilisée au prochain démarrage.` });
    if (response === 0) { app.relaunch(); app.exit(0); }
  } catch (e) {
    if (win) win.setProgressBar(-1);
    log('maj', `vérification impossible : ${e && e.message || e}`);
    if (manual) box({ type: 'warning', message: 'Impossible de vérifier les mises à jour', detail: 'Vérifiez la connexion Internet puis réessayez.' });
  } finally { busy = false; }
}

function markBadAndRestart(why) {
  if (!content.downloaded) return;
  writeBad(content.version); log('maj', `version ${content.version} écartée (${why}), retour à la version intégrée ${bundledVersion}`);
  app.relaunch(); app.exit(0);
}
function writeBad(v) { fs.mkdirSync(contentRoot, { recursive: true }); fs.writeFileSync(badFile, JSON.stringify([...new Set([...readJson(badFile, []), v])])); }

function createWindow() {
  win = new BrowserWindow({
    width: 1440, height: 920, minWidth: 980, minHeight: 640, title: 'VKARD — Planche QR', backgroundColor: '#F4F4F2', show: false,
    icon: path.join(ctx.bundledDir, 'icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true }
  });
  win.once('ready-to-show', () => win.show());
  win.loadFile(path.join(content.dir, 'index.html'));
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('did-fail-load', () => markBadAndRestart('chargement impossible'));
  win.on('closed', () => (win = null));
  if (content.downloaded) setTimeout(() => { if (!contentReady) markBadAndRestart('ne démarre pas'); }, 25000);
}

function buildMenu() {
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    { label: 'Fichier', submenu: [{ label: 'Ouvrir le dossier des données', click: () => shell.openPath(app.getPath('userData')) }, { type: 'separator' }, { role: 'quit', label: 'Quitter' }] },
    { label: 'Affichage', submenu: [{ role: 'reload', label: 'Recharger' }, { role: 'resetZoom', label: 'Taille réelle' }, { role: 'zoomIn', label: 'Zoom avant' }, { role: 'zoomOut', label: 'Zoom arrière' }, { type: 'separator' }, { role: 'togglefullscreen', label: 'Plein écran' }, { role: 'toggleDevTools', label: 'Outils de développement' }] },
    { label: 'Aide', submenu: [{ label: 'Rechercher des mises à jour…', click: () => checkContentUpdate(true) }, { label: 'Journal de l’application', click: () => shell.openPath(logFile) }, { type: 'separator' },
      { label: `À propos — version ${content.version}${content.downloaded ? ' (mise à jour)' : ''}`, enabled: false }] }
  ]));
}

app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
process.on('uncaughtException', (e) => log('uncaughtException', e && e.stack || e));
process.on('unhandledRejection', (e) => log('unhandledRejection', e && e.stack || e));

app.whenReady().then(() => {
  session.defaultSession.setPermissionRequestHandler((wc, perm, cb) => cb(perm === 'local-fonts'));   // polices installées (Avenir…)
  session.defaultSession.setPermissionCheckHandler((wc, perm) => perm === 'local-fonts');
  ipcMain.on('content-ready', () => { contentReady = true; });
  ipcMain.handle('app-info', () => ({ version: content.version, downloaded: content.downloaded, shell: ctx.BOOT_VERSION }));
  ipcMain.handle('check-update', () => checkContentUpdate(true));
  // plusieurs planches : un dossier (nommé comme les fichiers) contenant un fichier par planche
  ipcMain.handle('save-folder', async (e, { folderName, files }) => {
    const w = BrowserWindow.fromWebContents(e.sender);
    const r = AUTOTEST && process.env.PLANCHE_TEST_DIR ? { canceled: false, filePaths: [process.env.PLANCHE_TEST_DIR] } : await dialog.showOpenDialog(w, { title: 'Choisir où créer le dossier « ' + folderName + ' »', buttonLabel: 'Enregistrer ici', properties: ['openDirectory', 'createDirectory'] });
    if (r.canceled || !r.filePaths || !r.filePaths[0]) return null;
    let dir = path.join(r.filePaths[0], folderName), k = 2;
    while (fs.existsSync(dir) && fs.readdirSync(dir).some((f) => files.some((x) => x.name === f))) dir = path.join(r.filePaths[0], `${folderName} (${k++})`);
    fs.mkdirSync(dir, { recursive: true });
    for (const f of files) fs.writeFileSync(path.join(dir, f.name), Buffer.from(f.data));
    shell.openPath(dir);
    return dir;
  });
  ipcMain.handle('save-file', async (e, { name, data, filters }) => {
    const w = BrowserWindow.fromWebContents(e.sender);
    const r = await dialog.showSaveDialog(w, { defaultPath: name, filters: filters && filters.length ? filters : undefined });
    if (r.canceled || !r.filePath) return null;
    fs.writeFileSync(r.filePath, typeof data === 'string' ? data : Buffer.from(data));
    return r.filePath;
  });
  buildMenu();
  log('démarrage', `version ${content.version}${content.downloaded ? ' (téléchargée)' : ' (intégrée)'}`);
  createWindow();
  setTimeout(() => checkContentUpdate(false), AUTOTEST ? 1500 : 5000);
  setInterval(() => checkContentUpdate(false), 4 * 3600 * 1000);
});
app.on('window-all-closed', () => app.quit());
};
