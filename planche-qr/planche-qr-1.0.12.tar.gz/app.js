(function(){
'use strict';
const $=s=>document.querySelector(s);
const MM=72/25.4, ASC=0.8; // une position de texte = haut du bloc ; ligne de base = haut + 0,8 x corps
const NS='http://www.w3.org/2000/svg';
try{pdfjsLib.GlobalWorkerOptions.workerSrc='vendor/pdf.worker.min.js'}catch(e){}
try{qrcode.stringToBytes=qrcode.stringToBytesFuncs['UTF-8']}catch(e){}

/* ---------- état ---------- */
const S={
  art:{bytes:null,wpt:0,hpt:0,name:'',doc:null,demo:true},
  art2:null,variantEl:'',variantMin:2,bg:null,bgKind:'none',fit:'auto',
  sheet:{pageW:304,pageH:412,cols:3,rows:6,cardW:89.5,cardH:58,gapX:7,gapY:9,mL:11.5,mT:8},
  data:{cols:[],rows:[],name:'',demo:true},
  rowIdx:0,
  fonts:[
    {id:'helv',label:'Helvetica',family:'Helvetica, Arial, "Liberation Sans", sans-serif',weight:400,std:'Helvetica'},
    {id:'helv-b',label:'Helvetica Gras',family:'Helvetica, Arial, "Liberation Sans", sans-serif',weight:700,std:'HelveticaBold'}],
  els:[],sel:null,nextId:1,elsAreDemo:true
};
const byId=id=>S.els.find(e=>e.id===id);
const fontById=id=>S.fonts.find(f=>f.id===id)||S.fonts[0];

/* ---------- utilitaires ---------- */
const norm=s=>String(s==null?'':s).normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase().replace(/[#°.:]/g,'').replace(/[\s_]+/g,' ').trim();
const num=(v,d)=>{const n=parseFloat(String(v).replace(',','.'));return isFinite(n)?n:d};
const r2=v=>Math.round(v*100)/100;
function cmykRgb(c){const[C,M,Y,K]=c.map(v=>v/100);return `rgb(${Math.round(255*(1-C)*(1-K))},${Math.round(255*(1-M)*(1-K))},${Math.round(255*(1-Y)*(1-K))})`}
const ALIAS=[['prenom','firstname','first name','given name'],['nom','name','lastname','nom de famille'],['poste','titre','fonction','title','job','intitule'],['email','e-mail','mail','courriel','adresse mail','adresse email'],['tel','telephone','mobile','portable','phone','numero','num','numero de telephone','n de telephone','gsm','tel portable'],['url','lien','url qr','qr','lien qr','url du qr','qrcode','qrcodes','qr code','qr codes','code qr','lien qr code','lien vkard','vkard']];
function rowKey(row,name){const n=norm(name);for(const k in row){if(norm(k)===n)return row[k]}
  const g=ALIAS.find(g=>g.includes(n));if(g)for(const k in row){if(g.includes(norm(k)))return row[k]}return undefined}
function hasCol(k){const n=norm(k);if(S.data.cols.some(c=>norm(c)===n))return true;const g=ALIAS.find(g=>g.includes(n));return !!g&&S.data.cols.some(c=>g.includes(norm(c)))}
function fmtTel(v){let d=String(v).replace(/[^\d+]/g,'');if(!d)return String(v);
  if(d.startsWith('00'))d='+'+d.slice(2);else if(/^0\d{9}$/.test(d))d='+33'+d.slice(1);else if(/^33\d{9}$/.test(d))d='+'+d;
  const m=/^\+33(\d)(\d{2})(\d{2})(\d{2})(\d{2})$/.exec(d);return m?`+33 ${m[1]} ${m[2]} ${m[3]} ${m[4]} ${m[5]}`:String(v)}
function applyTpl(tpl,row,typo){
  const out=String(tpl).replace(/\{([^}|]+?)(?:\|(upper|lower|title|telbrut|tel))?\}/g,(m,k,f)=>{
    let v=rowKey(row,k);if(v===undefined)return '';v=String(v);if(f==='tel')return fmtTel(v);if(f==='telbrut'){const t=fmtTel(v);return t.startsWith('+')?t.replace(/\s/g,''):v}
    if(f==='upper')v=v.toUpperCase();else if(f==='lower')v=v.toLowerCase();else if(f==='title')v=v.toLowerCase().replace(/(^|[\s'’-])(\p{L})/gu,(a,b,c)=>b+c.toUpperCase());
    return v});
  const o2=out.replace(/\+\s*(?=\+)/g,'');
  return typo?o2.replace(/'/g,'\u2019'):o2;
}
function tplMissing(tpl){const out=[];String(tpl).replace(/\{([^}|]+?)(?:\|\w+)?\}/g,(m,k)=>{if(!hasCol(k))out.push(k)});return out}
const curRow=()=>S.data.rows[S.rowIdx]||{};
function effY(e,row){if(e.type!=='text'||!e.flow)return e.y;const ref=byId(e.flow);if(!ref||ref.type!=='text'||ref===e)return e.y;const extra=Math.max(0,nLines(ref,row)-1);const step=e.flowStep>0?e.flowStep:ref.size/MM*ref.lh;return e.y+extra*step}
const mmFmt=v=>String(r2(v)).replace('.',',');

/* ---------- Styles de QR (charte : fichier QRCODE-01.svg ; unités = points du fichier, QR = 62,37 pt de côté) ---------- */
const QS_SIDE=62.37;
const QS={
  boxtext:{label:'Boîte blanche + VKARD.IO',box:{w:73.7,h:82.21,r:3.61},qx:5.67,qy:5.63,text:{ox:228.87,oy:81.44,d:'M290.89,148.38c-.24-.42-.57-.75-.98-.98-.41-.24-.87-.35-1.38-.35s-.96.12-1.37.35c-.41.23-.74.56-.98.98-.24.42-.36.89-.36,1.41s.12,1,.36,1.42c.24.42.57.75.98.98.41.24.87.36,1.37.36s.96-.12,1.37-.35c.41-.24.74-.57.98-.99.24-.42.36-.89.36-1.42s-.12-1-.36-1.41M289.7,149.8c0,.41-.1.72-.32.96-.21.23-.49.35-.84.35s-.64-.11-.85-.35c-.21-.24-.32-.55-.32-.96s.1-.73.32-.97c.21-.23.49-.34.85-.34s.64.11.85.35c.21.23.32.55.32.96M279.94 147.13h1.53v5.37h-1.53zM274.06 150.97h1.57v1.53h-1.57zM268.6,147.46c-.42-.22-.92-.33-1.48-.33h-2.07v5.37h2.07c.56,0,1.06-.11,1.48-.34.42-.23.75-.55.98-.96.22-.4.34-.88.34-1.4s-.11-.99-.34-1.39c-.23-.4-.55-.72-.98-.95M268.38,149.8c0,.42-.12.73-.35.96-.24.23-.58.34-1.01.34h-.43v-2.6h.43c.44,0,.77.11,1.01.34.23.22.35.55.35.96M260.43,149.92c.22-.28.34-.63.34-1.03,0-.34-.08-.64-.23-.9-.15-.27-.39-.48-.69-.63-.3-.15-.66-.22-1.09-.22h-2.24v5.37h1.53v-1.92h.04l1.1,1.92h1.71l-1.24-2.06c.33-.11.59-.29.78-.53M258.05,148.46h.61c.2,0,.34.04.43.13.09.09.13.21.13.36,0,.17-.04.29-.12.37-.09.08-.23.12-.44.12h-.61v-.98ZM248.86,147.16l-1.97,5.34h1.61l.32-.93h1.69l.32.93h1.63l-1.97-5.34h-1.62ZM250.09,150.34h-.85l.43-1.25.42,1.25ZM241.44 147.13 L239.93 149.07 L239.93 147.13 L238.4 147.13 L238.4 152.5 L239.93 152.5 L239.93 150.52 L241.43 152.5 L243.3 152.5 L241.13 149.76 L243.3 147.13 L241.44 147.13ZM231.56 150.61 L230.46 147.23 L230.43 147.13 L228.79 147.13 L230.66 152.5 L232.45 152.5 L234.32 147.13 L232.69 147.13 L231.56 150.61Z'}},
  box:{label:'Boîte blanche',box:{w:73.7,h:73.7,r:3.61},qx:5.67,qy:5.67,text:null},
  text:{label:'QR + VKARD.IO (sans boîte)',box:null,qx:0,qy:0,text:{ox:134.99,oy:88.57,d:'M194.65,158.38c-.4,0-.72-.13-.96-.4s-.36-.62-.36-1.06.12-.81.36-1.07c.24-.26.56-.39.96-.39s.72.13.96.4.35.62.35,1.06-.12.8-.36,1.06c-.24.26-.56.4-.95.4M194.65,159.53c.47,0,.9-.11,1.29-.33.39-.22.7-.53.93-.93.23-.4.34-.84.34-1.34s-.11-.94-.34-1.34c-.22-.39-.53-.7-.92-.92-.39-.22-.82-.33-1.3-.33s-.9.11-1.29.33c-.39.22-.7.53-.93.92-.23.4-.34.84-.34,1.34s.11.94.34,1.34c.23.4.54.71.93.93.39.22.82.33,1.29.33M187.43,154.41h-1.23v5.07h1.23v-5.07ZM181.6,158.26h-1.27v1.23h1.27v-1.23ZM175.56,155.62c-.21-.38-.52-.68-.92-.89-.4-.21-.87-.32-1.41-.32h-1.92v5.07h1.92c.54,0,1.01-.11,1.41-.32.4-.22.71-.51.92-.9.21-.39.32-.83.32-1.32s-.11-.94-.32-1.32M174.24,158c-.27.25-.64.38-1.12.38h-.58v-2.9h.58c.48,0,.85.13,1.12.38.26.25.4.61.4,1.07s-.13.81-.4,1.07M166.43,156.96c.2-.26.31-.57.31-.94,0-.31-.07-.59-.21-.83-.14-.24-.35-.43-.62-.57-.28-.14-.62-.21-1.02-.21h-2.1v5.07h1.23v-1.92h.28l1.1,1.92h1.36l-1.21-1.99c.39-.1.68-.27.89-.53M165.31,156.57c-.12.11-.29.16-.54.16h-.76v-1.28h.76c.24,0,.42.06.53.17.12.12.18.27.18.47,0,.21-.06.37-.17.48M155.08,154.45l-1.86,5.04h1.29l.32-.93h1.9l.32.93h1.31l-1.86-5.04h-1.41ZM155.14,157.62l.64-1.87.63,1.87h-1.27ZM147.63 154.41 L145.89 156.64 L145.89 154.41 L144.67 154.41 L144.67 159.48 L145.89 159.48 L145.89 157.21 L147.62 159.48 L149.1 159.48 L147.06 156.89 L149.1 154.41 L147.63 154.41ZM137.67 158.23 L136.43 154.41 L135.12 154.41 L136.88 159.48 L138.46 159.48 L140.23 154.41 L138.91 154.41 L137.67 158.23Z',h:70.96}},
  plain:{label:'QR seul',box:null,qx:0,qy:0,text:null}};
function roundRectPath(w,h,r){const k=r*.5523,i=r-k;return `M${r} 0H${w-r}c${k} 0 ${r} ${i} ${r} ${r}V${h-r}c0 ${k} ${-i} ${r} ${-r} ${r}H${r}c${-k} 0 ${-r} ${-i} ${-r} ${-r}V${r}c0 ${-k} ${i} ${-r} ${r} ${-r}Z`}
/* géométrie d'un bloc QR en mm : le bloc (boîte + QR + texte) est homothétique, e.size = côté du QR */
function qrGeom(e){const st=QS[e.style]||QS.boxtext,u=e.size/QS_SIDE;
  const w=(st.box?st.box.w:QS_SIDE)*u,h=(st.box?st.box.h:(st.text&&st.text.h?st.text.h:QS_SIDE))*u;
  return{st,u,w,h,qx:e.x+st.qx*u,qy:e.y+st.qy*u}}

/* ---------- QR ---------- */
function qrMatrix(text,ecc){
  const q=qrcode(0,ecc||'M');q.addData(text,'Byte');q.make();const n=q.getModuleCount(),m=[];
  for(let r=0;r<n;r++){const row=[];for(let c=0;c<n;c++)row.push(q.isDark(r,c));m.push(row)}return m}
function qrPath(m,x0,y0,size){ // tracé unique, runs fusionnés
  const n=m.length,mod=size/n,runs=new Map();
  for(let r=0;r<n;r++){let c=0;while(c<n){if(m[r][c]){const s=c;while(c<n&&m[r][c])c++;const k=s+'-'+c;if(!runs.has(k))runs.set(k,[]);runs.get(k).push(r)}else c++}}
  let d='';const f=v=>(+v.toFixed(4));
  for(const[k,rows]of runs){const[s,e]=k.split('-').map(Number);let a=rows[0],p=a;
    for(let i=1;i<=rows.length;i++){const r=rows[i];if(r===undefined||r!==p+1){d+=`M${f(x0+s*mod)} ${f(y0+a*mod)}h${f((e-s)*mod)}v${f((p+1-a)*mod)}h${f(-(e-s)*mod)}z`;a=r}p=r}}
  return d}

/* ---------- police : mesure (aperçu) ---------- */
const mctx=document.createElement('canvas').getContext('2d');
function measure(fontId,text,sizePt){const f=fontById(fontId);mctx.font=`${f.weight>=600?'bold ':''}${sizePt}px ${f.family}`;return mctx.measureText(text).width}
function fitLines(el,lines,measureFn){
  let size=el.size;if(!(el.maxW>0))return size;const maxPt=el.maxW*MM;
  const w=Math.max(0,...lines.map(l=>measureFn(l,size)));
  return w>maxPt?Math.max(3,size*maxPt/w):size}

/* ---------- éléments par défaut (exemple) ---------- */
function defaultEls(){
  const mk=(o)=>Object.assign({id:'e'+(S.nextId++)},o);
  const L=[
    mk({type:'qr',name:'QR code',col:'URL QR',style:'boxtext',x:50.3,y:14.9,size:+(QS_SIDE/MM).toFixed(2),ecc:'M',color:[0,0,0,100],boxColor:[0,0,0,0]}),
    mk({type:'text',name:'Nom',tpl:'{Prénom} {Nom|upper}',font:'helv-b',size:8.5,x:7.3,y:19.5,color:[66,19,0,0],lh:1.2,maxW:42}),
    mk({type:'text',name:'Poste',tpl:'{Poste}',font:'helv',size:6.5,x:7.3,y:22.9,color:[66,19,0,0],lh:1.2,maxW:42,wrap:true}),
    mk({type:'text',name:'Email',tpl:'{Email}',font:'helv',size:5.5,x:11.5,y:26.5,color:[0,0,0,0],lh:1.2,maxW:38,flow:'@poste'}),
    mk({type:'text',name:'Téléphone',tpl:'{Téléphone}',font:'helv',size:5.5,x:11.5,y:29.8,color:[0,0,0,0],lh:1.2,maxW:38,flow:'@poste'})];
  const poste=L.find(e=>e.name==='Poste');L.forEach(e=>{if(e.flow==='@poste')e.flow=poste.id});return L;
}
function autoMapCols(){ // quand l'utilisateur charge ses données et n'a pas encore modifié les éléments
  const find=(...a)=>S.data.cols.find(c=>a.includes(norm(c)));
  const pre=find('prenom','firstname','first name'),nom=find('nom','name','lastname','nom de famille'),full=find('nom complet','fullname');
  const poste=find('poste','titre','fonction','title','job'),mail=find('email','e-mail','mail','courriel'),tel=find('tel','telephone','mobile','portable','phone','numero','num','gsm');
  const url=find('url','lien','url qr','qr','lien qr','url du qr','qrcode','qrcodes','qr code','qr codes','code qr');
  for(const e of S.els){
    if(e.type==='qr'&&url)e.col=url;
    if(e.name==='Nom')e.tpl=full?`{${full}}`:(pre&&nom?`{${pre}} {${nom}|upper}`:(nom?`{${nom}}`:e.tpl));
    if(e.name==='Poste'&&poste)e.tpl=`{${poste}}`;
    if(e.name==='Email'&&mail)e.tpl=`{${mail}}`;
    if(e.name==='Téléphone'&&tel)e.tpl=`{${tel}}`;
  }}

/* ---------- carte de démonstration (générée) ---------- */
async function demoCard(){
  const{PDFDocument,cmyk}=PDFLib;const d=await PDFDocument.create();const w=S.sheet.cardW*MM,h=S.sheet.cardH*MM;const p=d.addPage([w,h]);
  p.drawRectangle({x:0,y:0,width:w,height:h,color:cmyk(0,0,0,1)});
  p.drawCircle({x:w-16,y:22,size:46,borderColor:cmyk(.9,.1,.5,0),borderWidth:5});
  p.drawCircle({x:w-4,y:6,size:62,borderColor:cmyk(.75,.2,0,0),borderWidth:5});
  const f=await d.embedFont(PDFLib.StandardFonts.HelveticaBold);
  p.drawText('ENTREPRISE',{x:7.3*MM,y:h-9*MM,size:11,font:f,color:cmyk(0,0,0,0)});
  p.drawText('CARTE DE BASE (EXEMPLE)',{x:7.3*MM,y:h-12.2*MM,size:5,font:f,color:cmyk(.66,.19,0,0)});
  const b=await d.save();return b}
const demoRows=()=>[
  {'Prénom':'Camille','Nom':'Martin','Poste':'Responsable Achats','Email':'camille.martin@exemple.fr','Téléphone':'+33 6 12 34 56 78','URL QR':'https://exemple.fr/c/camille-martin'},
  {'Prénom':'Julien','Nom':'Dubois','Poste':'Chargé d’Affaires','Email':'julien.dubois@exemple.fr','Téléphone':'+33 6 98 76 54 32','URL QR':'https://exemple.fr/c/julien-dubois'},
  {'Prénom':'Inès','Nom':'Ait Ayoub','Poste':'Alternante Manager\nde la Performance Commerciale','Email':'ines.aitayoub@exemple.fr','Téléphone':'+33 7 64 75 24 08','URL QR':'https://exemple.fr/c/ines-ait-ayoub'}];

/* ---------- chargement carte ---------- */
async function setArt(bytes,name,demo){
  const src=await PDFLib.PDFDocument.load(bytes.slice(0));const sz=src.getPage(0).getSize();
  const doc=await pdfjsLib.getDocument({data:bytes.slice(0)}).promise;
  const pgb=src.getPage(0),mbx=pgb.getMediaBox(),tb=pgb.getTrimBox(),trim={x:tb.x-mbx.x,y:tb.y-mbx.y,w:tb.width,h:tb.height};
  S.art={bytes,wpt:sz.width,hpt:sz.height,trim,name,doc,demo:!!demo};
  $('#artInfo').textContent=demo?'exemple':`${name} · ${mmFmt(sz.width/MM)} × ${mmFmt(sz.height/MM)} mm`;
  const dw=sz.width/MM-S.sheet.cardW,dh=sz.height/MM-S.sheet.cardH;
  const n=$('#artNote');
  await detectBg();
  const pl=artPlace(S.art);
  if(!demo&&pl.mode==='center'&&pl.aw>=S.sheet.cardW-.2&&pl.ah>=S.sheet.cardH-.2&&(Math.abs(dw)>.2||Math.abs(dh)>.2)){n.className='note ok';n.textContent=`Carte de ${mmFmt(sz.width/MM)} × ${mmFmt(sz.height/MM)} mm avec fond perdu : centrée sur son format fini et rognée à l'emplacement de ${mmFmt(S.sheet.cardW)} × ${mmFmt(S.sheet.cardH)} mm.`}
  else if(!demo&&pl.mode==='center'&&(Math.abs(dw)>.2||Math.abs(dh)>.2)){n.className='note ok';n.textContent=`Carte de ${mmFmt(sz.width/MM)} × ${mmFmt(sz.height/MM)} mm centrée dans l'emplacement de ${mmFmt(S.sheet.cardW)} × ${mmFmt(S.sheet.cardH)} mm. Fond perdu : `+(S.bg?'aplat uni étendu autour de la carte.':'pas de fond (la carte est imprimée sans aplat), rien n\'est ajouté.')}
  else if(!demo&&S.bgKind==='complex'&&(Math.abs(dw)>.2||Math.abs(dh)>.2)){n.className='note warn';n.textContent=`Fond non uni (dégradé ou image) : le fond perdu ne peut pas être reconstitué, la carte de ${mmFmt(sz.width/MM)} × ${mmFmt(sz.height/MM)} mm est étirée à ${mmFmt(S.sheet.cardW)} × ${mmFmt(S.sheet.cardH)} mm. Mieux vaut fournir un PDF avec fond perdu.`}
  else if(!demo&&(Math.abs(dw)>.5||Math.abs(dh)>.5)){n.className='note warn';n.textContent=`Le PDF fait ${mmFmt(sz.width/MM)} × ${mmFmt(sz.height/MM)} mm ; la carte de la planche fait ${mmFmt(S.sheet.cardW)} × ${mmFmt(S.sheet.cardH)} mm. Le visuel sera étiré. Étape 4 : « Taille de carte = taille du PDF » pour garder la taille d'origine.`}
  else if(!demo){n.className='note ok';n.textContent='Taille cohérente avec la carte de la planche.'}
  else{n.className='note';n.textContent='Carte d\'exemple. Remplace-la par le PDF de ta carte, sans QR ni texte variable.'}
  await drawArt();drawAll()}
function textLines(e,row){let lines=applyTpl(e.tpl,row,true).split('\n').map(t=>t.trim()).filter(Boolean);
  if(e.wrap&&e.maxW>0){const maxPt=e.maxW*MM,out=[];
    for(const l of lines){let cur='';for(const w of l.split(/\s+/)){const t=cur?cur+' '+w:w;if(cur&&measure(e.font,t,e.size)>maxPt){out.push(cur);cur=w}else cur=t}if(cur)out.push(cur)}
    lines=out}
  return lines}
const nLines=(e,row)=>textLines(e,row).length;
function artFor(row){if(S.art2&&S.variantEl){const e=byId(S.variantEl);if(e&&e.type==='text'&&nLines(e,row)>=S.variantMin)return S.art2}return S.art}
async function setArt2(bytes,name){
  const src=await PDFLib.PDFDocument.load(bytes.slice(0));const sz=src.getPage(0).getSize();
  const pgb=src.getPage(0),mbx=pgb.getMediaBox(),tb=pgb.getTrimBox(),trim={x:tb.x-mbx.x,y:tb.y-mbx.y,w:tb.width,h:tb.height};
  S.art2={bytes,wpt:sz.width,hpt:sz.height,trim,name,doc:await pdfjsLib.getDocument({data:bytes.slice(0)}).promise};refreshVariant();await drawArt();drawOverlay()}
function refreshVariant(){
  $('#art2Info').textContent=S.art2?S.art2.name:'aucune';$('#art2Del').hidden=!S.art2;
  const sel=$('#varEl');sel.innerHTML='<option value="">—</option>';S.els.filter(e=>e.type==='text').forEach(e=>{const o=document.createElement('option');o.value=e.id;o.textContent=e.name||e.tpl;sel.appendChild(o)});
  if(S.variantEl&&!byId(S.variantEl))S.variantEl='';sel.value=S.variantEl;$('#varMin').value=S.variantMin;
  if(S.art2)$('#varBox').open=true}
/* Placement du visuel dans l'emplacement de la planche : centré à sa taille réelle (le fond uni est étendu = fond perdu) ou étiré */
function artPlace(art){const aw=art.wpt/MM,ah=art.hpt/MM,cw=S.sheet.cardW,ch=S.sheet.cardH;
  const t=art.trim&&art.trim.w>10?art.trim:{x:0,y:0,w:art.wpt,h:art.hpt},tw=t.w/MM,th=t.h/MM,tx=t.x/MM,ttop=(art.hpt-t.y-t.h)/MM;
  const near=Math.abs(cw-tw)<=12&&Math.abs(ch-th)<=12,covers=aw>=cw-.2&&ah>=ch-.2;
  let mode=S.fit;if(!mode||mode==='auto')mode=near&&(S.bgKind!=='complex'||covers)?'center':'stretch';
  return mode==='center'?{mode,aw,ah,ox:(cw-tw)/2-tx,oy:(ch-th)/2-ttop,sx:1,sy:1,dw:aw,dh:ah}:{mode,aw,ah,ox:0,oy:0,sx:cw/aw,sy:ch/ah,dw:cw,dh:ch}}
let curDoc=null;
async function drawArt(){
  const art=artFor(curRow());const cv=$('#artCanvas');const box=$('#cardBox');const W=box.clientWidth;if(!W||!art.doc)return;curDoc=art.doc;
  const H=W*S.sheet.cardH/S.sheet.cardW,dpr=Math.min(2,window.devicePixelRatio||1)*1.5;
  cv.width=Math.round(W*dpr);cv.height=Math.round(H*dpr);
  const page=await art.doc.getPage(1);const vp=page.getViewport({scale:1});
  const ctx=cv.getContext('2d');const pl=artPlace(art);ctx.fillStyle=(pl.mode==='center'&&S.bg)?cmykRgb(S.bg.cmyk):'#fff';ctx.fillRect(0,0,cv.width,cv.height);
  const token=++drawArt.t;const pxMm=cv.width/S.sheet.cardW,pxPt=pxMm/MM;
  const task=page.render({canvasContext:ctx,viewport:vp,transform:pl.mode==='center'?[pxPt,0,0,pxPt,pl.ox*pxMm,pl.oy*pxMm]:[cv.width/vp.width,0,0,cv.height/vp.height,0,0]});
  try{await task.promise}catch(e){}
}
drawArt.t=0;

/* ---------- chargement données ---------- */
function parseDelimited(text){
  text=text.replace(/^﻿/,'');const first=text.split(/\r?\n/)[0]||'';
  const delim=[';','\t',','].map(d=>[d,first.split(d).length]).sort((a,b)=>b[1]-a[1])[0][0];
  const rows=[];let row=[],cur='',q=false;
  for(let i=0;i<text.length;i++){const c=text[i];
    if(q){if(c==='"'){if(text[i+1]==='"'){cur+='"';i++}else q=false}else cur+=c}
    else if(c==='"')q=true;else if(c===delim){row.push(cur);cur=''}
    else if(c==='\n'||c==='\r'){if(c==='\r'&&text[i+1]==='\n')i++;row.push(cur);rows.push(row);row=[];cur=''}
    else cur+=c}
  if(cur!==''||row.length){row.push(cur);rows.push(row)}return rows}
async function loadData(file){
  let aoa;
  if(/\.(xlsx|xls|xlsm)$/i.test(file.name)){
    const wb=XLSX.read(await file.arrayBuffer(),{type:'array'});
    aoa=XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]],{header:1,raw:false,defval:''})}
  else{const buf=await file.arrayBuffer();let txt;try{txt=new TextDecoder('utf-8',{fatal:true}).decode(buf)}catch(e){txt=new TextDecoder('windows-1252').decode(buf)}aoa=parseDelimited(txt)}
  aoa=aoa.filter(r=>r.some(v=>String(v).trim()!==''));
  if(aoa.length<2){$('#dataNote').className='note bad';$('#dataNote').textContent='Fichier vide ou sans ligne de données.';return}
  const cols=aoa[0].map((h,i)=>String(h).trim()||('Colonne '+(i+1)));
  const rows=aoa.slice(1).map(r=>{const o={};cols.forEach((c,i)=>o[c]=String(r[i]==null?'':r[i]).replace(/\r/g,'').trim());return o});
  S.data={cols,rows,name:file.name,demo:false};S.rowIdx=0;
  if(S.elsAreDemo)autoMapCols();
  refreshData();drawAll();drawArt();reportMissing()}
function reportMissing(){const miss=new Set();S.els.forEach(e=>{if(e.type==='qr'){if(!hasCol(e.col))miss.add(e.col)}else tplMissing(e.tpl).forEach(k=>miss.add(k))});
  if(miss.size){const n=$('#dataNote');n.className='note warn';n.textContent='Colonnes non reconnues : '+[...miss].join(', ')+'. Colonnes du fichier : '+S.data.cols.join(', ')+'. Modifie le contenu des éléments pour les faire correspondre.'}}
function refreshData(){
  const d=S.data;$('#dataInfo').textContent=d.demo?'exemple':`${d.name} · ${d.rows.length} ligne${d.rows.length>1?'s':''}`;
  $('#cols').innerHTML='';d.cols.forEach(c=>{const b=document.createElement('button');b.className='chip';b.textContent=c;b.title='Insérer {'+c+'} dans le texte sélectionné';b.onclick=()=>insertToken(c);$('#cols').appendChild(b)});
  const n=$('#dataNote');n.className='note';n.textContent=d.demo?'Lignes d\'exemple. Remplace-les par ton fichier.':`${d.cols.length} colonnes détectées. Clique sur une colonne pour l'insérer dans le texte sélectionné.`;
  const sel=$('#rowSel');sel.innerHTML='';d.rows.forEach((r,i)=>{const o=document.createElement('option');o.value=i;o.textContent=(i+1)+' · '+(r[d.cols[0]]||'')+' '+(r[d.cols[1]]||'');sel.appendChild(o)});sel.value=S.rowIdx;
  updateInfo()}
function insertToken(c){const e=byId(S.sel);if(!e||e.type!=='text')return;e.tpl+=`{${c}}`;e.name=e.name||'Texte';renderForm();drawAll()}

/* ---------- éléments : liste + formulaire ---------- */
function renderList(){
  refreshVariant();const L=$('#elList');L.innerHTML='';
  S.els.forEach(e=>{const d=document.createElement('div');d.className='item';d.setAttribute('role','option');d.tabIndex=0;d.setAttribute('aria-selected',e.id===S.sel);
    const sw=document.createElement('span');sw.className='sw';sw.style.background=e.type==='qr'?'#222':cmykRgb(e.color);
    const k=document.createElement('span');k.className='k';k.textContent=e.type==='qr'?'QR':'Aa';
    const t=document.createElement('span');t.className='t';t.textContent=e.type==='qr'?`QR · ${e.col||'—'}`:`${e.name||'Texte'} · ${e.tpl}`;
    d.append(k,t,sw);d.onclick=()=>select(e.id);d.onkeydown=ev=>{if(ev.key==='Enter'||ev.key===' '){ev.preventDefault();select(e.id)}};L.appendChild(d)})}
function select(id){S.sel=id;renderList();renderForm();drawOverlay()}
function afterRowChange(){drawArt().then(drawOverlay)}
function field(label,el){const l=document.createElement('label');l.className='f';l.append(label,el);return l}
function inp(val,type,onchange,attrs){const i=document.createElement('input');i.type=type||'text';i.value=val;if(attrs)for(const k in attrs)i.setAttribute(k,attrs[k]);i.oninput=()=>onchange(i.value);return i}
function renderForm(){
  const F=$('#editor');F.innerHTML='';const e=byId(S.sel);if(!e){F.innerHTML='<p class="note" style="margin:0">Sélectionne un élément dans la liste ou sur la carte.</p>';return}
  const upd=(k,conv)=>v=>{e[k]=conv?conv(v):v;S.elsAreDemo=false;if(k==='tpl'||k==='col')renderList();drawAll(true)};
  const n=(k,min,step)=>inp(e[k],'number',upd(k,v=>num(v,e[k])),{step:step||'0.1',min:min==null?'':min});
  if(e.type==='qr'){
    const s=document.createElement('select');const cl=S.data.cols.includes(e.col)?S.data.cols:[e.col,...S.data.cols];cl.forEach(c=>{const o=document.createElement('option');o.value=c;o.textContent=c;s.appendChild(o)});s.value=e.col;s.onchange=()=>upd('col')(s.value);
    F.appendChild(field('Colonne contenant l\'URL du QR',s));
    const ss=document.createElement('select');Object.keys(QS).forEach(k=>{const o=document.createElement('option');o.value=k;o.textContent=QS[k].label;ss.appendChild(o)});ss.value=e.style||'boxtext';ss.onchange=()=>{e.style=ss.value;S.elsAreDemo=false;drawAll(true)};
    F.appendChild(field('Style du QR (charte)',ss));
    const g=document.createElement('div');g.className='grid3';g.append(field('X bloc (mm)',n('x')),field('Y bloc (mm)',n('y')),field('Côté du QR (mm)',n('size',5)));F.appendChild(g);
    const ec=document.createElement('select');['L','M','Q','H'].forEach(v=>{const o=document.createElement('option');o.value=v;o.textContent=v+(v==='M'?' (standard)':'');ec.appendChild(o)});ec.value=e.ecc;ec.onchange=()=>upd('ecc')(ec.value);
    F.appendChild(field('Correction d\'erreur',ec));
  }else{
    F.appendChild(field('Nom de l\'élément',inp(e.name,'text',upd('name'))));
    const ti=inp(e.tpl,'text',v=>{upd('tpl')(v);showPrev()});ti.id='tplIn';
    F.appendChild(field('Contenu (texte libre + {colonnes}, appliqué à toutes les cartes)',ti));
    const pv=document.createElement('p');pv.className='note';pv.style.margin='0';F.appendChild(pv);
    const showPrev=()=>{pv.textContent='Aperçu ligne '+(S.rowIdx+1)+' : '+(applyTpl(e.tpl,curRow(),true).replace(/\n/g,' ⏎ ')||'(vide)')};showPrev();
    const ig=document.createElement('div');ig.className='grid3';ig.style.alignItems='end';
    const cs=document.createElement('select');S.data.cols.forEach(c=>{const o=document.createElement('option');o.value=c;o.textContent=c;cs.appendChild(o)});
    const fs2=document.createElement('select');[['','Tel quel'],['upper','MAJUSCULES'],['lower','minuscules'],['title','Initiales En Majuscule'],['tel','Téléphone +33 6 00 00 00 00'],['telbrut','Téléphone +33600000000']].forEach(([v,l])=>{const o=document.createElement('option');o.value=v;o.textContent=l;fs2.appendChild(o)});
    const ib=document.createElement('button');ib.className='btn sm';ib.textContent='Insérer';ib.onclick=()=>{const tok='{'+cs.value+(fs2.value?'|'+fs2.value:'')+'}';const a=ti.selectionStart??ti.value.length,b=ti.selectionEnd??a;ti.value=ti.value.slice(0,a)+tok+ti.value.slice(b);upd('tpl')(ti.value);showPrev();ti.focus();ti.setSelectionRange(a+tok.length,a+tok.length)};
    ig.append(field('Colonne',cs),field('Format',fs2),ib);F.appendChild(ig);
    const hint=document.createElement('p');hint.className='note';hint.style.margin='0';hint.textContent='Exemples : « +{numero} » ajoute un + devant chaque numéro ; « Tél. {numero|tel} » ; « {Prénom} {Nom|upper} ». Les ajouts s\'appliquent à toutes les cartes.';F.appendChild(hint);
    const miss=tplMissing(e.tpl);if(miss.length){const p=document.createElement('p');p.className='note bad';p.style.margin='0';p.textContent='Colonne introuvable : '+miss.join(', ');F.appendChild(p)}
    const fs=document.createElement('select');S.fonts.forEach(f=>{const o=document.createElement('option');o.value=f.id;o.textContent=f.label;fs.appendChild(o)});fs.value=e.font;fs.onchange=()=>upd('font')(fs.value);
    const g=document.createElement('div');g.className='grid2';g.append(field('Police',fs),field('Corps (pt)',n('size',2,'0.1')));F.appendChild(g);
    const g2=document.createElement('div');g2.className='grid2';g2.append(field('X (mm)',n('x')),field('Y haut du texte (mm)',n('y')));F.appendChild(g2);
    const g3=document.createElement('div');g3.className='grid2';g3.append(field('Interligne (×)',n('lh',0.8,'0.05')),field('Largeur max (mm, 0 = libre)',n('maxW',0,'0.5')));F.appendChild(g3);
    const wl=document.createElement('label');wl.className='f';wl.style.flexDirection='row';wl.style.alignItems='center';wl.style.gap='8px';const wc=document.createElement('input');wc.type='checkbox';wc.style.width='auto';wc.checked=!!e.wrap;wc.onchange=()=>{e.wrap=wc.checked;S.elsAreDemo=false;drawAll(true);drawArt().then(drawOverlay)};wl.append(wc,'Retour à la ligne automatique (selon la largeur max)');F.appendChild(wl);
    const fl=document.createElement('select');fl.innerHTML='<option value="">Position fixe</option>';S.els.filter(x=>x.type==='text'&&x!==e).forEach(x=>{const o=document.createElement('option');o.value=x.id;o.textContent='Descend si « '+(x.name||x.tpl)+' » a plusieurs lignes';fl.appendChild(o)});fl.value=e.flow||'';fl.onchange=()=>{e.flow=fl.value;S.elsAreDemo=false;renderForm();drawAll(true)};
    const g4=document.createElement('div');g4.className='grid2';g4.append(field('Décalage automatique',fl),field('Décalage par ligne (mm, 0 = auto)',n('flowStep',0,'0.1')));F.appendChild(g4);
  }
  const cg=document.createElement('div');cg.className='grid4';
  ['C','M','J','N'].forEach((l,i)=>cg.appendChild(field(l+' %',inp(e.color[i],'number',v=>{e.color[i]=Math.min(100,Math.max(0,num(v,0)));S.elsAreDemo=false;renderList();drawAll(true)},{min:0,max:100,step:1}))));
  F.append(Object.assign(document.createElement('h3'),{textContent:e.type==='qr'?'Couleur du QR (CMJN)':'Couleur CMJN',style:'margin:4px 0 0'}),cg);
  if(e.type==='qr'){e.boxColor=e.boxColor||[0,0,0,0];const bg=document.createElement('div');bg.className='grid4';['C','M','J','N'].forEach((l,i)=>bg.appendChild(field(l+' %',inp(e.boxColor[i],'number',v=>{e.boxColor[i]=Math.min(100,Math.max(0,num(v,0)));drawAll(true)},{min:0,max:100,step:1}))));F.append(Object.assign(document.createElement('h3'),{textContent:'Couleur de la boîte (CMJN)',style:'margin:4px 0 0'}),bg)}}

/* ---------- aperçu : overlay SVG (unités = mm) ---------- */
let drag=null;
function drawOverlay(){
  const svg=$('#ov');const W=S.sheet.cardW,H=S.sheet.cardH;svg.setAttribute('viewBox',`0 0 ${W} ${H}`);svg.innerHTML='';
  const row=curRow();const stageMsgs=[];
  S.els.forEach(e=>{
    const g=document.createElementNS(NS,'g');g.setAttribute('class','el');g.dataset.id=e.id;svg.appendChild(g);
    if(e.type==='qr'){
      const url=applyTpl('{'+e.col+'}',row),G=qrGeom(e),W2=G.w,H2=G.h;
      if(G.st.box){const bx=document.createElementNS(NS,'path');bx.setAttribute('d',roundRectPath(G.st.box.w*G.u,G.st.box.h*G.u,G.st.box.r*G.u));bx.setAttribute('transform',`translate(${e.x} ${e.y})`);bx.setAttribute('fill',cmykRgb(e.boxColor||[0,0,0,0]));g.appendChild(bx)}
      if(url){try{const m=qrMatrix(url,e.ecc);const p=document.createElementNS(NS,'path');p.setAttribute('d',qrPath(m,G.qx,G.qy,e.size));p.setAttribute('fill',cmykRgb(e.color));g.appendChild(p);
        if(G.st.text){const t=document.createElementNS(NS,'path');t.setAttribute('d',G.st.text.d);t.setAttribute('transform',`translate(${G.qx-G.st.text.ox*G.u} ${G.qy-G.st.text.oy*G.u}) scale(${G.u})`);t.setAttribute('fill',cmykRgb(e.color));g.appendChild(t)}
        const hit=document.createElementNS(NS,'rect');hit.setAttribute('x',e.x);hit.setAttribute('y',e.y);hit.setAttribute('width',W2);hit.setAttribute('height',H2);hit.setAttribute('fill','transparent');g.appendChild(hit)}catch(err){stageMsgs.push('QR impossible : '+err.message)}}
      else{const r=document.createElementNS(NS,'rect');r.setAttribute('x',e.x);r.setAttribute('y',e.y);r.setAttribute('width',W2);r.setAttribute('height',H2);r.setAttribute('fill','rgba(179,38,30,.15)');r.setAttribute('stroke','#b3261e');r.setAttribute('stroke-dasharray','1 .6');r.setAttribute('stroke-width','.3');g.appendChild(r);stageMsgs.push('URL manquante pour la ligne affichée.')}
      if(e.id===S.sel){const hd=document.createElementNS(NS,'circle');hd.setAttribute('cx',e.x+W2);hd.setAttribute('cy',e.y+H2);hd.setAttribute('r','1.3');hd.setAttribute('fill','#2F86C4');hd.setAttribute('stroke','#fff');hd.setAttribute('stroke-width','.3');hd.dataset.handle='1';hd.style.cursor='nwse-resize';g.appendChild(hd)}
    }else{
      const lines=textLines(e,row);const f=fontById(e.font);const ey=effY(e,row);
      const size=fitLines(e,lines,(t,s)=>measure(e.font,t,s));const szmm=size/MM;
      lines.forEach((t,i)=>{const tx=document.createElementNS(NS,'text');tx.setAttribute('x',e.x);tx.setAttribute('y',ey+szmm*ASC+i*szmm*e.lh);tx.setAttribute('font-size',szmm);tx.setAttribute('font-family',f.family);tx.setAttribute('font-weight',f.weight);tx.setAttribute('fill',cmykRgb(e.color));tx.textContent=t;g.appendChild(tx)});
      const hh=lines.length?szmm*ASC+(lines.length-1)*szmm*e.lh+szmm*.3:szmm;
      const ww=Math.max(1,...lines.map(t=>measure(e.font,t,size)/MM));
      const hit=document.createElementNS(NS,'rect');hit.setAttribute('x',e.x);hit.setAttribute('y',ey);hit.setAttribute('width',ww);hit.setAttribute('height',hh);hit.setAttribute('fill','transparent');g.insertBefore(hit,g.firstChild);e._box=[e.x,ey,ww,hh];
      if(size<e.size-.01)stageMsgs.push(`« ${e.name} » réduit à ${size.toFixed(1)} pt (largeur max).`)}
    if(e.id===S.sel){const b=e.type==='qr'?(()=>{const G=qrGeom(e);return[e.x,e.y,G.w,G.h]})():(e._box||[e.x,e.y,5,3]);const o=document.createElementNS(NS,'rect');o.setAttribute('x',b[0]-.4);o.setAttribute('y',b[1]-.4);o.setAttribute('width',b[2]+.8);o.setAttribute('height',b[3]+.8);o.setAttribute('fill','none');o.setAttribute('stroke','#2F86C4');o.setAttribute('stroke-width','.3');o.setAttribute('stroke-dasharray','1 .7');o.setAttribute('pointer-events','none');svg.appendChild(o)}
  });
  const sn=$('#stageNote');sn.className=stageMsgs.length?'note warn':'note';sn.textContent=stageMsgs.length?stageMsgs.join(' '):'Aperçu de la ligne sélectionnée. Les couleurs CMJN sont approchées à l\'écran.';
}
function svgPt(ev){const svg=$('#ov');const pt=svg.createSVGPoint();pt.x=ev.clientX;pt.y=ev.clientY;return pt.matrixTransform(svg.getScreenCTM().inverse())}
const snap=v=>Math.round(v*20)/20;
$('#ov').addEventListener('pointerdown',ev=>{
  const g=ev.target.closest('[data-id]');if(!g){select(null);return}
  const e=byId(g.dataset.id);if(S.sel!==e.id){S.sel=e.id;renderList();renderForm()}
  const p=svgPt(ev);const sh=e.type==='text'?effY(e,curRow())-e.y:0;drag={e,shift:sh,dx:p.x-e.x,dy:p.y-e.y-sh,resize:!!ev.target.dataset.handle};try{$('#ov').setPointerCapture(ev.pointerId)}catch(x){}
  drawOverlay();ev.preventDefault()});
$('#ov').addEventListener('pointermove',ev=>{if(!drag)return;const p=svgPt(ev),e=drag.e;
  if(drag.resize){const G=qrGeom(e);const k=Math.max((p.x-e.x)/(G.w/e.size),(p.y-e.y)/(G.h/e.size));e.size=Math.max(8,Math.round(k*20)/20)}else{e.x=snap(p.x-drag.dx);e.y=snap(p.y-drag.dy-(drag.shift||0))}
  S.elsAreDemo=false;drawOverlay();syncPos(e)});
const endDrag=()=>{if(drag){drag=null;renderForm()}};
$('#ov').addEventListener('pointerup',endDrag);$('#ov').addEventListener('pointercancel',endDrag);
function syncPos(e){const ins=[...document.querySelectorAll('#editor input[type=number]')];/* champs X/Y/Côté suivent le glisser */}
document.addEventListener('keydown',ev=>{
  const e=byId(S.sel);if(!e||/INPUT|SELECT|TEXTAREA/.test(document.activeElement.tagName))return;
  const st=ev.shiftKey?1:.1;let h=true;
  if(ev.key==='ArrowLeft')e.x=r2(e.x-st);else if(ev.key==='ArrowRight')e.x=r2(e.x+st);else if(ev.key==='ArrowUp')e.y=r2(e.y-st);else if(ev.key==='ArrowDown')e.y=r2(e.y+st);else h=false;
  if(h){ev.preventDefault();S.elsAreDemo=false;renderForm();drawOverlay()}});

/* ---------- planche : champs + schéma ---------- */
const SHEET_FIELDS=[['pageW','Page larg. (mm)'],['pageH','Page haut. (mm)'],['cols','Colonnes'],['rows','Lignes'],['cardW','Carte larg. (mm)'],['cardH','Carte haut. (mm)'],['gapX','Écart X (mm)'],['gapY','Écart Y (mm)'],['mL','Marge gauche (mm)'],['mT','Marge haut (mm)']];
function buildSheetInputs(){
  const c=$('#sheetInputs');c.innerHTML='';
  SHEET_FIELDS.forEach(([k,l])=>{const i=document.createElement('input');i.type='number';i.id='sh_'+k;i.step=(k==='cols'||k==='rows')?'1':'0.1';i.min=(k==='cols'||k==='rows')?'1':'0';i.value=S.sheet[k];
    i.oninput=()=>{const v=num(i.value,S.sheet[k]);S.sheet[k]=(k==='cols'||k==='rows')?Math.max(1,Math.round(v)):v;sheetInfo();drawSheet();if(k==='cardW'||k==='cardH'){drawArt();drawOverlay()}};
    c.appendChild(field(l,i))})}
function syncSheetInputs(){const fs=document.getElementById('fillSel');if(fs)fs.value=S.sheet.fillEnd?'end':'start';SHEET_FIELDS.forEach(([k])=>{const i=$('#sh_'+k);if(i)i.value=r2(S.sheet[k])})}
const gridW=()=>S.sheet.cols*S.sheet.cardW+(S.sheet.cols-1)*S.sheet.gapX;
const gridH=()=>S.sheet.rows*S.sheet.cardH+(S.sheet.rows-1)*S.sheet.gapY;
function sheetInfo(){try{renderFormats()}catch(e){}
  const s=S.sheet,rm=s.pageW-s.mL-gridW(),bm=s.pageH-s.mT-gridH(),n=$('#sheetNote');
  const bad=rm<-.01||bm<-.01||s.mL<0||s.mT<0;
  n.className='note '+(bad?'bad':'ok');
  n.textContent=`${s.cols*s.rows} cartes par planche · marge droite ${mmFmt(rm)} mm · marge bas ${mmFmt(bm)} mm`+(bad?' · les cartes dépassent de la page':'');
  $('#cardDims').textContent=`${mmFmt(s.cardW)} × ${mmFmt(s.cardH)} mm`;
  updateInfo()}
function updateInfo(){const per=S.sheet.cols*S.sheet.rows,n=S.data.rows.length;$('#genInfo').textContent=`${n} carte${n>1?'s':''} · ${Math.max(1,Math.ceil(n/per))} planche${Math.ceil(n/per)>1?'s':''}`}
function drawSheet(){
  const s=S.sheet,svg=$('#sheetSvg');svg.setAttribute('viewBox',`0 0 ${s.pageW} ${s.pageH}`);svg.style.aspectRatio=`${s.pageW}/${s.pageH}`;svg.innerHTML='';
  const css=getComputedStyle(document.documentElement);const acc=css.getPropertyValue('--accent').trim(),ink=css.getPropertyValue('--ink').trim();
  const pg=document.createElementNS(NS,'rect');pg.setAttribute('width',s.pageW);pg.setAttribute('height',s.pageH);pg.setAttribute('fill','none');svg.appendChild(pg);
  const per0=s.cols*s.rows,n=Math.min(S.data.rows.length,per0),filled=new Set();for(let i=0;i<n;i++)filled.add(slotOf(i,S.data.rows.length,per0));
  for(let r=0;r<s.rows;r++)for(let c=0;c<s.cols;c++){const i=r*s.cols+c;const rc=document.createElementNS(NS,'rect');
    rc.setAttribute('x',s.mL+c*(s.cardW+s.gapX));rc.setAttribute('y',s.mT+r*(s.cardH+s.gapY));rc.setAttribute('width',s.cardW);rc.setAttribute('height',s.cardH);
    rc.setAttribute('fill',filled.has(i)?acc:'none');rc.setAttribute('fill-opacity',filled.has(i)?.85:0);rc.setAttribute('stroke',acc);rc.setAttribute('stroke-width',s.pageW/300);rc.setAttribute('stroke-dasharray',filled.has(i)?'0':`${s.pageW/100} ${s.pageW/200}`);svg.appendChild(rc)}
}
$('#fillSel').onchange=e=>{S.sheet.fillEnd=e.target.value==='end';drawSheet();renderFormats()};
$('#fitSel').onchange=e=>{S.fit=e.target.value;drawArt().then(drawOverlay)};
$('#centerX').onclick=()=>{S.sheet.mL=r2((S.sheet.pageW-gridW())/2);syncSheetInputs();sheetInfo();drawSheet()};
$('#centerY').onclick=()=>{S.sheet.mT=r2((S.sheet.pageH-gridH())/2);syncSheetInputs();sheetInfo();drawSheet()};
$('#useArt').onclick=()=>{if(!S.art.wpt)return;S.sheet.cardW=r2(S.art.wpt/MM);S.sheet.cardH=r2(S.art.hpt/MM);syncSheetInputs();sheetInfo();drawSheet();drawArt();drawOverlay();$('#artNote').className='note ok';$('#artNote').textContent='Taille de carte alignée sur le PDF.'};

/* Nom de police intégré : préfixe de sous-ensemble standard (ABCDEF+) + vrai nom PostScript, pour qu'Illustrator retrouve la police installée */
function subsetName(f){let ps=f.ps;if(!ps){try{ps=fontkit.create(f.bytes.slice(0)).postscriptName}catch(e){}ps=ps||f.label.replace(/\s+/g,'-');f.ps=ps}
  let tag='';for(let i=0;i<6;i++)tag+=String.fromCharCode(65+Math.floor(Math.random()*26));return tag+'+'+String(ps).replace(/[^\x21-\x7e]/g,'').replace(/[()<>\[\]{}\/%#]/g,'')}
/* ---------- enregistrement (application : boîte de dialogue native ; page : capability downloads) ---------- */
async function saveOut(filename,data,filters){
  if(window.api&&window.api.saveFile){const r=await window.api.saveFile(filename,data,filters);if(!r)throw Object.assign(new Error('annulé'),{code:'declined'});return r}
  const dl=window.claude&&window.claude.use?await window.claude.use('downloads'):null;
  if(!dl)throw new Error('Téléchargement indisponible dans cette vue.');
  await dl.save({filename,data});return filename}
/* emplacement de la i-ème carte : planches remplies dans l'ordre ; la dernière planche incomplète peut être calée à la fin (verso) */
function slotOf(i,n,per){const j=i%per,start=i-j,k=Math.min(per,n-start);return S.sheet.fillEnd&&k<per?per-k+j:j}
/* ---------- génération PDF ---------- */
async function generateBytes(log){
  const{PDFDocument,StandardFonts,cmyk}=PDFLib;const s=S.sheet,rows=S.data.rows;
  if(!rows.length)throw new Error('Aucune ligne de données.');
  const missing=[];S.els.filter(e=>e.type==='qr').forEach(e=>rows.forEach((r,i)=>{if(!applyTpl('{'+e.col+'}',r).trim())missing.push(i+2)}));
  if(missing.length)throw new Error(`URL du QR vide aux lignes ${[...new Set(missing)].slice(0,15).join(', ')} du fichier.`);
  if(s.mL+gridW()>s.pageW+.01||s.mT+gridH()>s.pageH+.01)throw new Error('Les cartes dépassent de la page : ajuste l\'étape 4.');
  const out=await PDFDocument.create();out.registerFontkit(fontkit);
  const src=await PDFDocument.load(S.art.bytes.slice(0));const[emb]=await out.embedPages([src.getPage(0)]);
  let emb2=null;if(S.art2){const s2=await PDFDocument.load(S.art2.bytes.slice(0));[emb2]=await out.embedPages([s2.getPage(0)])}
  const fmap={};for(const f of S.fonts){if(!S.els.some(e=>e.type==='text'&&e.font===f.id))continue;
    fmap[f.id]=f.std?await out.embedFont(StandardFonts[f.std]):await out.embedFont(f.bytes.slice(0),{subset:true,customName:subsetName(f)})}
  const PW=s.pageW*MM,PH=s.pageH*MM,per=s.cols*s.rows,warns=[];let page;
  rows.forEach((row,i)=>{
    if(i%per===0)page=out.addPage([PW,PH]);const slot=slotOf(i,rows.length,per);
    const ox=s.mL+(slot%s.cols)*(s.cardW+s.gapX),oy=s.mT+Math.floor(slot/s.cols)*(s.cardH+s.gapY);
    const useA2=S.art2&&emb2&&artFor(row)===S.art2,A=useA2?S.art2:S.art,pl=artPlace(A);
    if(pl.mode==='center'&&S.bg)page.drawRectangle({x:ox*MM,y:PH-(oy+s.cardH)*MM,width:s.cardW*MM,height:s.cardH*MM,color:cmyk(...S.bg.cmyk.map(v=>v/100)),borderWidth:0});
    page.pushOperators(PDFLib.pushGraphicsState(),PDFLib.rectangle(ox*MM,PH-(oy+s.cardH)*MM,s.cardW*MM,s.cardH*MM),PDFLib.clip(),PDFLib.endPath());
    page.drawPage(useA2?emb2:emb,{x:(ox+pl.ox)*MM,y:PH-(oy+pl.oy+pl.dh)*MM,width:pl.dw*MM,height:pl.dh*MM});
    page.pushOperators(PDFLib.popGraphicsState());
    S.els.forEach(e=>{
      const col=cmyk(...e.color.map(v=>v/100));
      if(e.type==='qr'){const m=qrMatrix(applyTpl('{'+e.col+'}',row).trim(),e.ecc);const G=qrGeom(e),sc=e.size*MM/QS_SIDE;
        if(G.st.box)page.drawSvgPath(roundRectPath(G.st.box.w*sc,G.st.box.h*sc,G.st.box.r*sc),{x:(ox+e.x)*MM,y:PH-(oy+e.y)*MM,color:cmyk(...(e.boxColor||[0,0,0,0]).map(v=>v/100)),borderWidth:0});
        page.drawSvgPath(qrPath(m,0,0,e.size*MM),{x:(ox+G.qx)*MM,y:PH-(oy+G.qy)*MM,color:col,borderWidth:0});
        if(G.st.text)page.drawSvgPath(G.st.text.d,{x:(ox+G.qx)*MM-G.st.text.ox*sc,y:PH-(oy+G.qy)*MM+G.st.text.oy*sc,scale:sc,color:col,borderWidth:0});
        if(m.length>45)warns.push(`Ligne ${i+2} : QR dense (${m.length} modules), URL longue.`)}
      else{
        const font=fmap[e.font];const clean=t=>{try{font.encodeText(t);return t}catch(x){const t2=[...t].map(ch=>{try{font.encodeText(ch);return ch}catch(y){return '?'}}).join('');warns.push(`Ligne ${i+2} : caractère non géré par ${fontById(e.font).label} dans « ${t} ».`);return t2}};
        const lines=textLines(e,row).map(clean);if(!lines.length)return;
        const size=fitLines(e,lines,(t,sz)=>font.widthOfTextAtSize(t,sz));
        if(size<e.size-.01)warns.push(`Ligne ${i+2} : « ${e.name} » réduit à ${size.toFixed(1)} pt.`);
        const szmm=size/MM;
        lines.forEach((t,k)=>page.drawText(t,{x:(ox+e.x)*MM,y:PH-(oy+effY(e,row)+szmm*ASC+k*szmm*e.lh)*MM,size,font,color:col}))}
    })});
  out.setTitle('Planche QR');out.setCreator('Planche QR');
  if(log)log(warns);
  return await out.save()}
$('#gen').onclick=async()=>{
  const lg=$('#log'),b=$('#gen');lg.textContent='';b.disabled=true;b.textContent='Génération…';
  try{
    const bytes=await generateBytes(w=>{lg.textContent=w.length?w.slice(0,40).join('\n')+(w.length>40?`\n… +${w.length-40}`:''):''});
    const path=await saveOut('planche.pdf',bytes,[{name:'PDF (ouvrable dans Illustrator)',extensions:['pdf']},{name:'Illustrator (.ai)',extensions:['ai']}]);
    lg.textContent=(lg.textContent?lg.textContent+'\n\n':'')+'Planche enregistrée : '+path+' ('+(bytes.length/1024/1024).toFixed(1)+' Mo).'
  }catch(e){lg.textContent=e&&e.code==='declined'?'Enregistrement annulé.':'Erreur : '+(e&&e.message||e)}
  finally{b.disabled=false;b.textContent='Générer la planche'}};

/* ---------- modèle (.json) ---------- */
function b64(u8){let s='';for(let i=0;i<u8.length;i+=0x8000)s+=String.fromCharCode.apply(null,u8.subarray(i,i+0x8000));return btoa(s)}
$('#saveModel').onclick=async()=>{
  const m={v:1,fit:S.fit,bg:S.bg,art2:S.art2?b64(new Uint8Array(S.art2.bytes)):null,art2Name:S.art2?S.art2.name:'',variantEl:S.variantEl,variantMin:S.variantMin,sheet:S.sheet,els:S.els.map(e=>{const c=Object.assign({},e);delete c._box;if(c.type==='text'){const f=fontById(c.font);if(!f.std){c.fontLabel=f.label;if(f.ps)c.fontPs=f.ps}}return c}),art:S.art.demo?null:b64(new Uint8Array(S.art.bytes)),artName:S.art.name,fonts:S.fonts.filter(f=>!f.std).map(f=>f.label)};
  const lg=$('#log');
  try{await saveOut('modele-planche.json',JSON.stringify(m),[{name:'Modèle de planche',extensions:['json']}]);lg.textContent='Modèle enregistré (carte, positions et réglages de planche). Les polices et les données ne sont pas incluses.'}catch(e){lg.textContent=e&&e.code==='declined'?'Enregistrement annulé.':'Erreur : '+(e&&e.message||e)}};
const fontByLabel=l=>S.fonts.find(f=>!f.std&&norm(f.label)===norm(l));
async function sysFontList(){if(!window.queryLocalFonts)return null;if(!sysFonts)sysFonts=(await window.queryLocalFonts()).sort((a,b)=>(a.fullName||'').localeCompare(b.fullName||''));return sysFonts}
async function loadSys(c){const ex=S.fonts.find(f=>f.ps&&f.ps===c.postscriptName);if(ex)return ex;const blob=await c.blob();const id=await addFont(await blob.arrayBuffer(),c.fullName);const f=S.fonts.find(x=>x.id===id);f.ps=c.postscriptName;return f}
/* police installée : 1) nom PostScript exact (Avenir-Book…) 2) nom complet 3) mots du nom */
async function localFontByLabel(label,ps){
  try{const L=await sysFontList();if(!L)return null;
    const psn=String(ps||label||'').replace(/^[A-Z]{6}\+/,'').replace(/\s+/g,'-').toLowerCase();
    const words=norm(label||ps||'').replace(/-/g,' ').split(' ').filter(Boolean);const hay=f=>norm((f.fullName||'')+' '+(f.family||'')+' '+(f.style||'')+' '+(f.postscriptName||'').replace(/-/g,' '));
    const c=L.find(f=>(f.postscriptName||'').toLowerCase()===psn)||L.find(f=>norm(f.fullName)===norm(label||''))||L.filter(f=>words.length&&words.every(w=>hay(f).includes(w))).sort((a,b)=>a.fullName.length-b.fullName.length)[0];
    return c?await loadSys(c):null}catch(e){return null}}
/* repli : Arial (présente sur tous les PC Windows) plutôt qu'Helvetica, absente de Windows */
async function fallbackFont(bold){try{const L=await sysFontList();if(!L)return null;const c=L.find(f=>f.postscriptName===(bold?'Arial-BoldMT':'ArialMT'));return c?await loadSys(c):null}catch(e){return null}}
async function resolveFonts(els){const missing=new Set(),found=new Set();
  for(const e of els){if(e.type!=='text'||!(e.fontLabel||e.fontPs))continue;
    const f=fontByLabel(e.fontLabel||'')||(e.fontPs&&S.fonts.find(x=>x.ps===e.fontPs))||await localFontByLabel(e.fontLabel,e.fontPs);
    if(f){e.font=f.id;found.add(f.label)}else{missing.add(e.fontLabel||e.fontPs);const fb=await fallbackFont(/black|bold|heavy|semibold/i.test((e.fontLabel||'')+(e.fontPs||''))||e.font==='helv-b');if(fb)e.font=fb.id;else if(!S.fonts.some(x=>x.id===e.font))e.font='helv'}}
  return{missing:[...missing],found:[...found]}}
async function applyModel(m){
  Object.assign(S.sheet,m.sheet);S.els=JSON.parse(JSON.stringify(m.els));S.nextId=1+Math.max(S.nextId,...S.els.map(e=>+String(e.id).replace(/\D/g,'')||0));S.sel=null;S.elsAreDemo=false;
  S.variantEl=m.variantEl||'';S.variantMin=m.variantMin||2;S.art2=null;S.fit=m.fit||'auto';S.bg=m.bg||null;$('#fitSel').value=S.fit;syncSheetInputs();
  if(m.art2)await setArt2(Uint8Array.from(atob(m.art2),c=>c.charCodeAt(0)),m.art2Name||'variante.pdf');
  if(m.art)await setArt(Uint8Array.from(atob(m.art),c=>c.charCodeAt(0)),m.artName||'carte.pdf',false);else await drawArt();
  if(m.bg)S.bg=m.bg;
  const rf=await resolveFonts(S.els),missing=new Set(rf.missing),found=new Set(rf.found);
  S.els.forEach(e=>{if(e.type==='text'&&!S.fonts.some(x=>x.id===e.font))e.font='helv'});
  sheetInfo();drawSheet();renderList();renderForm();drawAll();drawArt();
  return{missing:[...missing],found:[...found]}}
function modelMsg(r){return 'Modèle chargé.'+(r.found.length?' Polices trouvées : '+r.found.join(', ')+'.':'')+(r.missing.length?' Polices introuvables : '+r.missing.join(', ')+' (remplacées par Arial ; ajoute-les avec « Polices installées… »).':'')+' Charge maintenant ton fichier de données.'}
$('#modelIn').onchange=async ev=>{const f=ev.target.files[0];if(!f)return;try{
  const r=await applyModel(JSON.parse(await f.text()));$('#log').textContent=modelMsg(r)}catch(e){$('#log').textContent='Modèle illisible : '+e.message}ev.target.value=''};
if(window.PRESETS){const ps=$('#presetSel');ps.hidden=false;Object.keys(window.PRESETS).forEach(k=>{const o=document.createElement('option');o.value=k;o.textContent=window.PRESETS[k].label;ps.appendChild(o)});
  ps.onchange=async()=>{if(!ps.value)return;$('#log').textContent='Chargement du modèle…';try{const r=await applyModel(window.PRESETS[ps.value]);$('#log').textContent=modelMsg(r)}catch(e){$('#log').textContent='Erreur : '+e.message}ps.value=''}}

/* ---------- fichiers ---------- */
async function onArt(f){try{const b=new Uint8Array(await f.arrayBuffer());await setArt(b,f.name,false)}catch(e){$('#artNote').className='note bad';$('#artNote').textContent='PDF illisible : '+e.message}}
$('#artIn').onchange=ev=>{if(ev.target.files[0])onArt(ev.target.files[0]);ev.target.value=''};
$('#dataIn').onchange=ev=>{if(ev.target.files[0])loadData(ev.target.files[0]).catch(e=>{$('#dataNote').className='note bad';$('#dataNote').textContent='Fichier illisible : '+e.message});ev.target.value=''};
async function addFont(buf,label){
  const id='f'+(S.nextId++);const fam='uf'+id;const ff=new FontFace(fam,buf.slice(0));await ff.load();document.fonts.add(ff);
  const bytes=new Uint8Array(buf);try{await PDFLib.PDFDocument.create().then(d=>{d.registerFontkit(fontkit);return d.embedFont(bytes,{subset:true})})}catch(e){throw new Error('format de police non géré ('+(e.message||e)+')')}
  let ps='';try{ps=fontkit.create(bytes.slice(0)).postscriptName||''}catch(e){}
  S.fonts.push({id,label,family:`"${fam}", sans-serif`,weight:400,bytes,ps});return id}
$('#fontIn').onchange=async ev=>{for(const f of ev.target.files){try{await addFont(await f.arrayBuffer(),f.name.replace(/\.(ttf|otf)$/i,''))}catch(e){$('#log').textContent='Police illisible : '+e.message}}
  ev.target.value='';renderForm();drawAll()};
let sysFonts=null;
$('#sysFonts').onclick=async()=>{
  const box=$('#sysBox');box.hidden=!box.hidden;if(box.hidden)return;
  if(!window.queryLocalFonts){$('#sysList').textContent='Accès aux polices installées indisponible ici. Utilise « + Police ».';return}
  try{if(!sysFonts)sysFonts=(await window.queryLocalFonts()).sort((a,b)=>(a.fullName||'').localeCompare(b.fullName||''));renderSys()}catch(e){$('#sysList').textContent='Accès refusé : '+e.message}};
$('#sysFilter').oninput=()=>renderSys();
function renderSys(){const q=norm($('#sysFilter').value);const L=$('#sysList');L.innerHTML='';
  (sysFonts||[]).filter(f=>!q||norm(f.fullName+' '+f.family).includes(q)).slice(0,60).forEach(f=>{const b=document.createElement('button');b.className='chip';b.style.textAlign='left';b.textContent=f.fullName;b.onclick=async()=>{
    try{const blob=await f.blob();const id=await addFont(await blob.arrayBuffer(),f.fullName);const e=byId(S.sel);if(e&&e.type==='text'){e.font=id;S.elsAreDemo=false}renderForm();drawAll();$('#log').textContent='Police ajoutée : '+f.fullName+(e&&e.type==='text'?' (appliquée à « '+(e.name||'texte')+' »)':'')}catch(x){$('#log').textContent='Police inutilisable : '+x.message}};L.appendChild(b)});
  if(!L.children.length)L.textContent='Aucune police trouvée.'}
['artDrop','dataDrop'].forEach(id=>{const z=$('#'+id);
  z.addEventListener('dragover',e=>{e.preventDefault();z.classList.add('on')});z.addEventListener('dragleave',()=>z.classList.remove('on'));
  z.addEventListener('drop',e=>{e.preventDefault();z.classList.remove('on');const f=e.dataTransfer.files[0];if(!f)return;id==='artDrop'?onArt(f):loadData(f).catch(x=>{$('#dataNote').className='note bad';$('#dataNote').textContent='Fichier illisible : '+x.message})})});
document.querySelectorAll('label.btn[tabindex]').forEach(l=>l.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();l.click()}}));
$('#rowSel').onchange=e=>{S.rowIdx=+e.target.value;drawAll();drawArt()};
$('#art2In').onchange=async ev=>{const f=ev.target.files[0];if(f){try{await setArt2(new Uint8Array(await f.arrayBuffer()),f.name)}catch(e){$('#artNote').className='note bad';$('#artNote').textContent='PDF illisible : '+e.message}}ev.target.value=''};
$('#art2Del').onclick=()=>{S.art2=null;refreshVariant();drawArt().then(drawOverlay)};
$('#varEl').onchange=e=>{S.variantEl=e.target.value;drawArt().then(drawOverlay)};
$('#varMin').oninput=e=>{S.variantMin=Math.max(2,Math.round(num(e.target.value,2)));drawArt().then(drawOverlay)};
$('#addText').onclick=()=>{const e={id:'e'+(S.nextId++),type:'text',name:'Texte',tpl:'{'+(S.data.cols[0]||'Colonne')+'}',font:'helv',size:6,x:7.3,y:40,color:[0,0,0,0],lh:1.2,maxW:42};S.els.push(e);S.elsAreDemo=false;select(e.id);drawAll()};
$('#delEl').onclick=()=>{const e=byId(S.sel);if(!e)return;S.els=S.els.filter(x=>x!==e);S.sel=null;S.elsAreDemo=false;renderList();renderForm();drawAll()};

function drawAll(skipList){drawOverlay();drawSheet();if(!skipList)renderList()}
new ResizeObserver(()=>{sizeBox();drawArt().then(drawOverlay)}).observe($('#stageWrap'));
function sizeBox(){const wrap=$('#stageWrap'),box=$('#cardBox');const W=Math.min(wrap.clientWidth-32,760);box.style.width=Math.max(200,W)+'px';box.style.aspectRatio=`${S.sheet.cardW}/${S.sheet.cardH}`}
new MutationObserver(()=>drawSheet()).observe(document.documentElement,{attributes:true,attributeFilter:['data-theme']});
if(window.matchMedia)window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change',drawSheet);

/* ---------- Analyse d'une carte PDF : détecte fond, QR (vectoriel ou image), textes, et crée le modèle ---------- */
const latin1=u8=>{let o='';for(let i=0;i<u8.length;i+=0x4000)o+=String.fromCharCode.apply(null,u8.subarray(i,i+0x4000));return o};
function csTokenize(src){const toks=[],n=src.length;let i=0;
  const WS=c=>c===32||c===10||c===13||c===9||c===12||c===0,DL=c=>'()<>[]{}/%'.indexOf(String.fromCharCode(c))>=0;
  while(i<n){const c=src.charCodeAt(i);
    if(WS(c)){i++;continue}
    if(c===37){while(i<n&&src.charCodeAt(i)!==10&&src.charCodeAt(i)!==13)i++;continue}
    const st=i;
    if(c===47){i++;while(i<n&&!WS(src.charCodeAt(i))&&!DL(src.charCodeAt(i)))i++;toks.push({t:'name',v:src.slice(st+1,i),s:st,e:i});continue}
    if(c===40){let d=1;i++;while(i<n&&d>0){const ch=src[i];if(ch==='\\')i+=2;else{if(ch==='(')d++;else if(ch===')')d--;i++}}toks.push({t:'str',s:st,e:i});continue}
    if(c===60){if(src[i+1]==='<'){i+=2;toks.push({t:'dopen',s:st,e:i});continue}i++;while(i<n&&src[i]!=='>')i++;i++;toks.push({t:'str',s:st,e:i});continue}
    if(c===62){if(src[i+1]==='>'){i+=2;toks.push({t:'dclose',s:st,e:i});continue}i++;continue}
    if(c===91){i++;toks.push({t:'aopen',s:st,e:i});continue}
    if(c===93){i++;toks.push({t:'aclose',s:st,e:i});continue}
    if(c===123||c===125){i++;continue}
    while(i<n&&!WS(src.charCodeAt(i))&&!DL(src.charCodeAt(i)))i++;
    if(i===st){i++;continue}
    const w=src.slice(st,i);
    if(w==='BI'){const re=/\sEI(?=\s|$)/g;re.lastIndex=i;const r=re.exec(src);i=r?r.index+r[0].length:n;toks.push({t:'op',v:'BI',s:st,e:i});continue}
    toks.push(/^[+-]?(\d+\.?\d*|\.\d+)$/.test(w)?{t:'num',v:parseFloat(w),s:st,e:i}:{t:'op',v:w,s:st,e:i})}
  return toks}
function csParse(src){const toks=csTokenize(src),ops=[];let args=[],start=-1;
  for(let i=0;i<toks.length;i++){const t=toks[i];
    if(t.t==='op'){ops.push({op:t.v,args,s:start<0?t.s:start,e:t.e});args=[];start=-1;continue}
    if(start<0)start=t.s;
    if(t.t==='aopen'){const arr=[];i++;while(i<toks.length&&toks[i].t!=='aclose'){arr.push(toks[i]);i++}args.push({t:'arr',v:arr});continue}
    if(t.t==='dopen'){let d=1;i++;while(i<toks.length&&d>0){if(toks[i].t==='dopen')d++;else if(toks[i].t==='dclose')d--;i++}i--;args.push({t:'dict'});continue}
    args.push(t)}
  return ops}
const mmul=(a,b)=>[a[0]*b[0]+a[1]*b[2],a[0]*b[1]+a[1]*b[3],a[2]*b[0]+a[3]*b[2],a[2]*b[1]+a[3]*b[3],a[4]*b[0]+a[5]*b[2]+b[4],a[4]*b[1]+a[5]*b[3]+b[5]];
const mapp=(m,x,y)=>[m[0]*x+m[2]*y+m[4],m[1]*x+m[3]*y+m[5]];
function toCmyk(c){if(!c)return[0,0,0,100];if(c.k)return c.k.map(v=>Math.round(v*1000)/10);if(c.g!=null)return[0,0,0,Math.round((1-c.g)*1000)/10];if(c.rgb)return[...c.rgb.map(v=>Math.round((1-v)*1000)/10),0];return[0,0,0,100]}
const isWhite=c=>{if(!c)return false;if(c.k)return c.k.every(v=>v<.03);if(c.g!=null)return c.g>.97;if(c.rgb)return c.rgb.every(v=>v>.97);return false};
function csInterpret(ops,sid=0,out=null,init=null,onDo=null){
  let ctm=init?init.ctm.slice():[1,0,0,1,0,0];const stack=[];let fill=init?init.fill:null,tm=[1,0,0,1,0,0],tlm=[1,0,0,1,0,0],font='',fsize=1,lead=0;
  out=out||{shows:[],paths:[],dos:[],shs:[]};const{shows,paths,dos,shs}=out;let path=null;
  const nums=o=>o.args.filter(a=>a.t==='num').map(a=>a.v);
  const newPath=()=>({sid,idx:[],x0:1e9,y0:1e9,x1:-1e9,y1:-1e9,reOnly:true,nsub:0,clip:false,rects:[]});
  const pt=(p,x,y)=>{const q=mapp(ctm,x,y);p.x0=Math.min(p.x0,q[0]);p.x1=Math.max(p.x1,q[0]);p.y0=Math.min(p.y0,q[1]);p.y1=Math.max(p.y1,q[1])};
  const show=(i)=>{const m=mmul(tm,ctm);shows.push({sid,i,x:m[4],y:m[5],size:fsize*Math.hypot(m[2],m[3]),font,color:fill})};
  ops.forEach((o,i)=>{const a=nums(o);
    switch(o.op){
      case 'q':stack.push({ctm,fill});break;
      case 'Q':{const t=stack.pop();if(t){ctm=t.ctm;fill=t.fill}break}
      case 'cm':if(a.length===6)ctm=mmul(a,ctm);break;
      case 'k':fill={k:a.slice(0,4)};break;
      case 'g':fill={g:a[0]};break;
      case 'rg':fill={rgb:a.slice(0,3)};break;
      case 'sc':case 'scn':if(a.length===4)fill={k:a};else if(a.length===3)fill={rgb:a};else if(a.length===1)fill={g:a[0]};break;
      case 'BT':tm=[1,0,0,1,0,0];tlm=[1,0,0,1,0,0];break;
      case 'Tm':if(a.length===6){tm=a.slice();tlm=a.slice()}break;
      case 'Td':tlm=mmul([1,0,0,1,a[0],a[1]],tlm);tm=tlm.slice();break;
      case 'TD':lead=-a[1];tlm=mmul([1,0,0,1,a[0],a[1]],tlm);tm=tlm.slice();break;
      case 'TL':lead=a[0];break;
      case 'T*':tlm=mmul([1,0,0,1,0,-lead],tlm);tm=tlm.slice();break;
      case 'Tf':{const nm=o.args.find(x=>x.t==='name');font=nm?nm.v:'';fsize=a[0]||1;break}
      case 'Tj':case 'TJ':show(i);break;
      case "'":tlm=mmul([1,0,0,1,0,-lead],tlm);tm=tlm.slice();show(i);break;
      case '"':tlm=mmul([1,0,0,1,0,-lead],tlm);tm=tlm.slice();show(i);break;
      case 'm':case 'l':if(!path)path=newPath();path.idx.push(i);if(o.op==='m'){path.nsub++}path.reOnly=false;pt(path,a[0],a[1]);break;
      case 'c':if(!path)path=newPath();path.idx.push(i);path.reOnly=false;pt(path,a[0],a[1]);pt(path,a[2],a[3]);pt(path,a[4],a[5]);break;
      case 'v':case 'y':if(!path)path=newPath();path.idx.push(i);path.reOnly=false;pt(path,a[0],a[1]);pt(path,a[2],a[3]);break;
      case 'h':if(path){path.idx.push(i)}break;
      case 're':{if(!path)path=newPath();path.idx.push(i);path.nsub++;const[x,y,w,h]=a;const c=[mapp(ctm,x,y),mapp(ctm,x+w,y),mapp(ctm,x+w,y+h),mapp(ctm,x,y+h)];
        const xs=c.map(p=>p[0]),ys=c.map(p=>p[1]);const r={x0:Math.min(...xs),x1:Math.max(...xs),y0:Math.min(...ys),y1:Math.max(...ys)};path.rects.push(r);
        path.x0=Math.min(path.x0,r.x0);path.x1=Math.max(path.x1,r.x1);path.y0=Math.min(path.y0,r.y0);path.y1=Math.max(path.y1,r.y1);break}
      case 'W':case 'W*':if(path)path.clip=true;break;
      case 'f':case 'F':case 'f*':case 'B':case 'B*':case 'b':case 'b*':case 'S':case 's':case 'n':
        if(path){path.idx.push(i);path.paint=o.op;path.fill=(['f','F','f*','B','B*','b','b*'].includes(o.op))?fill:null;path.w=path.x1-path.x0;path.h=path.y1-path.y0;paths.push(path);path=null}break;
      case 'sh':shs.push({sid,i});break;
      case 'Do':{const nm=o.args.find(x=>x.t==='name');const isForm=onDo?onDo(nm?nm.v:'',ctm.slice(),fill):false;if(!isForm)dos.push({sid,i,name:nm?nm.v:'',ctm:ctm.slice()});break}
    }});
  return out}
const decodeSt=st=>st instanceof PDFLib.PDFRawStream?PDFLib.decodePDFRawStream(st).decode():st.getContents();
async function cardContent(bytes){
  const{PDFDocument,PDFArray,PDFName,PDFDict}=PDFLib;const doc=await PDFDocument.load(bytes.slice(0));const page=doc.getPage(0);const c=page.node.Contents();
  const parts=[];const add=o=>parts.push(decodeSt(doc.context.lookup(o)));
  if(c instanceof PDFArray){for(let i=0;i<c.size();i++)add(c.get(i))}else if(c)add(c);
  const src=parts.map(latin1).join('\n');const ops=csParse(src);
  const streams=[{sid:0,src,ops}],out={shows:[],paths:[],dos:[],shs:[]};
  const xobj=res=>{try{const d=res&&res.lookup(PDFName.of('XObject'));return d instanceof PDFDict?d:null}catch(e){return null}};
  const run=(ops,sid,res,init,depth)=>csInterpret(ops,sid,out,init,(name,ctm,fill)=>{
    if(depth>8)return false;const X=xobj(res);if(!X)return false;const ref=X.get(PDFName.of(name));if(!ref)return false;const st=doc.context.lookup(ref);
    if(!st||!st.dict||st.dict.get(PDFName.of('Subtype'))!==PDFName.of('Form'))return false;
    let m=[1,0,0,1,0,0];try{const a=st.dict.lookup(PDFName.of('Matrix'));if(a)m=a.asArray().map(n=>n.asNumber())}catch(e){}
    let fsrc;try{fsrc=latin1(decodeSt(st))}catch(e){return false}
    const sid2=streams.length;const fops=csParse(fsrc);streams.push({sid:sid2,src:fsrc,ops:fops,ref,st});
    let fres=null;try{fres=st.dict.lookup(PDFName.of('Resources'))}catch(e){}
    run(fops,sid2,fres||res,{ctm:mmul(m,ctm),fill},depth+1);return true});
  run(ops,0,page.node.Resources(),null,0);
  return{doc,page,src,ops,streams,...out,mb:page.getMediaBox()}}
async function detectBg(){ // fond uni = 1er aplat couvrant toute la page (couleur CMJN exacte)
  try{const cc=await cardContent(S.art.bytes);const{x,y,width:w,height:h}=cc.mb;
    const bg=cc.paths.find(p=>p.fill&&p.paint!=='n'&&!p.clip&&p.w>=w*.985&&p.h>=h*.985);
    S.bg=bg&&!isWhite(bg.fill)?{cmyk:toCmyk(bg.fill)}:null;
    const imgBg=cc.dos.some(d=>Math.hypot(d.ctm[0],d.ctm[1])>=w*.9&&Math.hypot(d.ctm[2],d.ctm[3])>=h*.9);
    S.bgKind=S.bg?'solid':(imgBg||cc.shs.length?'complex':'none')}catch(e){S.bg=null;S.bgKind='none'}}
function qrFromContent(cc){
  const{dos,mb}=cc;const inPage=p=>p.x0>=mb.x-1&&p.x1<=mb.x+mb.width+1&&p.y0>=mb.y-1&&p.y1<=mb.y+mb.height+1;const paths=cc.paths.filter(inPage);let cand=paths.filter(p=>p.fill&&!p.clip&&p.reOnly&&p.rects.length&&Math.min(p.w,p.h)>=.4&&Math.min(p.w,p.h)<=5&&Math.max(p.w,p.h)<=90);
  const bins=new Map();cand.forEach(p=>{const k=Math.round(Math.min(p.w,p.h)/p.rects.length>0.4?Math.min(...p.rects.map(r=>Math.min(r.x1-r.x0,r.y1-r.y0)))*20:0);if(!bins.has(k))bins.set(k,[]);bins.get(k).push(p)});
  let best=[];bins.forEach(v=>{if(v.length>best.length)best=v});
  let q=null;
  if(best.length>=60){q={paths:best,x0:Math.min(...best.map(p=>p.x0)),y0:Math.min(...best.map(p=>p.y0)),x1:Math.max(...best.map(p=>p.x1)),y1:Math.max(...best.map(p=>p.y1)),color:best[0].fill,kind:'vector'}}
  else{const big=paths.filter(p=>p.fill&&!p.clip&&p.reOnly&&p.nsub>=100&&p.w>30&&p.w<150&&Math.abs(p.w-p.h)<p.w*.15);
    if(big.length)q={paths:[big[0]],x0:big[0].x0,y0:big[0].y0,x1:big[0].x1,y1:big[0].y1,color:big[0].fill,kind:'vector'}}
  if(q){const w=q.x1-q.x0,h=q.y1-q.y0;if(w<25||w>150||Math.abs(w-h)>Math.max(w,h)*.2)q=null}
  if(!q){ // QR en image (carré)
    const im=dos.map(d=>({d,w:Math.hypot(d.ctm[0],d.ctm[1]),h:Math.hypot(d.ctm[2],d.ctm[3])})).find(o=>o.w>35&&o.w<150&&Math.abs(o.w-o.h)<o.w*.08);
    if(im){const c=im.d.ctm;q={paths:[],dos:[im.d],x0:c[4],y0:c[5],x1:c[4]+im.w,y1:c[5]+im.h,color:{k:[0,0,0,1]},kind:'image'}}}
  if(!q)return null;
  const qw=q.x1-q.x0,inBox=p=>p.x0<=q.x0-2&&p.x1>=q.x1+2&&p.y0<=q.y0-2&&p.y1>=q.y1+2&&p.w<qw*1.6&&p.h<qw*1.9;
  const box=paths.filter(p=>p.fill&&isWhite(p.fill)&&!p.clip&&inBox(p)).sort((a,b)=>a.w*a.h-b.w*b.h)[0]||null;
  const lim={x0:(box?box.x0:q.x0)-2,x1:(box?box.x1:q.x1)+2,y0:(box?box.y0:q.y0-16),y1:q.y0+1};
  const letters=paths.filter(p=>p.fill&&!isWhite(p.fill)&&!p.clip&&p!==box&&!q.paths.includes(p)&&p.y1<=lim.y1&&p.y0>=lim.y0&&p.x0>=lim.x0&&p.x1<=lim.x1&&p.h<10&&p.w<qw*1.1);
  const style=box&&letters.length?'boxtext':box?'box':letters.length?'text':'plain';
  const info=qrGridInfo(q);
  return{...q,box,letters,style,w:qw,h:q.y1-q.y0,...info}}
/* Lit la grille de modules du QR vectoriel : version, niveau de correction d'erreur (L/M/Q/H) et masque, depuis les bits de format */
function qrGridInfo(q){
  if(q.kind!=='vector'||!q.paths.length)return{};
  const rects=q.paths.flatMap(p=>p.rects);if(!rects.length)return{};
  const dims=rects.map(r=>Math.min(r.x1-r.x0,r.y1-r.y0)).sort((a,b)=>a-b),m=dims[Math.floor(dims.length/2)];
  const w=q.x1-q.x0,n=Math.round(w/m);if(n<21||n>177||(n-17)%4)return{n,version:(n-17)/4,ecc:null};
  const pitch=w/n,M=Array.from({length:n},()=>new Array(n).fill(false));
  rects.forEach(r=>{const c0=Math.round((r.x0-q.x0)/pitch),c1=Math.round((r.x1-q.x0)/pitch),r0=Math.round((q.y1-r.y1)/pitch),r1=Math.round((q.y1-r.y0)/pitch);
    for(let i=r0;i<r1;i++)for(let j=c0;j<c1;j++)if(i>=0&&j>=0&&i<n&&j<n)M[i][j]=true});
  const bit=(r,c)=>M[r][c]?1:0;let bits=0;
  [[8,0],[8,1],[8,2],[8,3],[8,4],[8,5],[8,7],[8,8],[7,8],[5,8],[4,8],[3,8],[2,8],[1,8],[0,8]].forEach(([r,c])=>{bits=(bits<<1)|bit(r,c)});
  let best=null;for(let d=0;d<32;d++){let rem=d<<10;for(let i=14;i>=10;i--)if(rem&(1<<i))rem^=0x537<<(i-10);const code=((d<<10)|rem)^0x5412;
    let x=code^bits,dist=0;while(x){dist+=x&1;x>>=1}if(!best||dist<best.dist)best={d,dist}}
  const ecc=best&&best.dist<=3?['M','L','H','Q'][best.d>>3]:null;
  return{n,version:(n-17)/4,ecc,mask:best&&best.dist<=3?best.d&7:null}}
const BOLD=/black|bold|heavy|semibold|extrabold/i;
async function textLinesOf(bytes,cc){
  const pd=await pdfjsLib.getDocument({data:bytes.slice(0)}).promise,pg=await pd.getPage(1);
  try{await pg.getOperatorList()}catch(e){}
  const tc=await pg.getTextContent({disableCombineTextItems:true});
  const items=tc.items.filter(it=>it.str!==undefined&&it.str.length).map(it=>({str:it.str,x:it.transform[4],y:it.transform[5],size:Math.hypot(it.transform[2],it.transform[3]),w:it.width,fontName:it.fontName}));
  const fname=id=>{try{const o=pg.commonObjs.get(id);return String(o&&o.name||'').replace(/^[A-Z]{6}\+/,'')}catch(e){return''}};
  items.sort((a,b)=>Math.abs(a.y-b.y)>.6?b.y-a.y:a.x-b.x);
  const lines=[];
  for(const it of items){const L=lines[lines.length-1];
    if(L&&Math.abs(L.y-it.y)<.6&&it.x-L.x1<it.size*2.5&&it.x>=L.x0-.5){const gap=it.x-L.x1;L.text+=(gap>it.size*.28&&!/\s$/.test(L.text)&&!/^\s/.test(it.str)?' ':'')+it.str;L.x1=Math.max(L.x1,it.x+it.w)}
    else lines.push({text:it.str,x0:it.x,x1:it.x+it.w,y:it.y,size:it.size,font:fname(it.fontName)})}
  lines.forEach((l,i)=>{l.id=i;l.text=l.text.replace(/\s+/g,' ').trim();
    const sh=cc.shows.find(s=>Math.abs(s.y-l.y)<1&&s.x>=l.x0-1.5&&s.x<=l.x1+1);l.color=sh?sh.color:null;l.showIdx=cc.shows.filter(s=>Math.abs(s.y-l.y)<1&&s.x>=l.x0-1.5&&s.x<=l.x1+1).map(s=>[s.sid,s.i])});
  const mb=cc.mb;return lines.filter(l=>l.text&&l.x1>=mb.x&&l.x0<=mb.x+mb.width&&l.y>=mb.y&&l.y<=mb.y+mb.height)}
const PHONE=/^[+(]?[\d\s().-]{8,}$/;
const PH=/<<\s*([^<>]+?)\s*>>/g,PHQR=['url','lien','qr','qrcode','qrcodes','qr code','qr codes','code qr','lien qr','url qr'];
const compact=t=>t.replace(/\s+/g,'').toLowerCase();
function guessRoles(lines){
  if(lines.some(l=>/<<[^<>]+>>/.test(l.text))){ // fichier de fusion (InDesign) : chaque <<champ>> = colonne du CSV
    lines.forEach(l=>{const f=[...l.text.matchAll(PH)].map(m=>m[1]);
      if(!f.length)l.role=compact(l.text)==='vkard.io'?'qrlabel':'fixe';
      else if(f.length===1&&PHQR.includes(norm(f[0]))&&l.text.replace(PH,'').trim()==='')l.role='qr';
      else l.role='champ';l.fields=f});
    return}
  const cand=lines.filter(l=>!l.text.includes('@')&&!PHONE.test(l.text));
  lines.forEach(l=>{l.role='fixe'});
  const cand2=cand.filter(l=>compact(l.text)!=='vkard.io');cand.length=0;cand.push(...cand2);
  lines.forEach(l=>{if(compact(l.text)==='vkard.io')l.role='qrlabel'});
  lines.forEach(l=>{if(l.role==='qrlabel')return;if(l.text.includes('@'))l.role='email';else if(PHONE.test(l.text)&&(l.text.match(/\d/g)||[]).length>=8)l.role='tel'});
  const byPh=cand.find(l=>/pr[ée]nom/i.test(l.text));
  const bold=cand.filter(l=>BOLD.test(l.font)).sort((a,b)=>b.y-a.y);
  const name=byPh||bold[0]||cand.slice().sort((a,b)=>b.size-a.size||b.y-a.y)[0];
  if(name){name.role='nom_complet';
    // prénom et nom sur deux lignes (ex. « Sulyvan » puis « ALVES ») : ligne voisine au même alignement
    const isUp=t=>t===t.toUpperCase()&&/[A-ZÀ-Ý]/.test(t),near=l=>l!==name&&l.role==='fixe'&&Math.abs(l.x0-name.x0)<2&&Math.abs(l.y-name.y)<Math.max(l.size,name.size)*1.8&&l.text.split(' ').length<=3;
    const other=cand.find(l=>near(l)&&isUp(name.text)!==isUp(l.text));
    if(other&&!/pr[ée]nom/i.test(name.text)){const[pre,nom]=isUp(name.text)?[other,name]:[name,other];pre.role='prenom';nom.role='nom'}
    let prev=cand.filter(l=>l.role==='prenom'||l.role==='nom').sort((a,b)=>a.y-b.y)[0]||name;for(const l of cand.filter(l=>l.y<prev.y).sort((a,b)=>b.y-a.y)){
      if(l===prev||l.role!=='fixe')continue;if(Math.abs(l.x0-name.x0)>4||prev.y-l.y>prev.size*2.2||l.size>name.size)break;
      if(BOLD.test(l.font)&&!/^poste$/i.test(l.text)&&l.font!==name.font&&l.size>=name.size*.8)break;
      l.role='poste';prev=l}}
}
const ROLES=[['champ','Champ <<…>> du CSV'],['qr','Emplacement du QR'],['qrlabel','Texte VKARD.IO du QR (retiré)'],['nom_complet','Prénom NOM'],['prenom','Prénom'],['nom','Nom'],['poste','Poste'],['email','E-mail'],['tel','Téléphone'],['fixe','Texte fixe (conservé)']];
/* Emplacement du QR d'après le repère <<QRCodes>> : le plus petit aplat qui contient le repère = cadre du QR (boîte charte) */
function qrFromPlaceholder(cc,lines){
  const L=lines.find(l=>l.role==='qr');if(!L)return null;const{x,y,width:W,height:H}=cc.mb;
  const tx0=L.x0,tx1=L.x1,ty0=L.y-L.size*.2,ty1=L.y+L.size*.8;
  const frame=cc.paths.filter(p=>p.fill&&!p.clip&&p.x0<=tx0+1&&p.x1>=tx1-1&&p.y0<=ty0+1&&p.y1>=ty1-1&&p.w<W*.9&&p.h<H*.95).sort((a,b)=>a.w*a.h-b.w*b.h)[0];
  let fx0,fy0,fx1,fy1;if(frame){fx0=frame.x0;fy0=frame.y0;fx1=frame.x1;fy1=frame.y1}else{const w=Math.max(tx1-tx0,40);fx0=(tx0+tx1)/2-w/2;fx1=fx0+w;fy1=ty1+w*.15;fy0=fy1-w}
  const fw=fx1-fx0,fh=fy1-fy0,lab=lines.find(l=>l.role==='qrlabel'&&l.x0>=fx0-3&&l.x1<=fx1+3&&l.y<=fy1+2&&l.y>=fy0-20);
  let style,qx0,qy1,qs;
  if(fh/fw>1.05){style='boxtext';const u=fw/73.7;qs=QS_SIDE*u;qx0=fx0+5.67*u;qy1=fy1-5.63*u}
  else if(lab&&lab.y<fy0){style='text';qs=fw;qx0=fx0;qy1=fy1}
  else{style='box';const u=fw/73.7;qs=QS_SIDE*u;qx0=fx0+5.67*u;qy1=fy1-5.67*u}
  return{kind:'placeholder',paths:frame?[frame]:[],letters:[],box:null,style,x0:qx0,x1:qx0+qs,y1:qy1,y0:qy1-qs,w:qs,h:qs,color:{k:[0,0,0,1]},col:L.fields&&L.fields[0]||'url',frame:{x0:fx0,y0:fy0,x1:fx1,y1:fy1}}}
let ana=null;
async function analyzeFile(file){
  const box=$('#anaBox');box.hidden=false;box.innerHTML='<p class="note">Analyse en cours…</p>';
  try{const bytes=new Uint8Array(await file.arrayBuffer());const cc=await cardContent(bytes);
    if(cc.page.getRotation().angle)throw new Error('page pivotée non gérée');
    let qr=qrFromContent(cc);const lines=await textLinesOf(bytes,cc);guessRoles(lines);
    if(lines.some(l=>l.role==='qr')){const ph=qrFromPlaceholder(cc,lines);if(ph&&(!qr||qr.kind!=='vector'))qr=ph;else if(ph&&qr)qr.col=ph.col}
    const bgp=cc.paths.find(p=>p.fill&&!p.clip&&p.w>=cc.mb.width*.985&&p.h>=cc.mb.height*.985);
    ana={bytes,cc,qr,lines,name:file.name,bg:bgp&&!isWhite(bgp.fill)?{cmyk:toCmyk(bgp.fill)}:null,style:qr?qr.style:'boxtext'};
    renderAna(false);await createFromAna()}catch(e){box.innerHTML='<p class="note bad">Analyse impossible : '+(e&&e.message||e)+'</p>'}}
const STYLE_TXT={boxtext:'boîte blanche + texte VKARD.IO',box:'boîte blanche',text:'QR + texte VKARD.IO (sans boîte)',plain:'QR seul'};
function renderAna(done){
  const box=$('#anaBox'),A=ana;box.innerHTML='';
  const h=document.createElement('h3');h.textContent=(done?'Modèle créé depuis : ':'Détection : ')+A.name;box.appendChild(h);
  // aperçu de la carte avec les éléments repérés
  const mb=A.cc.mb,W=300,k=W/mb.width,H=mb.height*k;
  const wrap=document.createElement('div');wrap.style.cssText=`position:relative;width:${W}px;max-width:100%;height:${H}px;background:#fff;border:1px solid var(--line);border-radius:4px;overflow:hidden;margin-bottom:8px`;
  const cv=document.createElement('canvas');cv.width=W*2;cv.height=H*2;cv.style.cssText='width:100%;height:100%;display:block';const ov=document.createElementNS(NS,'svg');ov.setAttribute('viewBox',`0 0 ${W} ${H}`);ov.style.cssText='position:absolute;inset:0;width:100%;height:100%';
  wrap.append(cv,ov);box.appendChild(wrap);
  pdfjsLib.getDocument({data:A.bytes.slice(0)}).promise.then(d=>d.getPage(1)).then(pg=>{const vp=pg.getViewport({scale:1});return pg.render({canvasContext:cv.getContext('2d'),viewport:vp,transform:[cv.width/vp.width,0,0,cv.height/vp.height,0,0]}).promise}).catch(()=>{});
  const R=(x0,y0,x1,y1,col,dash,sw)=>{const r=document.createElementNS(NS,'rect');r.setAttribute('x',(x0-mb.x)*k);r.setAttribute('y',(mb.y+mb.height-y1)*k);r.setAttribute('width',(x1-x0)*k);r.setAttribute('height',(y1-y0)*k);r.setAttribute('fill','none');r.setAttribute('stroke',col);r.setAttribute('stroke-width',sw||1.5);if(dash)r.setAttribute('stroke-dasharray','3 2');ov.appendChild(r)};
  if(A.qr){if(A.qr.frame)R(A.qr.frame.x0,A.qr.frame.y0,A.qr.frame.x1,A.qr.frame.y1,'#50A6E1',true);if(A.qr.box)R(A.qr.box.x0,A.qr.box.y0,A.qr.box.x1,A.qr.box.y1,'#50A6E1',true);R(A.qr.x0,A.qr.y0,A.qr.x1,A.qr.y1,'#2F86C4',false,2);A.qr.letters.forEach(p=>R(p.x0,p.y0,p.x1,p.y1,'#2F86C4',true,1))}
  A.lines.forEach(l=>R(l.x0,l.y-l.size*.2,l.x1,l.y+l.size*.8,l.role==='fixe'?'#9aa0a6':'#e67e22',l.role==='fixe',1.2));
  const info=document.createElement('p');info.className='note';info.style.marginTop='0';
  const mbw=mb.width/MM,mbh=mb.height/MM;
  info.textContent=`Carte ${mmFmt(mbw)} × ${mmFmt(mbh)} mm · fond : ${A.bg?'aplat uni (CMJN '+A.bg.cmyk.map(v=>Math.round(v)).join('/')+')':'aucun aplat uni'}`;box.appendChild(info);
  const qi=document.createElement('p');qi.className=A.qr?'note ok':'note warn';qi.style.marginTop='4px';
  if(A.qr){const q=A.qr,gx=(q.x0-mb.x)/MM,gy=(mb.y+mb.height-q.y1)/MM;
    qi.textContent=`QR ${q.kind==='image'?'(image)':q.kind==='placeholder'?'(repère <<'+q.col+'>>)':'vectoriel'} : ${mmFmt(q.w/MM)} mm de côté, en x ${mmFmt(gx)} mm / y ${mmFmt(gy)} mm`+(q.version?` · version ${q.version} (${q.n}×${q.n} modules)`:'')+(q.ecc?` · correction ${q.ecc}`:'')+` · style : ${STYLE_TXT[q.style]}`}
  else qi.textContent='Aucun QR détecté : le modèle est créé sans QR, tu pourras en ajouter un.';
  box.appendChild(qi);
  if(A.qr){const st=document.createElement('select');Object.keys(QS).forEach(kk=>{const o=document.createElement('option');o.value=kk;o.textContent=QS[kk].label;st.appendChild(o)});st.value=A.style;st.onchange=()=>{A.style=st.value};box.appendChild(field('Style du QR (modifiable)',st))}
  const t=document.createElement('div');t.style.cssText='display:flex;flex-direction:column;gap:6px;margin-top:8px';
  A.lines.forEach(l=>{const row=document.createElement('div');row.style.cssText='display:grid;grid-template-columns:minmax(0,1fr) 150px;gap:8px;align-items:center';
    const sp=document.createElement('span');sp.style.cssText='min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap';sp.textContent=l.text;sp.title=`${l.font||'police ?'} · ${l.size.toFixed(1)} pt`;
    const sel=document.createElement('select');sel.className='btn sm';ROLES.forEach(([v,lab])=>{const o=document.createElement('option');o.value=v;o.textContent=lab;sel.appendChild(o)});sel.value=l.role;sel.onchange=()=>{l.role=sel.value};
    row.append(sp,sel);t.appendChild(row)});
  if(!A.lines.length){const p=document.createElement('p');p.className='note warn';p.textContent='Aucun texte détecté (textes vectorisés ?). Place les textes à la main.';t.appendChild(p)}
  box.appendChild(t);
  const r=document.createElement('div');r.className='row';r.style.marginTop='10px';
  const ok=document.createElement('button');ok.className='btn primary sm';ok.textContent=done?'Recréer avec ces choix':'Créer le modèle';ok.onclick=()=>createFromAna().catch(e=>{$('#log').textContent='Erreur : '+(e&&e.message||e)});
  const no=document.createElement('button');no.className='btn sm';no.textContent='Fermer';no.onclick=()=>{box.hidden=true};
  r.append(ok,no);box.appendChild(r);
  const n=document.createElement('p');n.className='note';n.textContent='Orange : textes variables retirés du visuel · gris : textes fixes conservés · bleu : QR (et boîte). Le modèle est créé automatiquement ; change un rôle ou le style puis « Recréer ».';box.appendChild(n)}
async function createFromAna(){
  const A=ana,mb=A.cc.mb;const cc=await cardContent(A.bytes);const remove=new Set();
  const RM=(sid,i)=>remove.add(sid+':'+i);
  A.lines.filter(l=>l.role!=='fixe').forEach(l=>l.showIdx.forEach(([sid,i])=>RM(sid,i)));
  const varLines=A.lines.filter(l=>!['fixe','qr','qrlabel'].includes(l.role));
  const qr=A.qr;
  if(qr){qr.paths.forEach(p=>p.idx.forEach(i=>RM(p.sid,i)));(qr.dos||[]).forEach(d=>RM(d.sid,d.i));
    qr.letters.forEach(p=>p.idx.forEach(i=>RM(p.sid,i)));if(qr.box)qr.box.idx.forEach(i=>RM(qr.box.sid,i))}
  // visuel nettoyé : on réécrit le flux de contenu sans les opérations retirées
  const ctx=cc.doc.context,touched=new Set([...remove].map(k=>+k.split(':')[0]));
  for(const st of cc.streams){if(st.sid!==0&&!touched.has(st.sid))continue;
    const kept=st.ops.filter((o,i)=>!remove.has(st.sid+':'+i)).map(o=>st.src.slice(o.s,o.e)).join('\n');
    const enc=new Uint8Array(kept.length);for(let i=0;i<kept.length;i++)enc[i]=kept.charCodeAt(i)&255;
    if(st.sid===0)cc.page.node.set(PDFLib.PDFName.of('Contents'),ctx.register(ctx.flateStream(enc)));
    else{const ns=ctx.flateStream(enc);for(const[k,v]of st.st.dict.entries()){const kn=k.asString();if(!['/Length','/Filter','/DecodeParms'].includes(kn))ns.dict.set(k,v)}ctx.assign(st.ref,ns)}}
  const clean=await cc.doc.save();
  const art={bytes:clean};S.fit='auto';$('#fitSel').value='auto';
  await setArt(new Uint8Array(clean),A.name.replace(/\.pdf$/i,'')+' (nettoyé).pdf',false);
  S.bg=A.bg;await drawArt();
  const pl=artPlace(S.art),offX=pl.ox,offY=pl.oy,sx=pl.sx,sy=pl.sy,top=ypdf=>(mb.y+mb.height-ypdf)/MM;
  const mk=o=>Object.assign({id:'e'+(S.nextId++)},o),els=[];
  if(qr){const u=(qr.w/MM*sx)/QS_SIDE,st=QS[A.style];
    els.push(mk({type:'qr',name:'QR code',col:qr.col||'url',style:A.style,x:r2((qr.x0-mb.x)/MM*sx+offX-st.qx*u),y:r2(top(qr.y1)*sy+offY-st.qy*u),size:r2(qr.w/MM*sx),ecc:qr.ecc||'M',color:toCmyk(qr.color),boxColor:[0,0,0,0]}))}
  const qb=qr?(qr.box||qr.frame||qr):null,qLeft=qr?(qb.x0-mb.x)/MM*sx+offX:null,qTop=qr?top(qb.y1)*sy+offY:0,qBot=qr?top(qb.y0)*sy+offY:0;
  const phTpl=l=>{let t=l.text;t=t.replace(/(\+\s*)?<<\s*([^<>]+?)\s*>>/g,(m,plus,f)=>ALIAS[4].includes(norm(f))?`{${f}|tel}`:(plus?'+':'')+`{${f}}`);return t.replace(PH,'{$1}')};
  const tpl={champ:phTpl,nom_complet:l=>/\b[A-ZÉÈÀÇ]{2,}\b/.test(l.text)?'{Prénom} {Nom|upper}':'{Prénom} {Nom}',prenom:()=>'{Prénom}',nom:l=>l.text===l.text.toUpperCase()?'{Nom|upper}':'{Nom}',email:()=>'{Email}',tel:()=>'{Téléphone|tel}',poste:()=>'{Poste}'};
  const labels={champ:'Champ',nom_complet:'Nom',prenom:'Prénom',nom:'Nom',poste:'Poste',email:'Email',tel:'Téléphone'};
  const groups=[];varLines.forEach(l=>{if(l.role==='poste'&&groups.length&&groups[groups.length-1].role==='poste')groups[groups.length-1].lines.push(l);else groups.push({role:l.role,lines:[l]})});
  for(const g of groups){const l=g.lines[0],last=g.lines[g.lines.length-1];if(g.role==='champ')labels.champ=(l.fields||[]).join(' ')||'Champ';
    const size=l.size,x=(l.x0-mb.x)/MM*sx+offX,ytop=(top(l.y)-size/MM*ASC)*sy+offY;
    const lab=(l.font||'').replace(/-/g,' ').trim();const bold=BOLD.test(l.font);
    let maxW=0;if(qLeft!=null&&ytop+size/MM>qTop-1&&ytop<qBot&&qLeft>x)maxW=r2(qLeft-x-1.2);
    els.push(mk({type:'text',name:labels[g.role]||'Texte',tpl:tpl[g.role](l),font:bold?'helv-b':'helv',fontLabel:lab||undefined,fontPs:l.font||undefined,size:r2(size*sy),x:r2(x),y:r2(ytop),color:toCmyk(l.color),lh:g.lines.length>1?r2((l.y-g.lines[1].y)/size):1.2,maxW}))}
  S.els=els;S.sel=els[0]?els[0].id:null;S.elsAreDemo=false;S.variantEl='';S.art2=null;
  // polices : Avenir etc. depuis les polices installées si disponibles
  const miss=new Set(),found=new Set();
  {const rf=await resolveFonts(S.els);rf.found.forEach(x=>found.add(x));rf.missing.forEach(x=>miss.add(x))}
  refreshVariant();renderList();renderForm();drawAll();drawArt().then(drawOverlay);reportMissing();
  $('#log').textContent='Modèle créé depuis la carte : '+els.length+' éléments.'+(found.size?' Polices trouvées : '+[...found].join(', ')+'.':'')+(miss.size?' Polices introuvables : '+[...miss].join(', ')+' (remplacées par Arial ; ajoute-les avec « Polices installées… »).':'')+' Charge maintenant ton fichier de données (Prénom, Nom, Poste, Email, Téléphone, URL du QR).';
  renderAna(true)}
$('#anaIn').onchange=ev=>{const f=ev.target.files[0];if(f)analyzeFile(f);ev.target.value=''};

/* ---------- Formats de planche : formats fournis (mis à jour en direct) + formats enregistrés sur ce poste ---------- */
const BUILTIN_FORMATS=[ // nom : Support · Matière · nombre de cartes · taille de carte
  {id:'aplat-304x412-18',label:'À plat · 18 cartes · 89,5 × 58 mm',sheet:{pageW:304,pageH:412,cols:3,rows:6,cardW:89.5,cardH:58,gapX:7,gapY:9,mL:11.5,mT:8,fillEnd:false}},
  {id:'board-pvc-21',label:'Board A3 · PVC blanc / noir · 21 cartes · 85,5 × 54 mm',card:{w:85.5,h:54},sheet:{pageW:300,pageH:420,cols:3,rows:7,cardW:85.5,cardH:54,gapX:0,gapY:0,mL:43.5,mT:42,fillEnd:true}},
  {id:'board-bambou-21',label:'Board A3 · Bambou · 21 cartes · 85,2 × 53,7 mm',card:{w:85.2,h:53.7},sheet:{pageW:300,pageH:420,cols:3,rows:7,cardW:85.2,cardH:53.7,gapX:0,gapY:0,mL:44.4,mT:44.1,fillEnd:true}},
  {id:'board-metal-21',label:'Board A3 · Métal Silver / Gold · 21 cartes · 85 × 54 mm',card:{w:85,h:54},sheet:{pageW:300,pageH:420,cols:3,rows:7,cardW:85,cardH:54,gapX:0,gapY:0,mL:45,mT:42,fillEnd:true}}];
const LS=(k,d)=>{try{return JSON.parse(localStorage.getItem(k)||'null')??d}catch(e){return d}},LSset=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}};
const userFormats=()=>LS('planche.formats',[]),saveUserFormats=l=>LSset('planche.formats',l);
const overrides=()=>LS('planche.formatOverrides',{}),saveOverrides=o=>LSset('planche.formatOverrides',o);
const allFormats=()=>{const o=overrides();return[...BUILTIN_FORMATS.map(f=>o[f.id]?{...f,...o[f.id],builtin:true,modified:true}:{...f,builtin:true}),...userFormats()]};
const KEYS=['pageW','pageH','cols','rows','cardW','cardH','gapX','gapY','mL','mT'];
const sameSheet=(a,b)=>KEYS.every(x=>Math.abs((a[x]||0)-(b[x]||0))<.001);
const fmtDesc=sh=>`Page ${mmFmt(sh.pageW)} × ${mmFmt(sh.pageH)} mm · ${sh.cols} × ${sh.rows} = ${sh.cols*sh.rows} cartes de ${mmFmt(sh.cardW)} × ${mmFmt(sh.cardH)} mm · écarts ${mmFmt(sh.gapX)} / ${mmFmt(sh.gapY)} mm · marges ${mmFmt(sh.mL)} / ${mmFmt(sh.mT)} mm`;
function renderFormats(){
  const sel=$('#fmtSel'),L=allFormats();if(!S.fmtId||!L.some(f=>f.id===S.fmtId)){const m=L.find(f=>sameSheet(f.sheet,S.sheet));S.fmtId=m?m.id:''}
  const f=L.find(x=>x.id===S.fmtId),changed=f&&!sameSheet(f.sheet,S.sheet);sel.innerHTML='';
  L.forEach(x=>{const o=document.createElement('option');o.value=x.id;o.textContent=x.label+(x.builtin?(x.modified?' (fourni, modifié)':''):' (enregistré)')+(x.id===S.fmtId&&changed?' — réglages modifiés':'');sel.appendChild(o)});
  if(!f){const o=document.createElement('option');o.value='';o.textContent='Format personnalisé (non enregistré)';sel.appendChild(o)}
  sel.value=S.fmtId;$('#fmtNote').textContent=(f&&f.card?`Carte finie ${mmFmt(f.card.w)} × ${mmFmt(f.card.h)} mm`+((S.sheet.cardW-f.card.w)>.05?` + ${mmFmt((S.sheet.cardW-f.card.w)/2)} mm de fond perdu · `:' · sans fond perdu, cartes jointives · '):'')+fmtDesc(S.sheet)+(S.sheet.fillEnd?' · board verso : planche incomplète calée à la fin':'')+(changed?' · différent du format enregistré':'');
  $('#fmtUpdate').hidden=!changed;$('#fmtUpdate').textContent=f?'Mettre à jour « '+f.label+' »':'';
  $('#fmtReset').hidden=!(f&&f.builtin&&f.modified);$('#fmtDel').hidden=!f||f.builtin;$('#fmtRename').hidden=!f}
function applyFormat(f){Object.assign(S.sheet,f.sheet);S.fmtId=f.id;syncSheetInputs();sheetInfo();drawSheet();sizeBox();drawArt().then(drawOverlay);LSset('planche.lastFormat',f.id)}
$('#fmtSel').onchange=e=>{const f=allFormats().find(x=>x.id===e.target.value);if(f)applyFormat(f)};
$('#fmtUpdate').onclick=()=>{const f=allFormats().find(x=>x.id===S.fmtId);if(!f)return;
  if(f.builtin){const o=overrides();o[f.id]={label:f.label,sheet:{...S.sheet}};saveOverrides(o)}else saveUserFormats(userFormats().map(x=>x.id===f.id?{...x,sheet:{...S.sheet}}:x));
  LSset('planche.lastFormat',f.id);  renderFormats();$('#log').textContent='Format « '+f.label+' » mis à jour sur ce poste.'};
$('#fmtReset').onclick=()=>{const o=overrides();delete o[S.fmtId];saveOverrides(o);const f=allFormats().find(x=>x.id===S.fmtId);if(f)applyFormat(f);$('#log').textContent='Format d\'origine rétabli.'};
$('#fmtSave').onclick=()=>{const name=$('#fmtName').value.trim()||('Format '+mmFmt(S.sheet.pageW)+' × '+mmFmt(S.sheet.pageH)+' · '+S.sheet.cols*S.sheet.rows+' cartes');
  const id='u'+Date.now();saveUserFormats([...userFormats(),{id,label:name,sheet:{...S.sheet}}]);S.fmtId=id;LSset('planche.lastFormat',id);$('#fmtName').value='';renderFormats();$('#log').textContent='Format « '+name+' » enregistré sur ce poste.'};
$('#fmtRename').onclick=()=>{const name=$('#fmtName').value.trim();if(!name){$('#fmtName').focus();return}const f=allFormats().find(x=>x.id===S.fmtId);if(!f)return;
  if(f.builtin){const o=overrides();o[f.id]={label:name,sheet:{...(o[f.id]?o[f.id].sheet:f.sheet)}};saveOverrides(o)}else saveUserFormats(userFormats().map(x=>x.id===f.id?{...x,label:name}:x));
  $('#fmtName').value='';renderFormats()};
$('#fmtDel').onclick=()=>{saveUserFormats(userFormats().filter(f=>f.id!==S.fmtId));S.fmtId='';renderFormats()};
/* ---------- démarrage ---------- */
(async function init(){
  S.els=defaultEls();S.sel=S.els[1].id;
  S.data={cols:['Prénom','Nom','Poste','Email','Téléphone','URL QR'],rows:demoRows(),name:'',demo:true};
  {let last='';try{last=localStorage.getItem('planche.lastFormat')||'';last=JSON.parse(last)}catch(e){}const f=allFormats().find(x=>x.id===last)||allFormats()[0];if(f){Object.assign(S.sheet,f.sheet);S.fmtId=f.id}}
  buildSheetInputs();refreshData();sheetInfo();sizeBox();renderList();renderForm();
  await setArt(await demoCard(),'',true);drawAll();
  window.__planche={S,generateBytes,setArt,loadData,applyTpl,cardContent,qrFromContent};
  if(window.api&&window.api.contentReady)window.api.contentReady();
  if(window.api&&window.api.appInfo)window.api.appInfo().then(i=>{const t=document.querySelector('.brand span');if(t)t.title='Version '+i.version+(i.downloaded?' (mise à jour)':'')}).catch(()=>{});
})();
})();
