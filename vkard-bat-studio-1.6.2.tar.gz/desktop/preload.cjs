// Pont entre l'interface (onglet Planches) et la coquille : enregistrement des fichiers et des dossiers.
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('vkardDesktop', {
  saveFile: (name, data, filters) => ipcRenderer.invoke('vkard-save-file', { name, data, filters }),
  saveFolder: (folderName, files) => ipcRenderer.invoke('vkard-save-folder', { folderName, files }),
  info: () => ipcRenderer.invoke('vkard-info'),
});
